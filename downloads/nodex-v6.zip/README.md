# Nodex V6 — Skill Formateur Trading (Simplicité Radicale)

**Version** : 6.0.0 · **Statut** : Privé (licence requise) · **Évolution de** : V5.3

---

## Qu'est-ce que c'est ?

Un skill Claude qui transforme Claude en **Nodex**, un formateur trading mécanique direct. Quand tu actives ce skill :

1. Nodex t'accueille et se présente
2. Te fait passer un **diagnostic** (4 ou 10 questions selon ton niveau)
3. Analyse ton profil (débutant / intermédiaire / avancé)
4. Crée un **programme adapté** (1, 2 ou 3 semaines)
5. T'aide à installer TradingView + connexion MCP
6. T'enseigne la **stratégie Nodex V6** étape par étape (top-down D1 → M15)
7. Te coache sur tes 30 premiers paper trades
8. Valide ton passage en live si tu atteins les seuils

---

## Quelle stratégie ?

**Nodex V6** = Simplicité Radicale, alignée sur la pratique des prop traders institutionnels (Druckenmiller, Tudor Jones, Mark Douglas) et validée par la recherche académique (Barber-Odean 2000, Brunnermeier-Pedersen 2009).

- **2 POI** : FVG + OB (les 2 que n'importe qui reconnaît en 5 secondes)
- **Top-down 2 niveaux** : D1 (bias) + M15 (exécution)
- **Fibo M15** · entry sous 0,5 obligatoire (zone discount)
- **Confirmation** : 1 bougie post-sweep
- Crypto spot Binance — **watchlist focus : ARB + PENDLE**
- Timeframe M15 · Sessions **Londres (9h-12h Paris) + NYAM (14h30-17h Paris)** · Long only
- Risk 1 % standard / 1,2 % max A+ · TP trailing 3 paliers (+1,5 / +2,5 / +3 %)
- **Checklist 8 points** + **3 questions OUI** binaires + scoring A+/A/B

---

## Installation

### Option A — Télécharger le ZIP
Décompresser dans `<ton projet>/.claude/skills/nodex-v6/`.

### Option B — Clone du repo (si fourni)
```bash
git clone <url-du-repo> .claude/skills/nodex-v6
```

### Option C — Copier le dossier
Copier manuellement le dossier `nodex-v6/` dans `.claude/skills/`.

---

## Activation

Dans Claude Code, dis simplement :
> *"Nodex, je veux apprendre le trading"*

Ou n'importe quel message contenant : `trade`, `V6`, `ARB`, `SMC`, `formation`, `apprendre`, `Nodex`, etc.

**Le skill s'active automatiquement** et lance le protocole d'onboarding (vérification licence → message d'accueil → diagnostic).

---

## Structure

```
nodex-v6/
├── SKILL.md                    ← Entry point (orchestration)
├── PERSONA.md                  ← Qui est Nodex
├── FIRST-MESSAGE.md            ← Message d'accueil
├── README.md                   ← Ce fichier
│
├── onboarding/
│   ├── welcome.md
│   ├── questionnaire.md
│   └── analyse-et-programme.md
│
├── setup/
│   ├── installation-guide.md
│   ├── activation-protocol.md
│   └── test-codes.md (interne)
│
├── references/
│   ├── methode-complete.md     ← V6 en 4 étapes mécaniques
│   ├── checklist-8-points.md   ← 8 points + 3 questions OUI
│   ├── erreurs-a-eviter.md
│   ├── filtres-asset.md        ← ARB + PENDLE
│   ├── psycho-argent-reel.md
│   └── grille-rentabilite.md
│
├── procedures/
│   ├── pre-trade-check.md
│   ├── live-coaching.md
│   ├── post-trade-debrief.md
│   ├── decision-go-no-go.md
│   ├── transition-live.md
│   ├── consolidation-live.md
│   ├── autonomie-rentable.md
│   └── emergency-stop.md
│
├── state/                      ← Mémoire vivante de l'apprenant (templates vides)
│   ├── current-phase.md
│   ├── live-progression.md
│   ├── metrics.md
│   └── trades-log.md
│
└── templates/
    ├── journal-trade-entry.md
    └── journal-live-trade.md
```

---

## Confidentialité

**Ce skill est sous licence personnelle non transférable.** Ne pas redistribuer publiquement sans accord du propriétaire.

Roadmap diffusion :
- Phase 1 : usage interne propriétaire
- Phase 2 : équipe restreinte (après validation 30 trades backtest)
- Phase 3 : produit commercial (après validation live rentable confirmée)

---

## Métriques cibles (Phase 3 backtest)

| Métrique | Seuil minimum |
|----------|---------------|
| Trades exécutés | ≥ 30 |
| WR (TP1) | ≥ 55 % |
| Profit Factor | ≥ 1,8 |
| Drawdown max | ≤ 10 % |
| Discipline (checklist 8 cochée) | ≥ 95 % |

---

## Philosophie

> *"Le trading rentable, c'est 8 points + 3 questions OUI. Tu coches, tu trades. Tu coches pas, tu skip. Le reste, c'est du vent."*
> — **Nodex**

> *"Tout devrait être rendu aussi simple que possible, mais pas plus simple."*
> — Albert Einstein

> *"Les meilleurs traders prennent peu de positions, mais avec une conviction totale."*
> — Stanley Druckenmiller (Duquesne Capital)

---

**Projet Nodex Trading** · Skill v6.0.0 · Licence personnelle non transférable
