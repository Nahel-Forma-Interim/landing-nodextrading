# 📥 Installation du skill Nodex V5.2

Bienvenue ! Ce guide te permet d'installer **Nodex** dans ton Claude Code en moins de **3 minutes**.

---

## 📋 Pré-requis

- **Claude Code** installé (https://claude.ai/code)
- Un dossier de projet où tu utilises Claude
- 3 minutes

---

## 🎯 3 options d'installation (choisis la tienne)

### Option 1 — Installation AUTOMATIQUE (recommandée)

#### Windows (PowerShell)

1. Télécharge le ZIP `nodex-v5.2-skill.zip`
2. Ouvre **PowerShell** (Windows + R → `powershell`)
3. Navigue vers le dossier où tu as téléchargé le ZIP :
   ```powershell
   cd C:\Users\TON_NOM\Downloads
   ```
4. Exécute le script d'installation :
   ```powershell
   Expand-Archive -Path "nodex-v5.2-skill.zip" -DestinationPath "."
   cd nodex-v5.2
   .\install.ps1
   ```
5. Suis les instructions à l'écran

#### Mac / Linux (Terminal)

1. Télécharge le ZIP `nodex-v5.2-skill.zip`
2. Ouvre le **Terminal**
3. Décompresse et lance :
   ```bash
   cd ~/Downloads
   unzip nodex-v5.2-skill.zip
   cd nodex-v5.2
   chmod +x install.sh
   ./install.sh
   ```
4. Suis les instructions

---

### Option 2 — Installation MANUELLE (simple, fiable)

#### Étape 1 — Trouve ton dossier `.claude`

Le dossier `.claude` se trouve :
- **Dans ton projet** (recommandé) : `<ton-projet>/.claude/`
- **Ou global** : `C:\Users\TON_NOM\.claude\` (Windows) ou `~/.claude/` (Mac/Linux)

Si le dossier `.claude/skills/` n'existe pas, crée-le.

#### Étape 2 — Décompresse le ZIP

Décompresse `nodex-v5.2-skill.zip` — tu obtiens un dossier `nodex-v5.2/`.

#### Étape 3 — Copie le dossier

Déplace le dossier `nodex-v5.2/` **ENTIER** dans :
```
<ton-projet>/.claude/skills/nodex-v5.2/
```

Ton arborescence doit ressembler à :
```
ton-projet/
└── .claude/
    └── skills/
        └── nodex-v5.2/
            ├── SKILL.md
            ├── FIRST-MESSAGE.md
            ├── PERSONA.md
            ├── README.md
            └── (autres dossiers...)
```

#### Étape 4 — Redémarre Claude Code

Ferme puis relance Claude Code pour qu'il détecte le nouveau skill.

---

### Option 3 — Installation via GitHub (pour les utilisateurs avancés)

Si tu as reçu une **invitation GitHub** au repo privé :

```bash
cd <ton-projet>
git clone https://github.com/Nahel-Forma-Interim/nodex-skill-licensed.git .claude/skills/nodex-v5.2
```

Remplace l'URL par celle fournie dans ton email d'achat.

---

## ✅ Vérification de l'installation

Ouvre Claude Code dans ton projet et tape :

```
Nodex, tu es là ?
```

**Si tout est OK** → Nodex t'accueille avec son message d'introduction standard.

**Si rien ne se passe** :
1. Vérifie que le dossier est bien dans `.claude/skills/nodex-v5.2/`
2. Vérifie que le fichier `SKILL.md` est présent à la racine du skill
3. Redémarre Claude Code
4. Réessaie

---

## 🔒 Activation par code de licence

À la **première utilisation**, Nodex te demandera ton **code d'activation** (reçu par email après achat).

Format attendu : `NDX-V52-YYYYMMDD-XXXXXX`

⚠️ **Ce code est PERSONNEL** et ne peut être utilisé que sur **une seule machine**. Si tu changes de PC, contacte le support pour transférer ta licence.

---

## 🆘 Problèmes courants

### "Nodex ne répond pas"
→ Vérifie que `.claude/skills/nodex-v5.2/SKILL.md` existe. Redémarre Claude Code.

### "Message d'accueil différent à chaque fois"
→ Impossible normalement. Si ça arrive, vérifie que `FIRST-MESSAGE.md` est présent et intact.

### "Le code d'activation ne fonctionne pas"
→ Vérifie le format (`NDX-V52-...`). Contacte le support si persiste.

### "Installation bloquée sur Mac"
→ Droits insuffisants. Essaie : `sudo ./install.sh`

---

## 📞 Support

Email support : **[à définir par le propriétaire]**
Discord : **[à définir]**
Délai de réponse : 24-48h en semaine

---

## 📜 Licence

Licence personnelle et non transférable. Voir `license/LICENSE-SYSTEM.md` pour les détails.

**Tout partage, revente ou redistribution est strictement interdit et passible de poursuites.**
