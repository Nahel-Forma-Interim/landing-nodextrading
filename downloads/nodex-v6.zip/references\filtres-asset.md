# Filtre de sélection d'actif V6 (score 4/5 minimum)

> *"Tu ne trades pas ce que tu kiffes. Tu trades ce qui passe la checklist."* — Nodex V6

## 5 critères de scoring (inchangé V5.3 → V6)

| Critère | 1 point si… |
|---------|-------------|
| Structure HTF | D1 bullish confirmé (HH+HL) |
| Amplitude 4j | ≥ 7 % (sinon range mou) |
| Volume moyen | > 300k sur M15 |
| BTC cycle | bullish ou neutre (pas dump franc) |
| Fréquence setups | ≥ 1 setup / jour observé |

## Watchlist V6 (focalisée pour lancement 2026-04-26)

| Actif | Score | Verdict V6 |
|-------|-------|------------|
| **ARB** | 5/5 | 🏆 **PRIORITAIRE** (bias bull confirmé, volume OK) |
| **PENDLE** | 4/5 | ✅ **PRIORITAIRE** (bias bull confirmé) |
| **SUI** | 3/5 | 🟡 Observer (pas dans focus V6) |
| **TAO** | 3/5 | 🟡 Observer |
| **FET** | 2/5 | ❌ **SKIP** (-80 % sur 6 mois) |
| **RENDER** | TBD | ⏳ À ré-évaluer après 30 trades V6 |

## Règle V6

- **Watchlist focus = ARB + PENDLE** uniquement pendant Phase 3 backtest
- Score ≥ 4/5 → actif tradable
- Score 3/5 → tradable en mode TP1 only (paper)
- Score ≤ 2/5 → **SKIP**

## Sessions par actif

Tous les actifs V6 se tradent **uniquement** dans :
- **Londres (9h-12h Paris)**
- **NYAM (14h30-17h Paris)**

Hors session = hors méthode = **SKIP**.

## Note exclusion ENA

**ENA est exclu** pour conformité religieuse musulmane. **Ne JAMAIS proposer ENA** dans la watchlist.

## Élargissement watchlist post-Phase 3

Si V6 validée sur ARB + PENDLE (30 trades, WR ≥ 55 %, PF ≥ 1,8, DD ≤ 10 %) :
1. Ajouter SUI en Phase 4
2. Puis TAO si SUI valide
3. Puis RENDER si bias bull se confirme

**Pas d'élargissement avant validation 30 trades.**

> *"3 actifs maîtrisés > 10 actifs survolés."* — Nodex V6

## Mantra watchlist V6

> **"ARB. PENDLE. C'est tout. Le reste, on regarde, on touche pas."**
