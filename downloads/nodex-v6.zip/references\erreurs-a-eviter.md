# Les 12 erreurs à éviter (pièges mortels) — V6.1

> *"89 % des comptes particuliers perdent. La cause majeure : ces 12 erreurs."*
> — Étude **AMF** (Autorité des Marchés Financiers, 2014, 14 799 comptes analysés)

1. ❌ **Trader hors Londres ou NYAM** — 80 % des pertes viennent des sessions pourries. Londres 9h-12h Paris OU NYAM 14h30-17h Paris, point.
2. ❌ **NOUVEAU V6.1 — Trader le lundi/vendredi à plein risk** — Lundi = consolidation post-weekend (peu directionnel). Vendredi PM = institutionnels ferment leurs positions (volatilité erratique). **Demi-risk obligatoire** (0,5 %).
3. ❌ **NOUVEAU V6.1 — Trader le samedi/dimanche** — Pas de volume institutionnel = mouvements aléatoires = perte garantie. **JAMAIS.**
4. ❌ **Entrer sans bougie de confirmation** — "J'anticipe" = suicide. Discipline absolue.
5. ❌ **Bouger le SL contre soi** — *"La règle la plus importante du trading est de jouer une grande défense, pas une grande attaque."* — **Paul Tudor Jones**. Transforme −1 % en −3 %.
6. ❌ **Ignorer le filtre BTC + Weekly** — BTC bearish OU weekly bearish = alts bearish. Check obligatoire.
7. ❌ **Trader un actif en range serré** — Amplitude < 5 % sur 4j = skip cet actif.
8. ❌ **Reprendre après 2 SL** — Émotionnellement compromis. Stop 24-48h. *"Si tu peux créer un état mental qui n'est pas affecté par le comportement du marché, la lutte cessera d'exister."* — **Mark Douglas**, *Trading in the Zone*.
9. ❌ **Augmenter risk pour rattraper** — "Je passe à 2 %" = flamber le compte. Biais de "gambler's fallacy" documenté par **Kahneman & Tversky** (Prix Nobel 2002).
10. ❌ **Sauter le journal** — Pas de journal = pas de progrès. Les institutionnels journalisent CHAQUE trade.
11. ❌ **NOUVEAU V6.1 — Se focaliser uniquement sur le Win Rate** — Le WR seul ne dit RIEN. Un trader à 70 % WR avec RR 1:1 perd long terme. Un trader à 45 % WR avec RR 3:1 gagne. **Suis l'EXPECTANCY** (= WR×gain − (1-WR)×perte) pas le WR.
12. ❌ **NOUVEAU V6.1 — Ignorer le TP intelligent (PDH/PDL)** — Garder un trailing fixe +3 % alors qu'un PDH est à +2,1 % = se faire reverse par les institutionnels qui chassent ce PDH. **TP final = MIN(trailing, liquidité opposée − 0,2 %).**

---

## Mantra anti-erreurs V6.1

> **"Mardi-mercredi-jeudi : plein risk. Le reste : demi-risk. Weekend : jamais."**
>
> **"Expectancy avant Win Rate."**
>
> **"TP = MIN(trailing, PDH proche). Pas un seul tick au-dessus."**

— **Nodex V6.1**
