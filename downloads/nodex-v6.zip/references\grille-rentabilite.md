# 📊 Grille de rentabilité — qu'est-ce que "rentable" exactement ?

> Référence chiffrée pour évaluer objectivement où en est l'apprenant.
> **Aucune subjectivité.** Les seuils décident.

---

## 🎯 NIVEAUX DE RENTABILITÉ NODEX (5 paliers)

### Palier 0 — DÉBUTANT (Phase 1-3)
- Zéro trade live
- Aucune métrique pertinente
- **Verdict** : "tu apprends, c'est tout"

### Palier 1 — APPRENTI (Phase 4-5)
- Critères paper validés (WR ≥ 45 %, PF ≥ 1.5, DD ≤ 15 %)
- Premiers trades live (< 15)
- **Verdict** : "tu sais théoriquement, on teste en pratique"

### Palier 2 — TRADER VIABLE (Phase 6, 1-2 mois validés)
- 1 ou 2 mois consécutifs profitables (+3 % min/mois)
- WR live ≥ 45 %
- DD intra-mois ≤ 8 %
- **Verdict** : "tu peux tenir, mais c'est encore fragile"

### Palier 3 — TRADER RENTABLE (Phase 6 validée, 3+ mois)
- 3 mois consécutifs profitables minimum
- WR live ≥ 50 %
- PF live ≥ 1.6
- DD cumulé ≤ -10 %
- **Verdict** : "tu es OFFICIELLEMENT rentable"
- **Action** : déclencher Phase 7 (autonomie + compagnon)

### Palier 4 — TRADER PROFESSIONNEL (Phase 7, 12+ mois)
- 12 mois validés
- Capital × 2 ou plus depuis le départ
- ROI annualisé ≥ +30 %
- **Verdict** : "tu es dans le top 1 % des traders retail"

### Palier 5 — MAÎTRE (Phase 7 long terme, 24+ mois)
- 24 mois validés
- Capital × 5 ou plus
- ROI annualisé ≥ +40 %
- **Verdict** : "le marché est ton terrain de jeu"

---

## 📐 LES MÉTRIQUES À CONNAÎTRE PAR CŒUR

### WR (Win Rate)
- Formule : `wins / total_trades × 100`
- Seuil minimal Nodex : **45 %**
- Confortable : **50-55 %**
- Excellent : **>60 %**

### PF (Profit Factor)
- Formule : `total_gains / abs(total_losses)`
- Seuil minimal Nodex : **1.5**
- Confortable : **1.8-2.0**
- Excellent : **>2.5**

### DD (Drawdown)
- Formule : `(peak_capital - trough_capital) / peak_capital × 100`
- Seuil critique : **-15 %** (au-delà = arrêt)
- Confortable : **<-10 %**
- Excellent : **<-5 %**

### ROI (Return on Investment)
- Formule : `(capital_actuel - capital_initial) / capital_initial × 100`
- Mensuel attendu Nodex : **+3 % minimum**
- Mensuel cible : **+5 %**
- Annualisé attendu : **+30-50 %**

### Discipline V6.1
- Formule : `trades_avec_9pts_cochés_et_4questions_OUI / total_trades × 100`
- Seuil critique : **95 %**
- Idéal : **99-100 %**

### NOUVEAU V6.1 — Expectancy (LA métrique qui décide)
- Formule : `(WR × gain_moyen) − ((1 − WR) × perte_moyenne)`
- Exprimée en **% de capital par trade**
- **Seuil critique** : **+0,3 %** par trade (en dessous, méthode pas viable)
- **Confortable** : **+0,5 % à +0,8 %** par trade
- **Excellent** : **>+1 %** par trade

**Pourquoi c'est LA métrique reine** : on peut être rentable avec 40 % WR si RR est élevé, et perdant avec 70 % WR si RR est faible. L'expectancy normalise tout en une seule valeur.

| Profil | WR | RR | Expectancy | Verdict |
|--------|-----|-----|------------|---------|
| V6.1 standard | 50 % | 2,5:1 | **+0,75 %** | ✅ Profitable |
| V6.1 paper bon | 60 % | 2,5:1 | **+1,1 %** | ✅✅ Très bon |
| Mauvaise méthode | 70 % | 1:1 | **+0,4 %** | 🟡 Fragile |
| Setup C | 40 % | 2:1 | **+0,2 %** | 🟠 À peine OK |
| Désastre | 50 % | 1:1 | **0** | ❌ Break-even |

### Comment calculer après 30 trades
1. Lister les 30 trades avec leur P&L en %
2. Compter les wins (W) et losses (L)
3. WR = W ÷ 30
4. Gain moyen = somme(P&L des wins) ÷ W
5. Perte moyenne = abs(somme(P&L des losses) ÷ L)
6. Expectancy = (WR × gain moyen) − ((1 − WR) × perte moyenne)

→ Tracker dans `state/metrics.md` à chaque ajout de trade.

---

## NOUVEAU V6.1 — Compound Effect (croissance exponentielle)

> *"Les intérêts composés sont la 8e merveille du monde. Celui qui les comprend en gagne, celui qui ne les comprend pas en paie."* — souvent attribué à Albert Einstein

### Formule
```
Capital final = Capital initial × (1 + rendement_mensuel)^nombre_de_mois
```

### Simulateur compound (capital initial 2 000 €)

| Rendement mensuel | 6 mois | 12 mois | 18 mois | 24 mois | 36 mois |
|-------------------|--------|---------|---------|---------|---------|
| **+3 %** | 2 388 € | 2 851 € | 3 405 € | 4 066 € | 5 798 € |
| **+5 %** (cible V6.1) | 2 680 € | 3 591 € | 4 812 € | 6 449 € | 11 567 € |
| **+8 %** (excellent) | 3 174 € | 5 036 € | 7 989 € | 12 678 € | 31 999 € |
| **+10 %** (top 1 %) | 3 543 € | 6 274 € | 11 117 € | 19 698 € | 61 717 € |

### Avec réinvestissement salaire (700 €/mois)

Capital initial 2 000 € + 700 €/mois injecté + rendement +5 %/mois :

| Mois | Capital total |
|------|---------------|
| 6 | 6 942 € |
| 12 | 12 868 € |
| 18 | 21 067 € |
| 24 | 32 487 € |

→ La combinaison **discipline V6.1 + injection régulière + compound** fait des miracles sur 18-24 mois.

### Règle d'or
*"+5 % par mois constant pendant 18 mois bat largement +50 % une fois et −30 % les 5 mois suivants."*

→ Vise la **régularité**, pas l'exploit ponctuel.

---

## 💡 ATTENDU vs PROMIS

### Ce qu'on PROMET à l'acheteur
- "Devenir un trader rentable durable en suivant le programme"
- "+3 % par mois en moyenne sur 12 mois bien suivis"
- "Capital qui double dans les 18-24 mois si discipline"
- "Méthode + coaching IA + indicateurs Pine + fiche cockpit"

### Ce qu'on NE PROMET PAS
- ❌ "Devenir riche en 3 mois"
- ❌ "+30 % par mois"
- ❌ "Quitter ton job dans 6 mois"
- ❌ "Méthode infaillible"
- ❌ "0 perte"

### Ce qu'on RAPPELLE OBJECTIVEMENT
- 95 % des traders retail échouent dans la première année
- Notre approche réduit ce risque à environ 50 % (encore 1 sur 2 échoue)
- L'échec vient à 95 % de la discipline, pas de la stratégie
- C'est pourquoi le skill se concentre sur le PROCESS, pas sur les setups

---

## 🚦 GRILLE DE DÉCISION RAPIDE (Claude utilise ça)

```
SI total_trades_live < 15 :
   → Phase 5 (transition)

SI total_trades_live >= 15 ET mois_consécutifs_profitables < 3 :
   → Phase 6 (consolidation)

SI mois_consécutifs_profitables >= 3 ET capital_actuel >= 1500€ :
   → Phase 7 (autonomie)

SI mois_consécutifs_profitables = 0 ET DD > -15 % :
   → ALERTE NOIRE → Retour Phase 4

SI mois_consécutifs_profitables tombe en cours :
   → COMPTEUR RESET → "tu repars à 0/3"
```

---

**Version** : 1.0 · **Référence** : grille rentabilité · **Phases** : 4-7
