# Métriques cumulées — V6 Backtest et Live

> **Template neutre** : à remplir au fur et à mesure que l'apprenant exécute ses trades.
> **Phase 3 visée** : 30 trades minimum avant Go/No-Go Phase 4.

---

## Stats globales V6.1

| Métrique | Valeur apprenant | Cible Phase 3 (30 trades) |
|----------|-------------------|----------------------------|
| Trades exécutés | [à remplir] | 30 |
| WR (TP1 touché min) | [à remplir] | ≥ 55 % |
| Profit Factor | [à remplir] | ≥ 1,8 |
| Drawdown max | [à remplir] | ≤ 10 % |
| P&L cumulé | [à remplir] | positif |
| RR moyen obtenu | [à remplir] | ≥ 2,5:1 |
| **Expectancy (V6.1)** | [à calculer] | **≥ +0,5 % par trade** |
| **Discipline (9pts + 4Q OUI cochés)** | [à remplir] | **≥ 95 %** |

---

## Répartition scénarios trailing (à remplir)

| Scénario | Nombre | % | Cible |
|----------|--------|---|-------|
| A · Move parfait (+3 %) | [à remplir] | [à remplir] | ≥ 35 % |
| B · Partiel +2,5 % (+1,5 %) | [à remplir] | [à remplir] | ~15 % |
| C · Partiel +1,5 % (BE) | [à remplir] | [à remplir] | ~15 % |
| D · SL initial (−1 %) | [à remplir] | [à remplir] | ≤ 35 % |

---

## Répartition par actif (à remplir)

| Actif | Trades | WR | P&L | Note |
|-------|--------|-----|-----|------|
| ARB | [à remplir] | [à remplir] | [à remplir] | Watchlist focus prioritaire |
| PENDLE | [à remplir] | [à remplir] | [à remplir] | Watchlist focus prioritaire |
| Autres | 0 | — | — | Hors focus V6 |

---

## Répartition par grade (à remplir)

| Grade | Trades | % | WR | PF |
|-------|--------|---|-----|-----|
| A+ (8/8) | [à remplir] | [à remplir] | [à remplir] | [à remplir] |
| A (7/8) | [à remplir] | [à remplir] | [à remplir] | [à remplir] |
| B (6/8) | [à remplir] | [à remplir] | [à remplir] | [à remplir] |

**Cible distribution V6** : ~20 % A+ · ~40 % A · ~25 % B · ~15 % SKIP.

---

## Répartition par session (à remplir)

| Session | Trades | WR | P&L |
|---------|--------|-----|-----|
| Londres (9h-12h Paris) | [à remplir] | [à remplir] | [à remplir] |
| NYAM (14h30-17h Paris) | [à remplir] | [à remplir] | [à remplir] |

---

## Erreurs répétées (Demon Finder)

| Erreur | Occurrences | Statut |
|--------|-------------|--------|
| (à analyser après 30 trades) | — | — |

**Règle Nodex** : si une erreur atteint ≥ 3 occurrences sur 10 trades → STOP + revue méthode.

---

## Prochaines actions (Nodex remplit selon contexte apprenant)

1. [À DÉFINIR par Nodex selon stats actuelles]
2. [À DÉFINIR]
3. [À DÉFINIR]

---

## Critères Go/No-Go Phase 4 (rappel)

| Critère | Seuil minimum |
|---------|---------------|
| Trades exécutés | ≥ 30 |
| WR | ≥ 55 % |
| Profit Factor | ≥ 1,8 |
| Drawdown max | ≤ 10 % |
| Discipline (checklist 8 pts cochée correctement) | ≥ 95 % |
| 2 SL consécutifs respecté ? | OUI obligatoire |

**Si TOUS critères OK** → GO Phase 5 (transition live).
**Si UN critère manque** → NO-GO, retour Phase 3 + audit + ajustement.

---

**Version** : 1.0 template neutre · **MAJ initiale** : à la création de la licence
