# Suivi de progression LIVE — [Nom de l'apprenant]

> **Fichier mémoire vivante** : Claude (Nodex) lit + écrit à chaque interaction.
> Permet de savoir EXACTEMENT où en est l'apprenant dans son parcours live.
> **Template neutre** : à remplir lors du passage en Phase 5 (Live).

---

## État actuel (snapshot)

- **Phase actuelle** : [À REMPLIR — 1 à 7]
- **Date début live** : [À REMPLIR : YYYY-MM-DD]
- **Capital initial live** : [À REMPLIR]
- **Capital actuel** : [À REMPLIR]
- **Variation totale** : [À REMPLIR]
- **Sessions tradées** : Londres (9h-12h Paris) + NYAM (14h30-17h Paris)

---

## Phase 5 — Transition (paliers risk)

L'apprenant passe par 3 paliers de risque progressifs :

| Palier | Risk | Trades min | Validation |
|---|---|---|---|
| 1 | 0,25 % | 5 trades | ≥ 60 % WR |
| 2 | 0,5 % | 5 trades | ≥ 55 % WR |
| 3 | 1 % | 5 trades | ≥ 55 % WR |

**Statut Phase 5** : [⏳ Non démarrée · 🟡 En cours · ✅ Validée · ❌ À recommencer]

> **Exception** : si l'apprenant a déjà une expérience live profitable documentée (capital + statistiques antérieures), Nodex peut autoriser une entrée directe à 1 % de risk. Décision au cas par cas dans `procedures/transition-live.md`.

---

## Phase 6 — Consolidation (compteur consistance)

- **Compteur consistance** : [X / 3 mois consécutifs profitables]
- **Mois en cours** : [À REMPLIR]
- **Capital actif** : [À REMPLIR]

### Historique mensuel (à remplir mois après mois)

| Mois | Capital fin | Variation % | WR | PF | DD | Statut |
|---|---|---|---|---|---|---|
| [Mois 1] | — | — | — | — | — | ⏳ |
| [Mois 2] | — | — | — | — | — | ⏳ |
| [Mois 3] | — | — | — | — | — | ⏳ |

### Alertes déclenchées
- 🟠 Jaunes : 0
- 🔴 Rouges : 0
- ⚫ Noires : 0

---

## Phase 7 — Autonomie (à venir si Phase 6 validée)

- **Date d'entrée Phase 7** : à déterminer après 3 mois consécutifs profitables
- **Mois validés cumulés** : [À REMPLIR]

---

## Stratégie utilisée : Nodex V6 (Simplicité Radicale)

- **TF d'exécution** : M15
- **Top-down** : D1 → M15 (2 timeframes seulement)
- **Sessions** : Londres 9h-12h Paris + NYAM 14h30-17h Paris
- **2 POI** : FVG + OB
- **Fibo M15** · entry sous 0,5 obligatoire
- **Confirmation** : 1 bougie (close au-dessus du high du sweep)
- **Trailing 3 paliers** : +1,5 % BE / +2,5 % SL +1,5 % / +3 % sortie
- **Risk** : 1 % standard / 1,2 % max A+
- **Watchlist focus** : ARB + PENDLE
- **Max trades / jour** : 3 (idéalement 1 si A+)

---

## Prochaine action attendue

[À DÉFINIR par Nodex selon la phase actuelle de l'apprenant]

---

## Stops automatiques actifs (Phase 6)

1. **3 SL consécutifs** → STOP 24h
2. **−10 % DD global** → STOP 1 semaine + audit
3. **−20 % DD global** → STOP COMPLET, retour paper
4. **2 trades hors checklist 8 points / semaine** → STOP + audit discipline
5. **1 revenge trade détecté** (entrée < 30 min après SL) → STOP + 24h

---

## Verdict global (snapshot)

```
[Date snapshot]
─────────────────────────────────────
Niveau   : [À REMPLIR]
Phase    : [X / 7]
Capital  : [À REMPLIR]
Compteur : [X / 3 mois consécutifs profitables]
Sessions : Londres + NYAM
Stratégie: V6 Simplicité Radicale
Verdict  : [À REMPLIR par Nodex]
─────────────────────────────────────
```

---

**Version** : 1.0 template neutre · **MAJ initiale** : à l'entrée Phase 5
