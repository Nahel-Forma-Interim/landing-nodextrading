# Questionnaire Diagnostic V6.1 — 20 questions précises

> **Pourquoi 20 questions** : V6.0 utilisait 10 questions trop générales. Résultat : un trader avec déjà 6 mois d'expérience était classé "intermédiaire" et avait droit à 2 semaines, alors qu'il a besoin de 3-6 mois minimum pour valider 3 mois live profitables (objectif final V6.1).
> **20 questions** = diagnostic précis sur 6 dimensions : technique, expérience, discipline, psychologie, contexte personnel, attentes.

Nodex pose ces questions **UNE PAR UNE**, attend la réponse, puis enchaîne. Pas de liste en bloc.

---

## BLOC 1 — Expérience & Technique (Q1 à Q6)

### Question 1 — Ancienneté trading
> *"Depuis combien de temps tu trades activement (pas juste regarder des charts) ? (jamais / moins de 6 mois / 6 mois - 2 ans / 2-4 ans / 4 ans+)"*

**Mesure** : ancienneté · **Pondération ×1**

### Question 2 — Rentabilité passée (la VRAIE question)
> *"Sur les 12 derniers mois, combien de mois CALENDAIRES complets tu as terminés profitable (compte qui a augmenté entre le 1er et le 30) ? (0 / 1-2 / 3-5 / 6-9 / 10+)"*

**Mesure** : rentabilité réelle (vs feeling) · **Pondération ×2**
**Pourquoi** : un trader qui dit "je suis parfois rentable" peut avoir 0 mois calendaire profitable.

### Question 3 — Maîtrise concepts SMC/ICT
> *"Combien de ces concepts tu peux EXPLIQUER à quelqu'un sans Google : FVG, OB, BB, BPR, Sweep, MSS, CHoCH, OTE, Premium/Discount, Liquidity Pools, IFVG ?"*
>
> *(0-2 / 3-5 / 6-8 / 9+)*

**Mesure** : maîtrise réelle SMC · **Pondération ×2**
**Pourquoi** : "j'ai vu une vidéo sur les FVG" ≠ "je peux l'expliquer".

### Question 4 — Expérience crypto spot Binance
> *"Tu as déjà tradé du crypto spot sur Binance (achat-vente d'altcoins) ? Combien de temps ?"*
>
> *(jamais / 1-6 mois / 6 mois-2 ans / 2 ans+)*

**Mesure** : familiarité plateforme · **Pondération ×1**

### Question 5 — Aisance timeframe M15
> *"Sur quel timeframe tu te sens le plus à l'aise pour PRENDRE une décision d'entrée ?"*
>
> *(M1-M5 scalping / M15-M30 / H1-H4 / D1+)*

**Mesure** : alignement avec V6.1 (M15) · **Pondération ×1**
**Pourquoi** : un scalper M1 va devoir s'adapter à M15 (plus lent, plus patient).

### Question 6 — Sessions Londres / NYAM
> *"Tu as déjà tradé pendant les sessions Londres (9h-12h Paris) ou NYAM (14h30-17h Paris) en sachant POURQUOI tu choisis ces fenêtres ?"*
>
> *(jamais / parfois sans savoir pourquoi / régulièrement, je sais que c'est pour la liquidité / oui c'est mon timing principal)*

**Mesure** : compréhension liquidité institutionnelle · **Pondération ×1**

---

## BLOC 2 — Discipline & Psychologie (Q7 à Q12)

### Question 7 — Auto-évaluation discipline
> *"Tu te décrirais comment sur l'impulsivité en trading ?"*
>
> *(j'ai déjà flamé un compte sur une mauvaise décision / parfois je me laisse emporter / globalement discipliné / très discipliné, je suis ma méthode à 95 %+ même en perte)*

**Mesure** : risque psychologique · **Pondération ×3** (le plus important)

### Question 8 — Gestion des émotions sur perte
> *"Quand tu prends une perte (SL touché), comment tu réagis dans les 30 minutes qui suivent ?"*
>
> *(je tilte, je revenge trade / je suis stressé, j'évite l'écran / je prends une pause, je continue calmement / je ne ressens presque rien, j'analyse rationnellement)*

**Mesure** : maturité émotionnelle (Mark Douglas) · **Pondération ×2**

### Question 9 — Capital actuel disponible
> *"Quel capital tu as DÉJÀ disponible (pas projeté, vraiment dispo) pour le trading ?"*
>
> *(< 500 € / 500-1500 € / 1500-5000 € / 5000+ €)*

**Mesure** : adaptation calculs + sérieux financier · **Pondération ×1**

### Question 10 — Disponibilité quotidienne
> *"Combien d'heures tu peux DÉDIER au trading par jour en semaine (pas juste regarder, vraiment travailler : analyse + journal + lecture) ?"*
>
> *(< 30 min / 30 min-1h / 1-2h / 2h+)*

**Mesure** : intensité du coaching · **Pondération ×1**

### Question 11 — Journal de trading
> *"As-tu déjà tenu un journal de trading (chaque trade loggué : entry, SL, TP, raison, résultat, leçon) pendant au moins 30 jours consécutifs ?"*
>
> *(jamais / commencé sans tenir / 30+ jours mais arrêté / oui, je tiens un journal régulier depuis 6+ mois)*

**Mesure** : discipline objective · **Bonus +2 si OUI**

### Question 12 — Backtesting rigoureux
> *"As-tu déjà fait 30 backtests rigoureux (chaque trade documenté avec capture d'écran + journal) d'une seule méthode pour la valider statistiquement ?"*
>
> *(jamais / 5-10 backtests informels / 30+ backtests sur une méthode / oui plusieurs méthodes validées par 30+ backtests)*

**Mesure** : approche scientifique · **Bonus +2 si OUI**

---

## BLOC 3 — Engagement & Réalisme (Q13 à Q18)

### Question 13 — Patience théorie+paper
> *"Es-tu prêt à NE PAS toucher à ton vrai capital pendant 1 mois entier (théorie + paper trading uniquement) ?"*
>
> *(non, je veux trader réel rapidement / oui mais ça va être dur / oui, c'est OK / oui, c'est même la condition de réussite selon moi)*

**Mesure** : maturité d'engagement · **Bonus +2 si OUI · Malus -3 si NON**
**Pourquoi** : si NON, le programme V6.1 n'est pas pour cet apprenant.

### Question 14 — Discipline mécanique
> *"Es-tu prêt à respecter une checklist de 9 points + 4 questions OUI binaires SANS modifier la méthode pendant 3 mois (pas même un petit ajustement) ?"*
>
> *(non, je préfère adapter à mon feeling / oui mais je vais être tenté / oui, je comprends que c'est essentiel / oui, c'est exactement ce qu'il me faut)*

**Mesure** : capacité à suivre méthode mécanique · **Bonus +2 si OUI · Malus -3 si NON**

### Question 15 — Indépendance financière
> *"As-tu un revenu indépendant du trading qui couvre tes besoins (salaire, business, économies) ?"*
>
> *(non, je dois devenir rentable rapidement / partiellement / oui, le trading est en plus / oui, je suis financièrement autonome)*

**Mesure** : pression psychologique financière · **Bonus +1 si OUI · Malus -2 si NON**
**Pourquoi** : la pression "il faut que je gagne" tue la discipline.

### Question 16 — Objectif réaliste
> *"Quel est ton objectif RÉALISTE pour les 6 prochains mois avec V6.1 ?"*
>
> *(devenir riche, doubler mon capital chaque mois / faire +50 % en 6 mois / faire +20-30 % en 6 mois / devenir DURABLEMENT rentable, +3 à +5 %/mois constant)*

**Mesure** : alignement avec attentes V6.1 · **Bonus +1 si réaliste · Malus -3 si "riche"**
**Pourquoi** : le trader qui veut "doubler chaque mois" est statistiquement perdant (Barber-Odean 2000).

### Question 17 — Rôle de la chance
> *"Penses-tu que la chance joue un rôle dans le résultat de tes trades individuels ?"*
>
> *(non, c'est 100 % skill / un peu, mais c'est surtout skill / oui, sur 1 trade c'est variance pure, c'est sur 100+ trades qu'on voit le skill / oui, et c'est pour ça qu'on regarde l'expectancy pas le WR seul)*

**Mesure** : compréhension probabiliste · **Bonus +1 si OUI · Malus -2 si "100 % skill"**

### Question 18 — Tolérance aux pertes consécutives
> *"Combien de pertes consécutives peux-tu encaisser SANS modifier ta méthode ou réduire ta taille ?"*
>
> *(< 3 pertes je me remets en question / 3-4 pertes / 5-7 pertes / 8+ pertes, tant que la méthode est validée statistiquement)*

**Mesure** : robustesse psychologique · **Bonus +1 si 5+ · Malus -2 si <3**

---

## BLOC 4 — Contexte & Motivation (Q19 à Q20)

### Question 19 — Influence du contenu YouTube/Telegram
> *"Sur les 6 derniers mois, à quel point t'as été influencé par des contenus YouTube/Telegram trading qui promettent du gain rapide ou des "secrets" ?"*
>
> *(énormément, je suis 5+ chaînes et j'attends leurs signaux / pas mal, mais je suis sceptique / un peu, je sais filtrer / pas du tout, je suis méfiant des promesses)*

**Mesure** : conditionnement par contenus à risque · **Bonus +1 si "non" · Malus -1 si "énormément"**

### Question 20 — Conscience statistique des pertes retail
> *"Sais-tu que selon les études de l'Autorité des Marchés Financiers (AMF, 2014, 14 799 comptes analysés), 89 % des particuliers perdent à long terme ? Et que selon Barber-Odean (Journal of Finance, 2000), les day traders perdent en moyenne -11,5 %/an ?"*
>
> *(non je ne savais pas / oui mais moi je suis différent / oui c'est exactement pour ça que je veux une méthode mécanique / oui et c'est pour ça que je vais respecter ta méthode à 100 %)*

**Mesure** : humilité face aux statistiques · **Bonus +1 si OUI · Malus -2 si "moi je suis différent"**

---

## Calcul du score final V6.1

```
Score brut (Q1-Q10 pondéré) : max 40 points
+ Bonus (Q11-Q20) : max +12 points
- Malus (Q11-Q20) : max -19 points

Score final = Score brut + Bonus - Malus
Plage théorique : -19 à +52 points
```

### Classification V6.1

| Score final | Profil | Programme |
|-------------|--------|-----------|
| < 10 points | **Débutant à risque** | 6 mois (avec accompagnement renforcé psy) |
| 10-20 points | **Débutant standard** | 6 mois |
| 21-30 points | **Intermédiaire** | 4 mois |
| 31-42 points | **Avancé** | 3 mois (minimum strict) |
| > 42 points | **Expert** | 3 mois (test rapide V6.1, validation 3 mois live obligatoire) |

> ⚠️ **Aucun programme < 3 mois.** L'objectif est 3 mois live profitables consécutifs. Sans ça, impossible de prétendre être "rentable durablement".

---

## Fin du questionnaire

Après Q20, Nodex dit :

> *"OK, j'ai ton profil complet. Laisse-moi **3 minutes** pour analyser tes 20 réponses, calculer ton score sur 52 points, et te proposer un programme sur-mesure de **3 à 6 mois**.*
>
> *Note : aucun programme V6.1 ne dure moins de 3 mois — c'est mathématique. Pour valider une méthode statistiquement, il faut au moins 60-90 trades en live, ce qui demande 3 mois calendaires. Avant ça, tout résultat est de la variance, pas du skill."*

Puis Nodex lit `onboarding/analyse-et-programme.md` et applique la grille V6.1.

---

## Version courte V6.1 (si apprenant dit "j'ai du niveau, passons vite")

**Important** : même en version courte, on garde **8 questions minimum** (vs 4 en V6.0) pour ne pas mal classer un apprenant.

Poser :
- Q1 (ancienneté)
- Q2 (mois calendaires profitables — la VRAIE question)
- Q3 (concepts SMC explicables)
- Q7 (discipline auto-éval)
- Q13 (prêt à 1 mois sans live ?)
- Q14 (prêt à respecter checklist 3 mois sans modif ?)
- Q16 (objectif réaliste 6 mois ?)
- Q20 (conscience stats AMF/Barber-Odean ?)

Puis classer en intermédiaire ou avancé. **Si Q13 ou Q14 = NON** → proposer la version longue, ce candidat n'est pas prêt.

---

**Version** : 2.0 (V6.1 — questionnaire 20 questions précises, alignement objectif autonomie réelle)
