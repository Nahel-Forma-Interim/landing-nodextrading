# Analyse + Programme adaptatif V6.1 (objectif autonomie réelle)

> **Objectif final V6.1** : pas "rentable en 2 semaines paper", mais **rentable en LIVE sur 3 mois consécutifs minimum**, capable de trader seul sans Claude.
> **Durée totale minimum** : 4 mois (1 mois théorie+paper · 3 mois live consolidation)
> **Durée totale recommandée** : 6 mois (transition douce et consolidation solide)

---

## Grille de scoring V6.1 (basée sur questionnaire 20 questions étendues)

Nodex attribue un **score de maturité** sur 40 points :

| Critère | 0 pt | 1 pt | 2 pts | 3 pts | Pondération |
|---------|------|------|-------|-------|-------------|
| Q1 Expérience trading | < 6 mois | 6m-2 ans | 2-4 ans | 4+ ans | ×1 |
| Q2 Rentabilité passée | Jamais | Parfois | Souvent | Régulièrement | ×2 |
| Q3 Maîtrise SMC/ICT (FVG, OB, sweep, MSS, OTE…) | 0-2 concepts | 3-5 | 6-8 | 9+ | ×2 |
| Q4 Crypto spot Binance | Jamais | 1-6 mois | 6m-2 ans | 2+ ans | ×1 |
| Q5 Aisance M15 | Incompatible | Neutre | OK | Expert | ×1 |
| Q6 Sessions Londres/NYAM | Jamais tradé | Bases | Habituel | Maîtrisé | ×1 |
| Q7 Discipline auto-éval | Flamé compte | Parfois impulsif | Globalement bon | Très discipliné | ×3 |
| Q8 Gestion d'émotions (perte) | Tilt fort | Stress modéré | OK | Détaché | ×2 |
| Q9 Capital disponible | < 500 € | 500-1500 € | 1500-5000 € | 5000+ € | ×1 |
| Q10 Disponibilité quotidienne | < 30 min | 30 min-1h | 1-2h | 2h+ | ×1 |

**Score max** : 40 points · **Score min** : 0 point

### Bonus / Malus (5 questions psy + objectifs)

| Question | Bonus | Malus |
|----------|-------|-------|
| Q11 As-tu déjà tenu un journal de trading ≥ 30 jours ? | +2 | 0 |
| Q12 As-tu déjà fait 30 backtests rigoureux d'une méthode ? | +2 | 0 |
| Q13 Es-tu prêt à NE PAS trader pendant 1 mois entier (théorie+paper only) ? | +2 si OUI | -3 si NON |
| Q14 Es-tu prêt à respecter une checklist mécanique sans la modifier 3 mois ? | +2 si OUI | -3 si NON |
| Q15 As-tu un revenu indépendant du trading (salaire, business) ? | +1 si OUI | -2 si NON |
| Q16 Objectif réaliste pour 6 mois ? (rentable, +50 %, +200 %, riche) | +1 réaliste | -3 si "riche" |
| Q17 Penses-tu que la chance joue un rôle dans ton trading ? | +1 si OUI | -2 si "non, c'est skill pur" |
| Q18 Combien de pertes consécutives peux-tu encaisser sans modifier ta méthode ? | +1 si 5+ | -2 si <3 |
| Q19 Marqué par des contenus YouTube/Telegram récents ? | -1 si "oui beaucoup" | +1 si "non, je suis sceptique" |
| Q20 Comprends-tu que 89 % des traders particuliers perdent à long terme (étude AMF) ? | +1 si OUI | -2 si "moi je ne suis pas comme eux" |

---

## Classification V6.1 et programmes (durée minimum 1 mois)

### 🟢 Débutant (0-15 points sur 40) → Programme 6 mois

**Profil type** : peu d'expérience, jamais ou rarement rentable, SMC à découvrir, discipline à construire, peut-être marqué par des contenus YouTube qui promettent la rapidité.

> **Message Nodex** : *"Tu commences un vrai parcours. Le trading rentable n'est pas un sprint. On va faire les choses dans l'ordre, sans précipitation. Si tu cherches du gain rapide, ce n'est pas le bon outil — il y a 89 % de chances que tu perdes (étude AMF, Journal of Finance Barber-Odean 2000). Si tu cherches une vraie compétence transmissible sur 6 mois, on est bien."*

#### Mois 1 — Théorie + premiers paper (4 semaines)

| Semaine | Contenu | Objectif |
|---------|---------|----------|
| S1 | Installation TV + Pine pack + lectures fondamentales (Tendance/Range/Liquidité/Sweep/POI) + quiz | Setup OK + bases solides |
| S2 | Méthode V6.1 complète : 4 étapes mécaniques + 9 points checklist + 4 questions OUI + Fibo M15 | Connaître la méthode par cœur |
| S3 | TP intelligent (PDH/PDL) + Trailing 3 paliers + Risk management + Calendar mardi-jeudi | Maîtriser les sorties |
| S4 | **5 paper trades** sur ARB en mode coaché, débrief chacun + journal écrit obligatoire | Premiers réflexes |

#### Mois 2 — Paper trading intensif (4 semaines, ≥ 30 trades)

| Semaine | Contenu | Objectif |
|---------|---------|----------|
| S5-S6 | 15 paper trades supplémentaires sur ARB + PENDLE | 20 trades cumulés |
| S7 | Mid-debrief : analyse des 20 trades, Demon Finder (erreurs répétées), ajustements discipline | Identifier les fuites |
| S8 | 10 paper trades supplémentaires + journal vidéo OBS recommandé | 30 trades cumulés |

**Décision Go/No-Go Phase 4 fin Mois 2** :
- Trades exécutés : ≥ 30
- WR ≥ 55 %
- PF ≥ 1.8
- Drawdown max ≤ 10 %
- Discipline (9pts + 4Q OUI cochés) ≥ 95 %
- **Expectancy ≥ +0,5 % par trade** (la métrique-clé V6.1)

→ Si TOUS critères OK : passage Mois 3 (transition live)
→ Si UN critère manque : on prolonge le paper de 2 semaines + audit méthode

#### Mois 3 — Transition Paper → Live (4 semaines, paliers risk)

| Semaine | Capital | Risk | Trades min | Validation |
|---------|---------|------|------------|------------|
| S9 | 500 € live | **0,25 %** | 5 | ≥ 60 % WR |
| S10 | 500 € live | **0,5 %** | 5 | ≥ 55 % WR + 3 questions OUI psy "je dors quand même bien" toujours OUI |
| S11 | 500 € live | **0,75 %** | 5 | ≥ 55 % WR |
| S12 | 500 € live | **1 % standard** | 5 | ≥ 55 % WR |

**Si discipline OK toute la période** → Mois 4-6 démarre.
**Si décrochage** → retour Mois 2 (paper) + analyse psy.

#### Mois 4-6 — Consolidation LIVE (3 mois consécutifs profitables — OBJECTIF FINAL)

| Mois | Capital | Risk | Cible | Validation |
|------|---------|------|-------|------------|
| Mois 4 | 500 € live | 1 % standard / 1,2 % A+ | +3 % min | Mois 1/3 OK |
| Mois 5 | Capital × 1,5 (≈ 750 €) | 1 % standard | +3 % min | Mois 2/3 OK |
| Mois 6 | Capital × 2 (≈ 1 000 €) | 1 % standard | +3 % min | Mois 3/3 OK = **certifié rentable** |

**Validation finale Phase 7 (autonomie)** :
- 3 mois consécutifs profitables (+3 % min/mois)
- WR mensuel moyen ≥ 55 %
- Aucune alerte rouge ou noire déclenchée
- Discipline ≥ 95 %
- **L'apprenant peut trader SEUL sans Claude pendant 1 semaine entière** (test final autonomie)

---

### 🟡 Intermédiaire (16-25 points sur 40) → Programme 4 mois

**Profil type** : 1-3 ans d'expérience, parfois rentable, SMC connu mais pas systématiquement appliqué, discipline moyenne à bonne.

> **Message Nodex** : *"Tu n'es pas débutant, mais tu n'es pas encore rentable durablement. On va consolider tes bases, t'imposer la discipline qui te manque (la checklist 9 points + 4 questions OUI), et te faire valider 3 mois live consécutifs profitables. Pas de raccourci, mais on va plus vite sur la théorie."*

#### Mois 1 — Rappels théorie + Setup V6.1 + premiers paper (4 semaines)

| Semaine | Contenu |
|---------|---------|
| S1 | Installation/rappel TV + lectures rapides fondamentaux + Setup V6.1 méthode complète |
| S2 | Checklist 9 points + 4 questions OUI + Calendar mardi-jeudi + TP intelligent PDH/PDL |
| S3 | Risk management + Expectancy + journal 4 couches + 5 premiers paper trades coachés |
| S4 | 10 paper trades supplémentaires + débrief intermédiaire |

#### Mois 2 — Paper intensif (≥ 20 trades supplémentaires, total 35)

| Semaine | Contenu |
|---------|---------|
| S5-S6 | 15 paper trades sur ARB + PENDLE + journal vidéo OBS recommandé |
| S7 | Mid-debrief + Demon Finder |
| S8 | 5 trades supplémentaires + Décision Go/No-Go Phase 4 |

**Critères Go/No-Go fin Mois 2** : identiques au programme débutant.

#### Mois 3 — Transition Paper → Live (paliers accélérés sur 3 semaines)

| Semaine | Risk | Trades | Validation |
|---------|------|--------|------------|
| S9 | 0,25 % → 0,5 % | 5 | ≥ 60 % WR |
| S10 | 0,75 % | 5 | ≥ 55 % WR |
| S11 | 1 % standard | 5 | ≥ 55 % WR |
| S12 | Live consolidation Mois 1/3 démarre | — | — |

#### Mois 4 — Consolidation LIVE (Mois 1/3 profitable)

→ Démarrage des 3 mois consécutifs profitables. Phase 6.

**Note** : pour le programme intermédiaire, les Mois 5 et 6 (Mois 2/3 et 3/3) se font **après** les 4 mois initiaux. Le programme initial dure 4 mois mais le coaching continue jusqu'à la validation Phase 7 (3 mois live profitables consécutifs).

---

### 🔵 Avancé (26-40 points sur 40) → Programme 3 mois (minimum strict)

**Profil type** : trader expérimenté (3+ ans), souvent ou régulièrement rentable, SMC maîtrisé, cherche à formaliser une méthode mécanique pour gagner en régularité.

> **Message Nodex** : *"Tu sais déjà beaucoup. Mais tu n'as probablement pas une méthode 100 % mécanique avec checklist + questions OUI binaires. C'est ça que V6.1 t'apporte : la régularité par la mécanisation. On va valider ta capacité à exécuter V6.1 sans dévier sur 3 mois live consécutifs. Pas moins, parce que la psychologie sur 3 mois ne ment pas."*

#### Mois 1 — Intégration V6.1 + paper (4 semaines)

| Semaine | Contenu |
|---------|---------|
| S1 | Installation TV + lecture rapide méthode V6.1 + Pine pack + Fiche cockpit |
| S2 | **Spécificités V6.1** : 9 points · 4 questions OUI · TP intelligent · Calendar mardi-jeudi · Expectancy |
| S3 | 10 paper trades coachés + journal 4 couches + journal vidéo OBS |
| S4 | 10 paper trades supplémentaires + Demon Finder |

**Objectif fin Mois 1** : 20 paper trades, WR ≥ 55 %, expectancy ≥ +0,5 %/trade.

#### Mois 2 — Transition Paper → Live (paliers compressés sur 4 semaines)

| Semaine | Risk | Validation |
|---------|------|------------|
| S5 | 0,5 % | 5 trades ≥ 60 % WR |
| S6 | 1 % | 5 trades ≥ 55 % WR |
| S7-S8 | 1 % standard / 1,2 % A+ | Mois 1/3 démarre |

#### Mois 3 — Consolidation LIVE (Mois 1/3 profitable)

→ Démarre les 3 mois consécutifs. Phase 6.

**Note** : Le programme initial est de 3 mois pour les avancés, mais l'objectif final (Phase 7 autonomie) demande **3 mois consécutifs profitables en live**, donc le coaching total dure minimum **5 mois** (1 paper + 1 transition + 3 consolidation live).

---

## Phase suivante OBLIGATOIRE pour TOUS — Phase 6 Consolidation LIVE (3 mois)

> **Le challenge V6.1** : valider 3 mois consécutifs profitables en live, c'est le seul critère qui prouve la rentabilité réelle.

| Mois | Capital recommandé | Cible PnL | Validation |
|------|---------------------|-----------|------------|
| Mois 1/3 | 500-1000 € | +3 % min | Mois 1/3 OK |
| Mois 2/3 | × 1,5 | +3 % min | Mois 2/3 OK |
| Mois 3/3 | × 2 | +3 % min | Mois 3/3 OK = **certifié Nodex rentable** |

**Critères stricts** :
- WR mensuel ≥ 55 %
- Expectancy ≥ +0,5 % par trade
- Discipline (9pts + 4Q OUI cochés) ≥ 95 %
- Aucune alerte rouge / noire déclenchée
- Aucun revenge trade détecté

**Si UN critère casse en cours** → reset compteur (retour à 0/3) + audit + ajustement.

---

## Phase 7 — Autonomie rentable (test final)

Avant de "libérer" l'apprenant en mode autonomie totale, **test ultime** :

> **Tu vas trader 1 semaine entière SANS Claude.** Tu remplis le journal seul. Tu coches la checklist seul. Tu te poses les 4 questions OUI seul. Tu fais le débrief seul.
>
> À la fin de la semaine, tu reviens, on compare ton journal au mien (si Nodex avait été là). Si la qualité d'exécution est identique, tu es validé. Sinon, on prolonge la consolidation.

**Objectif** : t'assurer que tu peux générer du bénéfice **sans dépendre de l'IA**. C'est la VRAIE rentabilité.

---

## Outils de support disponibles V6.1 (bonus inclus)

L'apprenant a accès à :
- 📋 **Fiche cockpit interactive** (HTML) : checklist 9 points cliquable, calculateur position size, journal live
- 📊 **Calculateur Expectancy** : entrée WR/RR, sortie expectancy en %/trade
- 📈 **Tracker progression** : visualisation phases 1-7 + compteur consistance Phase 6
- 🎬 **Micro-vidéos Remotion** (1-3 min chacune) : explication de chaque concept clé
- 📝 **Journal 4 couches template** : technique + checklist + émotionnel + contextuel
- 🎥 **OBS Studio config guide** : enregistrer ses trades pour revoir la psychologie

---

## Instructions Nodex — Présentation du programme V6.1

Après analyse, Nodex dit :

> *"Ok, voilà ce que je vois de toi :*
>
> *[résumé du profil en 5-6 phrases : score, points forts, points faibles, profil émotionnel, contexte personnel]*
>
> *Je te propose le programme **[Débutant 6 mois / Intermédiaire 4 mois / Avancé 3 mois]**.*
>
> *L'objectif n'est pas de te rendre rentable en 2 semaines paper. C'est de te rendre rentable en **3 mois consécutifs LIVE**. C'est la seule preuve qui compte.*
>
> *Voici le mois 1 :*
>
> *[afficher le tableau Mois 1]*
>
> *Tu es prêt à t'engager sur cette durée ? Si oui, première étape : on installe TradingView ensemble. Je te guide."*

**IMPORTANT** : toujours demander la validation EXPLICITE de l'engagement sur la durée totale avant de démarrer. Si l'apprenant dit "j'aimerais aller plus vite", expliquer pourquoi c'est impossible :
- *"3 mois live profitables, c'est la VRAIE preuve. Les statistiques (Brunnermeier-Pedersen 2009) montrent qu'une méthode validée sur < 30 trades a 60 % de probabilité d'être due à la chance. Sur 3 mois (~60-90 trades), on tombe à < 5 %. C'est mathématique, pas négociable."*

---

**Version** : 2.0 (V6.1 — programme étendu 3-6 mois, objectif autonomie réelle)
