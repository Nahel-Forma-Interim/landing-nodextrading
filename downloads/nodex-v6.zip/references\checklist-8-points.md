# Checklist pré-trade V6.1 (9 points + 4 questions OUI)

> *"Tout devrait être rendu aussi simple que possible, mais pas plus simple."* — **Albert Einstein**
>
> *"Les meilleurs traders prennent peu de positions, mais avec une conviction totale."* — **Stanley Druckenmiller** (Duquesne Capital)

**Évolution V6.0 → V6.1** : on passe de 8 à 9 points (ajout Continuation/Reversal) et de 3 à 4 questions OUI (ajout question psy).

**Règle hard rule** : si UNE seule des 4 questions OUI = NON → **SKIP**, peu importe le score.
**Règle scoring** : 9/9 = A+ · 8/9 = A · 7/9 = B (paper only) · ≤ 6 = SKIP.

---

## LES 9 POINTS V6.1

### 🌐 BLOC 1 — Contexte (4 points)

- [ ] **① Session valide** : Londres (9h-12h Paris) OU NYAM (14h30-17h Paris) ⚠️ **HARD RULE**
- [ ] **② Jour autorisé** : mardi/mercredi/jeudi (plein risk) OU lundi/vendredi (demi-risk 0,5 %) ⚠️ **HARD RULE V6.1**
- [ ] **③ D1 bullish + Weekly bullish + BTC pas en dump** ⚠️ **HARD RULE**
- [ ] **④ Pas de news rouge ±30 min** (ForexFactory.com / Coinmarketcal.com)

### 📐 BLOC 2 — Setup (3 points)

- [ ] **⑤ Fibo M15 tracé** + prix actuellement DANS la zone discount (sous 0,5)
- [ ] **⑥ POI identifié dans le discount** : FVG OU OB sous le 0,5 Fibo M15 ⚠️ **HARD RULE**
- [ ] **⑦ Sweep valide DANS la zone POI** : casse + mèche ≥ 2× corps + close au-dessus ⚠️ **HARD RULE**

### 🕯️ BLOC 3 — Confirmation + Risk + Contexte avancé (2 points)

- [ ] **⑧ Bougie de confirmation clôturée au-dessus du high du sweep + RR ≥ 2,5:1 + risk ≤ 1,2 %** ⚠️ **HARD RULE**
- [ ] **⑨ NOUVEAU V6.1 — Continuation (HH+HL en cours sur D1) ?** Si OUI = mode A+ · Si Reversal = mode A standard ou paper

---

## LES 4 QUESTIONS OUI V6.1 (binaires, à se poser AVANT de cliquer "buy")

> Reformulation simple des hard rules — l'apprenant DOIT répondre OUI aux 4 :

### ① Suis-je dans une session ET un jour autorisés ?
- Londres 9h-12h Paris ✅
- NYAM 14h30-17h Paris ✅
- Mardi/mercredi/jeudi → plein risk ✅
- Lundi/vendredi → demi-risk 0,5 % uniquement ✅
- Hors session ou samedi/dimanche → **NON → SKIP**

### ② Le sweep est-il SOUS le 0,5 Fibo M15 ET sur un POI (FVG ou OB) ?
- Oui dans le discount ✅
- Oui touche un POI valide ✅
- Si l'un des 2 manque → **NON → SKIP**

### ③ La bougie de confirmation a-t-elle CLÔTURÉ au-dessus du high du sweep ?
- Oui clôture au-dessus du high du sweep ✅
- Encore en cours → **ATTENDRE** la clôture
- Clôture sous le high → **NON → SKIP**

### ④ NOUVEAU V6.1 — Si je perds ce trade aujourd'hui (−1 % capital), je dors quand même bien ce soir ?
- Oui, la perte est acceptable émotionnellement ✅
- Non, ça me stresse → **TAILLE TROP GROSSE → réduire à 0,5 %**
- Issue de Mark Douglas (*Trading in the Zone*) : si la perte t'empêche de dormir, l'exécution sera dégradée par la peur.

**Si UNE seule = NON → TU NE TRADES PAS. Pas de débat.**

---

## 🚫 LES 6 HARD RULES V6.1 (override absolu)

Si UNE seule manque → grade = SKIP, peu importe le score :

1. ❌ **Hors session Londres ou NYAM** (heure de Paris)
2. ❌ **Samedi ou dimanche** (pas de trading weekend, jamais)
3. ❌ **D1 bear OU Weekly bear OU BTC en dump franc**
4. ❌ **Pas de POI (FVG ni OB) dans le discount sous 0,5 Fibo M15**
5. ❌ **Sweep "vide"** (sans confluence POI) OU **bougie de confirmation pas clôturée au-dessus du high du sweep**
6. ❌ **Risk > 1,2 % OU RR < 2:1 OU 2 SL consécutifs aujourd'hui OU 3 trades déjà pris**

---

## 🧠 Auto-évaluation psy (hors checklist mais OBLIGATOIRE)

Avant CHAQUE trade, vérifie en silence :
- ① Dormi 7h+ ?
- ② Pas en boucle post-perte ?
- ③ Trade prévu dans le plan du jour (max 3) ?
- ④ NOUVEAU V6.1 — Mardi/mercredi/jeudi ? Si lundi/vendredi → demi-risk obligatoire

Si UN des 4 KO → **SKIP**, peu importe le grade.

---

## 📊 Scoring V6.1 → action concrète

| Score | Grade | Risk (mar-jeu) | Risk (lun-ven) | RR min | Position | Action |
|-------|-------|----------------|------------------|--------|----------|--------|
| 9/9 | **A+** | 1,2 % | 0,5 % | 3:1 | 100 % | **Entrer en confiance** (One Shot One Kill) |
| 8/9 | **A** | 1 % | 0,5 % | 2,5:1 | 100 % | Entrer standard |
| 7/9 | **B** | 0,5 % | — | 2:1 | 50 % | **PAPER seulement** |
| ≤ 6 | **C** | — | — | — | — | **SKIP IMPÉRATIF** |

**Distribution attendue sur 30 trades V6.1** : ~15 % A+ · ~35 % A · ~25 % B · ~25 % SKIP.

---

## 🔄 Différences clés V6.0 → V6.1 (rappel)

| Élément | V6.0 | V6.1 |
|---|---|---|
| Nb points checklist | 8 | **9** (+ Continuation/Reversal) |
| Nb questions OUI | 3 | **4** (+ question psy) |
| Hard rules | 5 | **6** (+ jour weekend interdit explicite) |
| Filtre jours | (non) | **Mardi-jeudi plein risk · lun-ven demi-risk** |
| TP | trailing fixe | **MIN(trailing, PDH/PDL opposé − 0,2 %)** |
| Top-down | D1 → M15 | **W1 → D1 → M15** (weekly bias ajouté) |
| Métrique-clé | WR | **Expectancy** |

---

## Mantra de vérification V6.1 (à se réciter avant chaque trade)

> **"9 points. 2 POI. 4 questions OUI."**
>
> **"Mardi-mercredi-jeudi : plein risk. Le reste : demi-risk."**
>
> **"Si je perds ce trade, je dors quand même bien."**
>
> **"1 trade A+ par jour. Et je rentre chez moi."**

— **Nodex V6.1**
