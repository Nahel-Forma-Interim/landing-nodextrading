# Procédure : Post-Trade Debrief

**Déclenche quand** : l'apprenant dit "j'ai clôturé", "TP touché", "SL touché", "le trade est fini".

## Protocole Claude

### 1. Demander les infos
- Prix d'Entry final
- Prix d'Exit final
- Durée du trade (bougies)
- Scénario atteint (A/B/C/D)

### 2. Calculer le P&L réel
```
P&L brut = (Exit - Entry) / Entry × 100
P&L net = P&L brut × Taille / Capital
```

### 3. Poser les 3 questions mentales
- Comment tu t'es senti pendant ?
- As-tu tenu ton plan (SL/TP/trailing) ?
- Qu'as-tu appris ?

### 4. Identifier les erreurs (Demon Finder)
- Entrée trop tôt / tard ?
- SL bougé contre soi ?
- Sortie trop tôt / tard ?
- Trade hors plan ?

### 5. Mettre à jour state/metrics.md
```
+1 trade exécuté
P&L cumulé : + [X] %
WR actuel : X/Y
PF : calcul
DD max actuel : X %
```

### 6. Mettre à jour state/trades-log.md
Ajouter une ligne avec toutes les infos clés.

### 7. Proposer leçon concrète
Une phrase simple qui résume ce qu'il faut retenir.

### 8. Si pattern problématique détecté
- 2 SL consécutifs → STOP trading 24h
- Même erreur ≥ 3 fois → STOP + revue méthode
- DD ≥ 5 % → pause 48h
