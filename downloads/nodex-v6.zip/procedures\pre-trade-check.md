# Procédure : Pre-Trade Check

**Déclenche quand** : l'apprenant dit "j'ai un setup", "je pense entrer", "regarde ce chart", ou similaire.

## Protocole Claude (dans l'ordre)

### 1. Demander les infos manquantes
- Actif + prix actuel
- Entry envisagée
- Niveau du low sweepé
- Contexte HTF (D1/H4 bullish ?)

### 2. Vérifier les 3 critères du sweep
```
□ Niveau significatif cassé ?
□ Mèche ≥ 2× corps bougie ?
□ Close au-dessus du niveau ?
```
Si 1 manque → **refuser le trade**, expliquer pourquoi.

### 3. Calculer les paramètres
```
Entry = close bougie 2
SL = sous mèche sweep + 0,2% buffer
Risk% = (Entry - SL) / Entry × 100
RR = (TP2 - Entry) / (Entry - SL)
```

### 4. Valider la qualité du setup
- Volume sweep ≥ 3× moyenne ? → A+
- Score actif ≥ 4/5 (filtres-asset.md) ?
- RR ≥ 2,5:1 ?
- Risk ≤ 1,2% ?

### 5. Si tout OK → valider + donner les niveaux
```
ENTRY : [close bougie 2]
SL    : [prix]  (−X%)
+1,5% : [prix]  ← bouger SL à BE
+2,5% : [prix]  ← bouger SL à +1,5%
+3%   : [prix]  ← SORTIE TOTALE
```

### 6. Rappeler les alertes TV à placer
- Alerte +1,5%
- Alerte +2,5%
- Alerte TP2 (+3%)

### 7. Rappeler les règles mentales
- Pas bouger le SL contre soi
- Respecter trailing même si stress
- Noter dans Nodex Journal dès entrée
