# Méthode V6 — Référence complète (Simplicité Radicale Institutionnelle)

> **V5.3 → V6** : on garde tout ce qui marche (sweep, trailing, risk strict) ET on **dégage** tout ce qui paralyse :
> - **2 POI seulement** (FVG + OB) au lieu de 6
> - **2 timeframes** (D1 + M15) au lieu de 4
> - **1 fibo** (M15) au lieu de 2
> - **1 bougie de confirmation** au lieu de 2
> - **8 points checklist** au lieu de 22
> - **3 questions OUI** binaires avant chaque entry

> *"Tout devrait être rendu aussi simple que possible, mais pas plus simple."* — **Albert Einstein**

> *"Une méthode simple appliquée à 100 % bat toujours une méthode complexe appliquée à 60 %."* — **Nodex** (principe fondateur V6)

---

## Le setup V6

**Nom** : SMC Simplicité Radicale (One Shot One Kill)
**TF d'exécution** : M15
**Sessions** : **Londres (9h-12h Paris) + NYAM (14h30-17h Paris)**
**Direction** : Long only spot
**Watchlist** : ARB + PENDLE (focalisée)
**Max trades/jour** : 3 (idéalement 1 si A+)

---

## Les 2 POI (cœur de V6)

V5.3 avait 6 POI. V6 en garde 2 — les plus mécaniques, les plus visuels, ceux que **n'importe qui reconnaît en 5 secondes** :

| Rang | POI | Force | Description visuelle |
|------|-----|-------|----------------------|
| 1 | **FVG** | ⭐⭐⭐⭐⭐ | Fair Value Gap. **Trou de prix** entre 3 bougies : low[i] > high[i-2]. Tu le vois en 1 seconde. |
| 2 | **OB** | ⭐⭐⭐⭐⭐ | Order Block. **Dernière bougie baissière** avant une grosse impulsion bullish. Tu la vois aussi en 1 seconde. |

**Tout le reste (BPR, BB, IFVG, BISI) → DÉGAGÉ.**

> *"Les zones de prix où s'accumulent les ordres stop attirent mécaniquement les flux institutionnels."*
> — Recherche **SEC** sur le high-frequency trading, 2014

C'est pour ça que les FVG et OB fonctionnent : ce sont les zones où les algorithmes des banques d'investissement vont **chasser la liquidité**.

---

## Les 4 étapes mécaniques V6 (vs 8 en V5.3)

### Étape 0 NOUVEAU V6.1 — Weekly bias (chaque dimanche soir, 30 sec)

Avant que la semaine commence, regarder **W1** (timeframe weekly) sur ARB et PENDLE :

- **Weekly bullish** (HH+HL hebdo) → toute la semaine, je ne trade QUE les longs
- **Weekly bearish** (LL+LH hebdo) → SKIP toute la semaine
- **Weekly range** → mode prudent demi-risk + uniquement A+

C'est le filtre macro le plus puissant. Recherche **Brunnermeier-Pedersen** (2009) : les biais hebdomadaires expliquent 60-70 % des mouvements directionnels intra-semaine.

### Étape 1 — Bias D1 + BTC (5 secondes max)

**1 seul timeframe pour le bias** : D1.

- D1 bullish = **HH + HL** (au moins 2 sur les 5 dernières bougies)
- BTC D1 bullish ou neutre (pas en dump franc)
- Pas de news rouge ±30 min (vérifier ForexFactory.com ou Coinmarketcal.com)
- **Marquer PDH + PDL** (Previous Day High + Low) → ce sont tes cibles TP intelligentes
- **Marquer Asia High + Asia Low** (range 00h-08h Paris) → souvent breakout par Londres

Si D1 bear ou BTC en dump → **SKIP TOUT.** Tu fais autre chose, tu reviens demain.

> *"La première règle du trading : ne pas perdre. La deuxième règle : ne jamais oublier la première."*
> — **Warren Buffett** (Berkshire Hathaway)

### Étape 2 — Tracer Fibo M15 (10 secondes max)

**1 seul fibo** : sur le dernier swing impulsif M15 (low → high).

- Identifier la zone **discount** (sous le 0,5)
- Identifier la zone **OTE** (entre 0,62 et 0,79) — bonus si setup tombe dedans

Si le prix est **au-dessus du 0,5** (premium) → **ATTENDRE** qu'il revienne en discount. Pas de trade en premium.

### Étape 3 — Identifier le POI dans le discount (10 secondes max)

Cherche un **FVG** ou un **OB** dans la zone discount (sous 0,5 Fibo M15).

- FVG = trou entre bougies, marqué visuellement
- OB = dernière bougie rouge avant impulsion verte

**Hard rule** : aucun FVG ni OB dans le discount → **SKIP**.

### Étape 4 — Attendre le SWEEP + 1 bougie de confirmation

Le prix doit :

1. **Balayer** un low significatif (Asia Low, PDL, low récent) **DANS la zone POI**
2. La mèche du sweep **mèche ≥ 2× corps** (sinon c'est pas un vrai sweep)
3. **Close au-dessus** du niveau balayé
4. **Bougie suivante clôture au-dessus du high de la bougie de sweep** ← CONFIRMATION

**Différence majeure V5.3 vs V6** : V5.3 = 2 bougies de confirmation. V6 = **1 bougie suffit** (si sweep propre + close au-dessus du high).

> *"La liquidité de marché et la liquidité de financement se renforcent mutuellement."*
> — **Brunnermeier & Pedersen**, "Market Liquidity and Funding Liquidity", *Review of Financial Studies*, 2009

C'est exactement ce que fait un sweep : les institutions cassent un niveau de liquidité (stop-loss agglomérés) pour générer du carburant pour le mouvement suivant.

---

## Les 4 QUESTIONS OUI V6.1 (binaires, non négociables)

> **Évolution V6.1** : on passe de 3 à 4 questions. La 4e est PSYCHOLOGIQUE et garantit que la taille de position est saine.

Avant chaque entry, l'apprenant DOIT répondre OUI aux 4 :

### ① Suis-je dans une session autorisée ET un jour autorisé ?
- Londres : 9h-12h heure de Paris ✅
- NYAM : 14h30-17h heure de Paris ✅
- **Jour : mardi, mercredi ou jeudi** (mode plein risk 1 %) ✅
- Lundi ou vendredi → mode demi-risk 0,5 % seulement (consolidation post-weekend / institutionnels qui ferment)
- Hors session ou samedi/dimanche → **NON → SKIP**

### ② Le sweep est-il SOUS le 0,5 Fibo M15 ET sur un POI (FVG ou OB) ?
- Oui sweep dans le discount ✅
- Oui sweep touche un FVG ou OB ✅
- Si l'un des 2 manque → **NON → SKIP**

### ③ La bougie de confirmation a-t-elle CLÔTURÉ au-dessus du high du sweep ?
- Oui clôture validée ✅
- Non encore en cours → **ATTENDRE** (pas d'entry sur bougie en cours)
- Non clôture sous le high → **NON → SKIP**

### ④ NOUVEAU V6.1 — Si je perds ce trade aujourd'hui, je dors quand même bien ce soir ?
- Oui, la perte (−1 % capital max) est acceptable émotionnellement ✅
- Non, ça me stresse → **TAILLE TROP GROSSE → réduire à 0,5 % et re-évaluer**
- Question issue de Mark Douglas (*Trading in the Zone*) : la qualité d'exécution est inversement proportionnelle à la peur de perdre.

**Si UNE seule = NON → TU NE TRADES PAS.**

> *"Si tu peux créer un état mental qui n'est pas affecté par le comportement du marché, la lutte cessera d'exister."*
> — **Mark Douglas**, *Trading in the Zone*

---

## Étape 5 — Placer le trade

- **Entry** = close de la bougie de confirmation
- **SL** = sous la mèche du sweep + buffer 0,2 %
- **Risk** = 1 % standard / 1,2 % max si setup A+ (mardi-jeudi) / 0,5 % lundi-vendredi
- **TP** = règle intelligente (PDH/PDL opposé) puis trailing 3 paliers (cf. ci-dessous)
- **Vérifier RR ≥ 2,5:1** sinon **SKIP**

---

## NOUVEAU V6.1 — TP intelligent sur liquidité opposée

> **Principe** : un sweep prend la liquidité d'un côté → le marché va **chercher la liquidité opposée** (PDH si on a sweepé un PDL en long).
> Donc le TP doit être placé **AVANT** la liquidité opposée, pas seulement basé sur un % fixe.

### Règle V6.1
```
TP final = MIN(trailing fixe +3 %, PDH_proche − buffer 0,2 %)
```

Si le PDH est à +2,1 % de l'entry → TP = +1,9 % (sortie totale avant que le marché tape le PDH et fasse un sweep inversé).
Si le PDH est à +5 % (loin) → TP = +3 % standard (trailing).

### Pourquoi
Recherche **SEC** (2014) sur high-frequency trading : *"Les zones de prix où s'accumulent les ordres stop attirent mécaniquement les flux institutionnels."* Donc en visant la liquidité opposée, tu sors AVANT que les institutionnels la chassent et que le prix s'inverse.

### En pratique
- Marquer **PDH (Previous Day High)** et **PDL (Previous Day Low)** en M15 chaque matin avant 9h
- Marquer **Asia High** et **Asia Low** (range 00h-08h Paris)
- Calculer la distance entry → liquidité opposée
- Régler le TP automatique sur TradingView en conséquence

---

## NOUVEAU V6.1 — Reversal vs Continuation (9e checkbox optionnelle)

> **Statistiques V5.3 backtest interne** : continuations = ~65 % WR · reversals = ~45 % WR. **Énorme différence.**

### Définitions
- **Continuation** : le marché est déjà en tendance (HH+HL). Le sweep prend une liquidité de retracement, puis continue. **WR élevé.**
- **Reversal** : le marché vient de casser sa structure (MSS = Market Structure Shift). Le sweep est le premier signe de retournement. **WR faible.**

### Règle V6.1
- **Mode A+ (risk 1,2 %)** = uniquement en **continuation** (HH+HL clair sur D1 + structure haussière sur M15)
- **Mode A (risk 1 %)** = continuation OU reversal validé par 2 bougies de confirmation au lieu d'1
- **Mode B (paper only)** = reversal sans contexte fort

→ Ajoute une **9e checkbox** : *"Suis-je en continuation (HH+HL en cours) ou reversal (premier MSS) ?"*

---

## Gestion TP trailing par paliers (V6.1 = trailing + cap PDH/PDL)

100 % de la position gardée. SL déplacé par paliers :

| Palier | Prix atteint | Action |
|--------|--------------|--------|
| 1 · ENTRY | 0 % | SL initial à **−1 %** |
| 2 · BE | **+1,5 %** | SL bouge à **BE (0 %)** |
| 3 · Mid-trail | **+2,5 %** | SL bouge à **+1,5 %** |
| 4 · SORTIE | **+3 %** | **Sortie totale** |

### 4 scénarios

| Scénario | Description | Résultat |
|----------|-------------|----------|
| A · Parfait | +3 % atteint | **+3,0 %** 🏆 |
| B · Partiel +2,5 % | +2,5 % puis reverse | **+1,5 %** ✅ |
| C · Partiel +1,5 % | +1,5 % puis reverse | **0 %** 🟡 (BE) |
| D · Reverse direct | N'atteint jamais +1,5 % | **−1 %** ❌ |

**Piège** : bouger le SL à temps. Toujours alertes TradingView à +1,5 % et +2,5 %.

---

## Risk management V6.1 (NON NÉGOCIABLE)

| Règle | Valeur |
|-------|--------|
| Risk / trade (mardi-jeudi A+) | **1,2 % max** |
| Risk / trade (mardi-jeudi standard) | **1 %** |
| Risk / trade (lundi ou vendredi) | **0,5 % max** (jours faibles) |
| RR minimum | **2,5:1** (RR < 2:1 = SKIP) |
| **Max trades / jour** | **3** (One Shot One Kill mindset) |
| **Jours autorisés** | **mardi · mercredi · jeudi** (best). Lundi + vendredi en demi-risk. **Samedi + dimanche = JAMAIS.** |
| Stop 2 SL consécutifs | **→ 24h** |
| DD alert 5 % / 5 trades | **→ pause 48h** |
| DD stop 10 % | **→ arrêt complet** |
| **Expectancy minimum** (par 30 trades) | **≥ +0,5 % par trade en moyenne** |

> *"La règle la plus importante du trading est de jouer une grande défense, pas une grande attaque."*
> — **Paul Tudor Jones** (Tudor Investment Corporation, fondateur)

### Formule taille position
```
Taille = Capital × Risk% ÷ (Entry − SL) × Entry
```

Exemple : Capital 2 000 € · Risk 1 % · Entry 0,1280 · SL 0,1272 (0,62 %)
→ Taille = 2 000 × 1 % ÷ 0,62 % × 0,1280 = **413 €** en position

---

## Sessions V6 (heures de Paris)

V6 trade **2 fenêtres de Kill Zone strictes** :

### Kill Zone London (9h-12h Paris)
- Logique : la session asiatique accumule la liquidité (00h-08h), Londres ouvre, vient sweeper
- Setups possibles : sweep Asia Low, sweep PDL
- Volume institutionnel London = excellent

### Kill Zone NYAM (14h30-17h Paris)
- Logique : NY rejoint la liquidité European/London
- Setups possibles : sweep High/Low London, sweep PDH/PDL
- Volume maximal global

> *"Le volume institutionnel se concentre dans 3 fenêtres mondiales : ouverture Tokyo, ouverture Londres, ouverture New York."*
> — Études flux Bloomberg sur 10 ans

**Règle d'or** : **zéro trade en dehors de ces 2 fenêtres.** Pas une seule fois. Jamais.

---

## Validation V6 (à venir)

### Backtest préliminaire prévu
- 30 trades minimum sur ARB + PENDLE
- Sessions Londres + NYAM
- Critères validation : WR ≥ 55 %, PF ≥ 1.8, DD ≤ 10 %

### Live (à venir après validation backtest)
- Capital 500 € max au démarrage
- Paliers risk : 0,25 % → 0,5 % → 1 %
- Phase 5 transition Paper → Live

---

## Différences clés V5.3 → V6 → V6.1 (le shift simplicité + intelligence)

| Élément | V5.3 | V6.0 | V6.1 (actuelle) |
|---|---|---|---|
| **Checklist** | 22 points | 8 points | **9 points** (+ Continuation/Reversal) |
| **POI utilisés** | 6 | 2 | **2** (FVG + OB) |
| **Top-down** | D1→H4→H1→M15 | D1→M15 | **W1→D1→M15** (weekly bias ajouté) |
| **Fibo** | H1 + M15 | M15 seulement | **M15 seulement** |
| **Confirmation** | 2 bougies | 1 bougie | **1 bougie** |
| **Sessions** | London + NYAM | Londres + NYAM | **Londres + NYAM** + filtre **mardi-jeudi** |
| **Questions OUI** | — | 3 | **4** (+ question psy "je dors quand même bien") |
| **TP** | trailing fixe +3 % | trailing fixe +3 % | **MIN(trailing +3 %, PDH/PDL opposé − 0,2 %)** |
| **Risk lundi/vendredi** | 1 % standard | 1 % standard | **0,5 % (demi-risk jours faibles)** |
| **Métrique-clé suivie** | WR | WR | **Expectancy** (= WR×gain − (1-WR)×perte) |
| **Inspirations** | Mix | Institutionnel + recherche | **Institutionnel + recherche académique** |

---

## NOUVEAU V6.1 — Expectancy : la métrique qui compte vraiment

**Formule** :
```
Expectancy = (WR × Gain moyen) − ((1 − WR) × Perte moyenne)
```

### Exemples concrets

| Scénario | WR | RR | Expectancy | Verdict |
|----------|-----|-----|------------|---------|
| V6 standard | 50 % | 2,5:1 | (0,5 × 2,5) − (0,5 × 1) = **+0,75 %** par trade | ✅ Profitable |
| V6 paper bon | 60 % | 2,5:1 | (0,6 × 2,5) − (0,4 × 1) = **+1,1 %** par trade | ✅✅ Très profitable |
| Trader émotionnel | 70 % | 1:1 | (0,7 × 1) − (0,3 × 1) = **+0,4 %** par trade | 🟡 Profitable mais fragile |
| Mauvais setup | 40 % | 2:1 | (0,4 × 2) − (0,6 × 1) = **+0,2 %** par trade | 🟠 À peine profitable |
| Désastre | 50 % | 1:1 | (0,5 × 1) − (0,5 × 1) = **0** | ❌ Break-even, pas profitable |

### Règle V6.1
**Si après 30 trades l'expectancy ≥ +0,5 %** → tu es rentable mathématiquement, peu importe le WR.
**Si expectancy < +0,3 %** → revue méthode, soit le RR est trop bas, soit le WR est trop bas, soit les deux.

→ Apprends à **arrêter de paniquer après 3 pertes consécutives** : si ton expectancy reste positive sur 30 trades, tu es OK.

---

## NOUVEAU V6.1 — Affinage entry M5 ou M3 (Phase 6+ uniquement)

> **Réservé aux apprenants ayant validé 3 mois de discipline parfaite V6.**

Une fois le setup identifié sur **M15** (sweep + POI dans discount), descendre sur **M5** ou **M3** pour affiner l'entry exacte :

- **Sur M15** : SL ~0,6 % en moyenne, RR ~2,5:1
- **Avec entry M5** : SL ~0,4 %, RR ~3,75:1 (×1,5 amélioration)
- **Avec entry M3** : SL ~0,3 %, RR ~5:1 (×2 amélioration)

Comment :
1. Identifier le setup macro sur M15 (V6 standard)
2. Descendre sur M5/M3 et chercher un MINI-sweep + mini-POI dans la zone M15
3. Entrée sur close confirmation M5/M3
4. SL plus serré → RR mécaniquement supérieur

**Risque** : faux signaux plus fréquents sur M5/M3. Réservé aux traders disciplinés.

---

## NOUVEAU V6.1 — Journal vidéo (recommandé)

**Outil gratuit** : OBS Studio (https://obsproject.com/).

Configuration : enregistrer l'écran TradingView pendant tout le trade (entry → SL/TP). Le replay vidéo capture **la psychologie en temps réel** (tremblement, hésitation, panic close) que le journal écrit ne capture pas.

→ Recommandé en Phase 5 (transition live) et Phase 6 (consolidation). Optionnel en Phase 7.

---

## Mantra V6

> **"8 points. 2 POI. 3 questions OUI. C'est tout."**
>
> **"Si tu réfléchis 10 minutes, c'est PAS un setup."**
>
> **"One Shot One Kill : 1 trade A+ par jour, et tu rentres chez toi."**

— **Nodex V6**
