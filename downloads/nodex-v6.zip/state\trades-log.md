# Log des trades V6

> **Format** : 1 ligne par trade clôturé · ajout chronologique
> **Template neutre** : à remplir au fur et à mesure des trades de l'apprenant.

---

## Trades

| # | Date | Actif | Setup (FVG/OB) | Entry | SL | Exit | Scénario | P&L % | Grade | Leçon |
|---|------|-------|----------------|-------|-----|------|----------|-------|-------|-------|
| (aucun trade encore) | — | — | — | — | — | — | — | — | — | — |

---

## Stats par semaine

### Semaine 1
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —
- Discipline (% checklist 8 pts cochée) : —

### Semaine 2
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —
- Discipline : —

### Semaine 3
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —
- Discipline : —

### Semaine 4
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —
- Discipline : —

---

## Légende grades V6

| Grade | Score | Action |
|-------|-------|--------|
| **A+** | 8/8 | Entrer en confiance (One Shot One Kill) |
| **A** | 7/8 | Entrer standard |
| **B** | 6/8 | PAPER seulement |
| **C** | ≤ 5/8 | SKIP impératif |

---

## Légende scénarios trailing

| Scénario | Description | Résultat |
|----------|-------------|----------|
| A · Parfait | +3 % atteint | +3,0 % |
| B · Partiel +2,5 % | +2,5 % puis reverse | +1,5 % |
| C · Partiel +1,5 % | +1,5 % puis reverse | 0 % (BE) |
| D · Reverse direct | N'atteint jamais +1,5 % | −1 % |

---

**Règle Nodex** : à remplir SYSTÉMATIQUEMENT après chaque trade. Sans journal = pas de progrès.
