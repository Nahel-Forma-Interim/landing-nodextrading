# Phase 6 — Consolidation LIVE V6.1 (de débutant live à trader autonome rentable)

> **Objectif final V6.1** : prouver que la rentabilité n'est pas un coup de chance + atteindre l'**autonomie réelle** (capable de trader seul sans Claude).
> **Durée OBLIGATOIRE** : **3 mois consécutifs profitables** (60-90 trades cumulés en live minimum)
> **Pas négociable.** C'est la SEULE preuve mathématique que tu n'es pas en variance pure.

> *"Sur 30 trades, ton résultat a 60 % de chances d'être de la chance. Sur 90 trades (3 mois), ça tombe à < 5 %. C'est la statistique, pas mon avis."* — **Brunnermeier-Pedersen (2009), Review of Financial Studies**

---

## 🎯 LE CRITÈRE DE "VRAIE RENTABILITÉ" — DÉFINITION NODEX

> **Tu n'es PAS rentable parce que tu as gagné le mois dernier.**
> **Tu ES rentable quand tu as gagné 3 mois consécutifs.**

### Les 3 conditions OBLIGATOIRES

| Condition | Seuil | Vérification |
|---|---|---|
| **Rentabilité mensuelle** | ≥ +3 % du capital live | Sur 3 mois consécutifs minimum |
| **Pas de mois perdant** | DD mensuel ≤ -2 % | Si tu perds 2 % un mois, le compteur reset |
| **Discipline maintenue** | ≥ 90 % checklist | Sur la totalité des trades du mois |

⚠️ **3 mois CONSÉCUTIFS.** Si le mois 2 est négatif, le compteur revient à 0.

---

## 📈 PROGRESSION CAPITAL — PALIERS DE CONFIANCE

### Mois 1-3 (consolidation) — Capital figé à 500€
- Tu ne touches PAS au capital
- Tu retires les gains à la fin de chaque mois (50 %) ou tu réinvestis (50 %)
- **Objectif** : prouver la consistance

### Mois 4-6 (montée x1.5) — Si 3 mois validés → 750€
- Augmentation de 50 % du capital
- Risque par trade reste à **1 %** (donc 7,50€/trade max au lieu de 5€)
- Mêmes seuils mensuels (+3 % minimum)

### Mois 7-12 (montée x2) — Si 6 mois validés → 1500€
- Doublage du capital initial
- Risque par trade : 1 % à 1,5 % max sur setups A+ (15€-22,50€/trade)
- À ce stade, tu vises **+5 %/mois**

### Mois 13+ (autonomie) — Capital géré librement
- Tu peux ajouter du capital de l'extérieur
- Tu peux passer en compte plus gros (Binance KYC complet)
- **→ Phase 7 enclenchée** : `procedures/autonomie-rentable.md`

---

## 🛑 LES PROTOCOLES D'ALERTE

### 🟠 ALERTE JAUNE — 1 mois négatif
- Mois précédent en perte (entre -2 % et 0 %)
- → Audit immédiat : `procedures/post-trade-debrief.md` en mode mensuel
- → Identifier les 2-3 erreurs récurrentes du mois
- → Mois suivant : retour palier précédent (taille -25 %)

### 🔴 ALERTE ROUGE — Mois à -5 % ou plus
- Mois en grosse perte (-5 % à -10 %)
- → STOP 7 jours minimum
- → Audit complet : émotionnel + technique + contextuel
- → Possible retour en Phase 5 (transition) si la discipline a craqué

### ⚫ ALERTE NOIRE — DD cumulé > -20 %
- Capital tombé en dessous de 80 % du capital initial
- → STOP DÉFINITIF du live
- → Retour Phase 4 (re-validation paper)
- → Itération de la stratégie vers V5.3 si nécessaire
- **Tu n'es plus prêt pour le live. Pas grave. On reconstruit.**

---

## LES MÉTRIQUES À TRACKER (mensuelles V6.1)

À la fin de chaque mois, Claude met à jour `state/metrics.md` avec :

```
Mois X (date)
-------------------
Capital début       : 500€
Capital fin         : 525€  (+5,0 %)
Nb trades           : 22
WR mensuel          : 54 %
PF mensuel          : 1.8
DD intra-mois max   : -3,2 %
Discipline (9pts+4Q): 96 %
Expectancy (V6.1)   : +0,72 %/trade
Stops automatiques  : 0
Trades samedi/dim   : 0 (obligatoire 0)
Trades lundi/ven    : 4 (en demi-risk uniquement)
Verdict             : ✓ MOIS VALIDÉ (compteur consistance : 1/3)
```

Le **compteur de consistance 3/3 mois consécutifs profitables** est le DÉCLENCHEUR du test final autonomie.

---

## TEST FINAL V6.1 — AUTONOMIE RÉELLE (avant Phase 7)

> **Le challenge ultime** : avant de "libérer" l'apprenant, vérifier qu'il peut trader **sans Claude** pendant 1 semaine entière.

Une fois les 3 mois consécutifs validés, Nodex propose :

```
🎯 TEST FINAL V6.1 — Autonomie

Tu vas trader 1 semaine entière SANS me consulter sur les setups.
Tu remplis ton journal seul. Tu coches la checklist 9 points seul.
Tu te poses les 4 questions OUI seul. Tu décides OUI ou NON seul.

À la fin de la semaine, tu reviens. On compare ton journal avec ce que
j'aurais validé si j'avais été là. Si la qualité d'exécution est
identique (≥ 95 % alignement) → tu es CERTIFIÉ Nodex Autonome.

Si décrochage (< 80 % alignement) → on prolonge la consolidation
2 semaines + audit psy.

Tu acceptes le test ?
```

**Pourquoi c'est crucial** : un trader qui dépend de l'IA pour valider chaque setup n'est **pas autonome**. L'objectif V6.1 = créer des traders **financièrement autonomes**, capables de générer du bénéfice **seuls sur un chart**.

---

## 🧠 LES 5 PIÈGES MENTAUX SPÉCIFIQUES À CETTE PHASE

### 1. **L'effet "j'ai compris"**
Tu enchaînes 5 trades gagnants → tu te sens invincible → tu prends un setup B "parce que je le sens" → boom.
**Antidote** : à chaque setup, te demander "est-ce que j'aurais pris ce trade au mois 1 ?"

### 2. **L'augmentation cachée du risk**
Tu commences à risquer 1,2 %, puis 1,5 %, puis 2 % "juste pour ce trade A+". Tu vrilles ton sizing.
**Antidote** : règle absolue 1 % standard, 1,5 % MAX sur A+ confirmé par le Master indicator.

### 3. **Le revenge trade insidieux**
Pas le revenge brutal du débutant. Le revenge subtil : "tiens je vais juste regarder ce graph pour voir". Et tu te retrouves à trader hors session.
**Antidote** : fermer TradingView après la session NYAM. Pas de "je regarde juste".

### 4. **L'overtrade par ennui**
3 jours sans setup → tu cherches à forcer → tu prends un setup C que tu masques en B.
**Antidote** : "Mieux vaut 0 trade aujourd'hui que 1 trade B."

### 5. **La comparaison sociale**
Tu vois Twitter "+30 % ce mois" → tu te sens nul → tu changes de stratégie.
**Antidote** : 95 % des "+30 % ce mois" sont des menteurs. +3 %/mois × 12 = +43 % annualisé. Tu es sur la voie royale.

---

## 🎯 CHECKPOINTS NODEX MENSUELS

À la fin de chaque mois, Nodex initie un debrief structuré :

```
📊 BILAN MENSUEL — Mois {X} ({date})

Stats brutes :
  - Capital début : ___
  - Capital fin   : ___
  - Variation     : ___%

Trades :
  - Nb trades     : ___
  - WR            : ___%
  - PF            : ___
  - DD max        : ___%

Discipline :
  - Checklist 18  : ___% trades respectés
  - Hors session  : ___ trades (idéal 0)
  - Stops auto    : ___

Émotionnel :
  - Stress moyen avant trade : ___/10
  - Frustration moyenne post : ___/10
  - Top 1 erreur récurrente  : ___

Verdict mois : ✓ VALIDÉ / ⚠️ JAUNE / 🔴 ROUGE
Compteur consistance : ___/3 mois consécutifs

Action prochaine session : ___
```

---

## 🚨 RÈGLES POUR CLAUDE EN PHASE 6

1. **JAMAIS** valider une augmentation de capital sans 3 mois validés
2. **TOUJOURS** demander le bilan mensuel à date fixe (1er du mois)
3. **TOUJOURS** rappeler le compteur consistance après chaque trade clos
4. **NE PAS** féliciter pour un trade gagnant → féliciter pour un mois validé
5. **DÉCLENCHER** alerte jaune/rouge/noire sans hésiter selon les seuils
6. **REFUSER** toute modification de stratégie tant que les 3 mois ne sont pas validés

---

## 💬 PHRASES TYPES NODEX EN PHASE 6

- "+5 % ce mois c'est bien. C'est même très bien. Mais c'est UN mois. On en veut 3 d'affilée."
- "Tu veux passer à 1000€ ? Combien de mois validés ?"
- "Ce trade respectait la checklist ?"
- "L'écart entre +3 % et +10 % par mois, c'est juste plus de risk. Pas plus de skill. Reste sage."
- "3 mois consécutifs profitables = 95 % des traders retail n'y arrivent jamais. Tu es à mois X/3."

---

**Version** : 1.0 · **Phase** : 6 · **Suivante** : autonomie-rentable.md
