# État actuel — Phase de l'apprenant

> Ce fichier est **vide au démarrage**. Claude (Nodex) le remplit au fur et à mesure que l'apprenant progresse.
> **Format template** : à remplir lors de l'onboarding et à chaque transition de phase.

---

## Snapshot apprenant

- **Phase actuelle** : [À DÉTERMINER lors de l'onboarding — Phase 1-7]
- **Sous-phase** : [À PRÉCISER]
- **Date démarrage formation** : [À REMPLIR : YYYY-MM-DD]
- **Statut** : [⚪ À démarrer · 🟡 En cours · 🟢 Validée · 🔴 Bloquée]

---

## Performance actuelle (si en Phase 5+)

- **Capital de départ** : [À REMPLIR]
- **Capital actuel** : [À REMPLIR]
- **PnL cumulé** : [À REMPLIR]
- **Sessions tradées** : Londres (9h-12h Paris) + NYAM (14h30-17h Paris)
- **Stratégie** : Nodex V6 (Simplicité Radicale)

---

## Compteur consistance Phase 6 (si applicable)

- **Mois 1** : [À REMPLIR] → ⏳ statut
- **Mois 2** : [À REMPLIR] → ⏳ statut
- **Mois 3** : [À REMPLIR] → ⏳ statut

**Si 3 mois consécutifs profitables** → passage Phase 7 (autonomie + capital ×1,5 puis ×2)

---

## Validation V6 backtest (Phase 3)

| Métrique | Valeur cible | Valeur apprenant |
|----------|--------------|-------------------|
| Trades exécutés | ≥ 30 | [à remplir] |
| WR (Win Rate) | ≥ 55 % | [à remplir] |
| Profit Factor | ≥ 1,8 | [à remplir] |
| Drawdown max | ≤ 10 % | [à remplir] |
| RR moyen | ≥ 2,5:1 | [à remplir] |

---

## Prochaines étapes

1. [À DÉFINIR par Nodex selon la phase actuelle]
2. [À DÉFINIR]
3. [À DÉFINIR]

---

## Seuils Go/No-Go Phase 7

- **3 mois consécutifs** avec PnL ≥ +3 % chacun
- WR mensuel moyen ≥ 55 %
- Aucune alerte rouge ou noire déclenchée
- Discipline ≥ 95 % (checklist 8 points cochée correctement)

---

## Actions Claude (Nodex) à chaque interaction

1. Vérifier `state/live-progression.md` AVANT toute analyse
2. Activer `procedures/live-coaching.md` pour analyses de setups
3. Activer `procedures/post-trade-debrief.md` après chaque trade clos
4. Mettre à jour `state/trades-log.md` (avec grade A+/A/B)
5. Mettre à jour `state/metrics.md` (stats live)
6. Adapter le ton et la profondeur à la phase actuelle de l'apprenant

---

**Version** : 1.0 template neutre · **MAJ initiale** : à la création de la licence
