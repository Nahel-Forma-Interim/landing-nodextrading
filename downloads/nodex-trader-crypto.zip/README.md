# Nodex Trader Crypto V1.0

> **Le skill formateur trader crypto pur de Nodex.**
> Différent du skill `nodex-v6` (opérateur de checklist) — celui-ci FORME un trader autonome.

---

## C'est quoi ?

Un skill Claude qui transforme Claude en **Nodex**, formateur trader crypto socratique. Quand tu actives ce skill :

1. Nodex t'accueille (FIRST-MESSAGE)
2. Te fait passer un **questionnaire diagnostic** (15 questions sur 10 blocs de connaissance)
3. Construit ton **parcours personnalisé** (1 à 12 mois selon ton niveau)
4. T'enseigne via **méthode socratique** (questions plutôt que réponses)
5. Te fait construire **TON propre edge** validé par 100+ backtests
6. Te certifie **autonome** quand tu peux trader sans Nodex

---

## Quelle différence vs Nodex V6 ?

| | Nodex V6 (opérateur) | Nodex Trader Crypto (formateur) |
|---|---|---|
| **But** | Exécuter une méthode mécanique (8 conditions) | Former un trader autonome |
| **Format** | Checklist + questions OUI/NON | Cours structuré + exercices |
| **Liberté** | Aucune | Totale |
| **Sortie** | Trader-opérateur Nodex | Trader autonome avec SA méthode |
| **Durée** | 3-6 mois | 6-12 mois |

**Tu peux utiliser les 2 en parallèle** : V6 pour exécuter pendant la formation, Trader Crypto pour comprendre vraiment.

---

## Les 10 blocs de connaissance

1. **Fondamentaux crypto** — Blockchain, BTC/ETH/alts, exchanges, custody, wallets, fees, spot vs futures
2. **Cycles & Macro** — Halving, accumulation/markup/distribution/markdown, dominance BTC, M2, ETF, DXY
3. **Structure de marché** — Tendances, ranges, S/R, swing highs/lows, MSS, CHoCH, BOS, liquidité
4. **Analyse technique classique** — Fibonacci, RSI, MACD, EMA, Bollinger, VWAP, volume profile, divergences
5. **SMC/ICT approfondi** — FVG, OB, BB, BPR, BISI, IFVG, Killzones, OTE, premium/discount, top-down
6. **On-chain analysis** — MVRV, NUPL, miners, exchange flows, addresses actives, hashrate
7. **Sentiment & flux** — Fear & Greed, funding, open interest, ratio long/short, options
8. **Fondamentaux projet** — Tokenomics, vesting, équipe, whitepaper, audits, scoring
9. **Risk management** — Expectancy, Kelly, sizing, allocation, drawdown, kill switch, journal 4 couches
10. **Construction edge perso** — TA méthode validée par 100+ backtests + paper trading + transition live

---

## Méthode pédagogique

**Socratique** : Nodex pose des questions plutôt que de donner des réponses directes. L'apprenant développe son propre raisonnement.

**Validation par exercice** : pas de quiz à choix multiples. Tu analyses des charts, scores des projets, construis des plans, backtests des hypothèses.

**Aucune méthode imposée** : V6 (8 conditions) est UNE option dans le bloc 10. Tu peux choisir une autre méthode tant qu'elle est validée par 100+ backtests avec expectancy positive.

---

## Installation

```bash
# Le skill est dans :
.claude/skills/nodex-trader-crypto/

# Auto-détecté par Claude Code à l'ouverture du projet
```

---

## Activation

Dans Claude Code, dis :
> *"Nodex, je veux apprendre le trading crypto"*

Ou n'importe quel mot-clé : `crypto`, `trading`, `Bitcoin`, `apprendre`, `formation`, `Nodex`, etc.

À la première activation, Nodex te demande ton code d'activation.

---

## Structure

```
nodex-trader-crypto/
├── SKILL.md                    ← Orchestration
├── PERSONA.md                  ← Identité Nodex formateur socratique
├── FIRST-MESSAGE.md            ← Message d'accueil
├── README.md                   ← Ce fichier
│
├── onboarding/
│   ├── questionnaire-diagnostic.md  ← 15 questions sur 10 blocs
│   └── analyse-et-programme.md      ← Construction parcours personnalisé
│
├── setup/
│   ├── activation-protocol.md
│   └── test-codes.md (interne)
│
├── blocs/                      ← LE COEUR — 10 blocs pédagogiques
│   ├── 01-fondamentaux/
│   ├── 02-cycles-macro/
│   ├── 03-structure-marche/
│   ├── 04-analyse-technique/
│   ├── 05-smc-ict/
│   ├── 06-on-chain/
│   ├── 07-sentiment-flux/
│   ├── 08-fondamentaux-projet/
│   ├── 09-risk-management/
│   └── 10-edge-perso/
│
├── procedures/
│   └── coaching-socratique.md  ← Méthode pédagogique principale
│
├── state/
│   ├── parcours.json           ← Progression dans les 10 blocs
│   └── license.json            ← Licence (vide par défaut)
│
└── templates/                  ← Templates d'exercices
```

---

## Confidentialité

- ✅ Utilisable par les détenteurs d'une licence valide
- ⚠️ Distribution équipe contrôlée par le propriétaire
- ❌ Pas diffusable publiquement sans accord

---

## Philosophie

> *"Donnez un poisson à un homme, il mangera un jour. Apprenez-lui à pêcher, il mangera toute sa vie."* — Lao Tseu

À la fin du parcours, tu n'auras plus besoin de Nodex. **C'est ça le succès.**

---

**Version** : 1.0.0 · **Skill** : nodex-trader-crypto · **Statut** : actif lancement
