# Bloc 04 — Analyse technique classique

> **Connaître les outils. Mais surtout savoir lesquels marchent et lesquels sont du bruit.**

---

## Pourquoi ce bloc

Un débutant utilise 12 indicateurs en même temps → paralysie. Un expert utilise 2-3 indicateurs adaptés au contexte. Ce bloc apprend à **filtrer**.

---

## Prérequis

- Bloc 03 (structure de marché)

---

## Objectifs pédagogiques

À la fin :

1. **Maîtriser le Fibonacci retracement** (où le tracer, comment le lire)
2. **Comprendre RSI** (zones overbought/oversold + divergences)
3. **Comprendre MACD** (croisements + divergences)
4. **Utiliser EMA/SMA** (50, 100, 200) comme indicateurs dynamiques de tendance
5. **Lire les divergences** (prix vs RSI/MACD/OBV)
6. **Comprendre Bollinger Bands** (volatilité, squeeze, breakout)
7. **Utiliser VWAP** (volume-weighted average price) en intraday
8. **Maîtriser volume profile** (POC, VAH, VAL)
9. **SAVOIR CE QUI MARCHE** vs ce qui est du bruit en crypto

---

## Leçons (10 leçons)

### Leçon 4.1 — Fibonacci retracement (le bon usage)
> Concepts : tracer sur dernier swing impulsif, niveaux clés (0.5 = frontière, 0.618-0.786 = OTE)
> Exercice : tracer Fibo sur 10 swings et identifier la zone discount

### Leçon 4.2 — Fibonacci extension (cibles TP)
> Concepts : 1.272, 1.414, 1.618, 2.0, 2.618 — où sont les cibles probables
> Exercice : tracer extensions et identifier TP cohérents

### Leçon 4.3 — RSI (Relative Strength Index)
> Concepts : 0-100, overbought >70, oversold <30, plus utile en RANGE qu'en trend
> Exercice : identifier 5 setups RSI valides + 5 invalides

### Leçon 4.4 — Divergences (prix vs RSI/MACD)
> Concepts : divergence bullish (prix LL, RSI HL) = signal retournement potentiel
> Exercice : repérer 5 divergences historiques significatives

### Leçon 4.5 — MACD
> Concepts : 12-26-9, croisements, histogramme, divergences MACD
> Exercice : analyser 5 trades sur signaux MACD

### Leçon 4.6 — Moyennes mobiles (EMA 50/100/200)
> Concepts : EMA 200 = ligne du marché bull/bear long terme, golden cross, death cross
> Exercice : analyser comportement BTC vs EMA 200 D1 sur 4 ans

### Leçon 4.7 — Bollinger Bands
> Concepts : déviation standard, squeeze (low volatility), breakout, mean reversion
> Exercice : trader 5 squeezes Bollinger sur ARB

### Leçon 4.8 — VWAP (intraday)
> Concepts : prix moyen pondéré par volume depuis ouverture session
> Exercice : utiliser VWAP comme support/résistance sur session NYAM

### Leçon 4.9 — Volume Profile (POC, VAH, VAL)
> Concepts : où se concentre le volume = zones d'intérêt institutionnel
> Exercice : identifier POC sur 5 ranges majeurs

### Leçon 4.10 — Synthèse : quel indicateur quand
> Format : décider quel indicateur utiliser selon le contexte (trend / range / scalp / swing)
> Tableau de décision : "Si X situation, alors Y indicateur"

---

## Validation du bloc

Exercice : **construire son propre setup d'indicateurs** sur TradingView, justifier chaque choix, montrer comment ils se complètent (et ne se redondent pas).

---

**Bloc 04** · **Durée estimée : 2-3 semaines**
