# Bloc 08 — Fondamentaux d'un projet crypto

> **Un trader peut survivre sans ça. Un investisseur, jamais.**

---

## Pourquoi ce bloc

Si tu ne fais que du scalp/swing court terme, ce bloc est secondaire. Mais si tu veux DCA / hold des positions long terme, savoir scorer un projet sur ses fondamentaux est **vital**. Beaucoup de gens "tradent" en réalité des SHITCOINS qui vont à zéro.

---

## Prérequis

- Bloc 01 (comprendre blockchain et tokens)

---

## Objectifs pédagogiques

1. **Lire un whitepaper** rapidement (10-15 min)
2. **Analyser tokenomics** (supply, vesting, emissions, distribution)
3. **Évaluer** une équipe (LinkedIn, anonyme, doxxed, expérience)
4. **Identifier** le use case réel vs hype
5. **Vérifier** les audits (CertiK, Halborn, Trail of Bits)
6. **Repérer** les red flags (rug pull risks, vesting agressif, équipe anonyme suspecte)

---

## Leçons (8 leçons)

### Leçon 8.1 — Lire un whitepaper en 15 min
> Méthode : 4 questions-clés à poser systématiquement

### Leçon 8.2 — Tokenomics — Supply
> Concepts : max supply, circulating supply, fully diluted valuation (FDV), inflation

### Leçon 8.3 — Tokenomics — Vesting & emissions
> Concepts : équipe vested 4 ans, cliff 1 an, unlock schedule, dilution
> Sources : tokenomist.io

### Leçon 8.4 — Tokenomics — Distribution
> Concepts : équipe vs investors vs community, % réservé fondateurs

### Leçon 8.5 — Use case réel vs hype
> Méthode : "Si ce projet disparaissait, qu'est-ce qui changerait pour le monde ?"

### Leçon 8.6 — Équipe et conseil
> Vérification : LinkedIn, GitHub commits, expériences passées
> Red flag : équipe entièrement anonyme + promesses de 100x

### Leçon 8.7 — Audits & sécurité
> Sources : CertiK, Halborn, Trail of Bits, Quantstamp
> Lecture : "0 audit" = pass · "1 audit, 5 high vulnerabilities not fixed" = pass

### Leçon 8.8 — Synthèse : scoring d'un projet (template)
> Template : 10 critères notés 0-10, total /100

---

## Validation du bloc

Scorer 5 projets crypto réels (de ta watchlist) avec le template + justifier chaque note.

---

**Bloc 08** · **Durée estimée : 2 semaines** · **Optionnel pour scalper, essentiel pour investisseur**
