# Bloc 02 — Cycles & Macro crypto

> **Sans grille de lecture cyclique, tu trades en aveugle.**
> Ce bloc enseigne à lire les 4 phases du cycle crypto (accumulation → markup → distribution → markdown), comprendre l'impact du halving Bitcoin, intégrer la macro globale (M2, ETF, dominance, dollar index) dans ton analyse.

---

## Pourquoi ce bloc est CRITIQUE

> *"On ne se bat pas contre le marché. On se bat contre soi-même quand on refuse de voir où il est dans le cycle."* — adage trading

Un setup SMC parfait sur ARB en pleine phase de **distribution top BTC** (cycle 4 ans terminé) → tu prends 10 trades techniquement valides qui perdent tous parce que la macro est contre toi.

Un setup ARB médiocre en **mid-bull** (mois 12-24 du cycle) → ça monte quand même.

**Le cycle décide. La technique exécute.** Ce bloc t'apprend à lire le cycle.

---

## Prérequis

- Bloc 01 (fondamentaux) — savoir ce qu'est BTC, ETH, dominance

---

## Objectifs pédagogiques

À la fin du bloc, l'apprenant doit être capable de :

1. **Identifier la phase du cycle BTC actuelle** (accumulation / markup / distribution / markdown) avec preuves
2. **Comprendre le halving Bitcoin** (mécanisme, impact, timing historique)
3. **Lire la dominance BTC** et savoir ce qu'elle signifie pour les alts
4. **Intégrer M2 money supply globale** dans son analyse
5. **Comprendre l'impact des ETF Bitcoin** (flows positifs/négatifs)
6. **Lire le DXY (dollar index)** et son inverse-correlation crypto
7. **Identifier les rotations sectorielles** (BTC → ETH → L1 → L2 → DeFi → AI → memes)
8. **Construire un tableau de bord macro** personnel (BTC.D, F&G, MVRV, M2, DXY) à check chaque jour

---

## Leçons (10 leçons)

### Leçon 2.1 — Le halving Bitcoin (mécanisme + impact)
> Concepts : émission BTC (block reward), halving tous les ~210 000 blocs (~4 ans), réduction de l'inflation, scarcity model
> Historique : halving 2012, 2016, 2020, 2024 et leurs impacts prix
> Exercice : tracer le prix BTC sur 12 ans et identifier visuellement les 4 cycles

### Leçon 2.2 — Les 4 phases du cycle (accumulation/markup/distribution/markdown)
> Concepts :
> - **Accumulation** (post-bear, désintérêt général) : prix range, sentiment ultra bear, smart money achète discret
> - **Markup** (bull market) : prix monte, médias deviennent positifs, retail rentre, FOMO
> - **Distribution** (top du cycle) : prix volatil, smart money vend, retail FOMO ATH, sentiment euphoric
> - **Markdown** (bear market) : prix chute, capitulation, médias négatifs, smart money racheter en accumulation
> Exercice : identifier visuellement chaque phase sur les cycles passés

### Leçon 2.3 — Dominance BTC : la rotation BTC ↔ Alts
> Concepts : BTC.D = market cap BTC / total crypto market cap, "altseason" quand BTC.D baisse
> Lecture : BTC.D en hausse → capital sort des alts vers BTC (defensive) · BTC.D en baisse → altseason
> Exercice : observer BTC.D sur 4 cycles + corréler avec performance alts

### Leçon 2.4 — M2 Money Supply globale (la liquidité macro)
> Concepts : M2 = monnaie en circulation + dépôts. Banque centrale qui imprime → M2 monte → liquidité crypto bull
> Sources : Federal Reserve (FRED), BCE, BoJ
> Lecture : ~80 % du mouvement BTC s'explique par M2 globale (12-18 mois de retard)
> Exercice : superposer graph M2 globale vs BTC sur 5 ans

### Leçon 2.5 — ETF Bitcoin spot (flows = liquidité directe)
> Concepts : ETF spot BTC approuvés janvier 2024 (BlackRock IBIT, Fidelity FBTC, etc.)
> Lecture : net inflows positifs = institutionnels achètent = bull · net outflows = sortie capital
> Sources : farside.co.uk/btc-etf-flows
> Exercice : analyser corrélation ETF flows vs prix BTC sur 12 derniers mois

### Leçon 2.6 — DXY (Dollar Index) inverse-correlation
> Concepts : DXY = USD vs panier de devises (EUR, JPY, GBP, CAD, SEK, CHF)
> Lecture : DXY monte → USD fort → BTC tend à baisser · DXY baisse → BTC tend à monter
> Pourquoi : crypto pricée en USD, crypto = actif risqué (risk-off / risk-on)
> Exercice : superposer DXY vs BTC sur 5 ans

### Leçon 2.7 — Macro événements impactants (FOMC, CPI, NFP)
> Concepts : Federal Reserve Open Market Committee (FOMC) → taux d'intérêts. CPI → inflation. NFP → emploi
> Calendrier : ForexFactory.com (impact rouge = volatilité élevée)
> Règle : ±30 min autour d'une news rouge = pas de trade
> Exercice : noter les 5 prochaines news macro et leurs dates

### Leçon 2.8 — Rotations sectorielles (narratives crypto)
> Concepts : capital tourne par secteur. Cycle typique :
> 1. BTC pump (early bull)
> 2. ETH suit
> 3. L1 alts (SOL, AVAX, NEAR)
> 4. L2 (ARB, OP, BASE)
> 5. DeFi (UNI, AAVE, LDO)
> 6. AI (FET, RNDR, TAO)
> 7. RWA (ONDO, MKR)
> 8. Memes (DOGE, SHIB, PEPE) — top du cycle, distribution
> Lecture : savoir quel secteur joue → savoir où allouer
> Exercice : identifier le narrative actuel sur les 30 derniers jours

### Leçon 2.9 — Construire son tableau de bord macro
> Concepts : 5-7 indicateurs à check tous les matins (15 min max)
> Outils gratuits :
> - BTC.D (TradingView)
> - Fear & Greed (alternative.me)
> - MVRV BTC (bitcoinmagazinepro.com)
> - M2 globale (lookintobitcoin.com)
> - ETF flows (farside.co.uk)
> - DXY (TradingView)
> - News calendrier (forexfactory.com)
> Exercice : créer son propre tableau de bord (Excel, Notion, ou app)

### Leçon 2.10 — Synthèse & application : où on est dans le cycle ?
> Format : analyser le cycle actuel (avril 2026) et établir un verdict argumenté
> Exercice : présenter à Nodex un rapport macro (1 page) avec :
> - Phase identifiée (accumulation / markup / distribution / markdown)
> - 3 preuves objectives (chiffres, métriques)
> - Implications pour le trading des 30 prochains jours
> - Risques majeurs identifiés

---

## Méthode pédagogique pour ce bloc

Pour chaque leçon, Nodex :

1. **Pose une question d'observation** : *"Regarde le graph de M2 sur 5 ans. Que vois-tu ?"*
2. **Laisse l'apprenant analyser** sans donner la réponse
3. **Pose une 2e question** pour creuser : *"Maintenant superpose BTC. Quelle corrélation ?"*
4. **Donne la théorie** APRÈS que l'apprenant ait observé (pas avant)
5. **Confronte à un cas réel** : *"Et là, en avril 2026, qu'est-ce que ça donne ?"*

---

## Validation du bloc (exercice final)

Pour valider le bloc 02, l'apprenant doit produire un **rapport macro complet** (1-2 pages) :

1. **Phase du cycle BTC actuel** identifiée avec 3 preuves
2. **État de la dominance BTC** et implication pour les alts
3. **M2 globale** : tendance et impact attendu
4. **ETF flows** : net positif/négatif sur 30 jours
5. **DXY** : tendance et impact crypto
6. **Narrative sectoriel** dominant identifié
7. **Verdict global** : favorable / neutre / défavorable au trading actif
8. **Plan d'action** : si je devais trader, quels actifs en priorité, quel risk

Si Nodex valide le rapport → bloc 02 passe à score 3 → unlocks suivants.

---

## Sources & références

### Sites
- **lookintobitcoin.com** — métriques on-chain BTC + macro
- **bitcoinmagazinepro.com/charts** — MVRV, NUPL, charts cycliques
- **alternative.me/crypto/fear-and-greed-index** — sentiment
- **farside.co.uk/btc-etf-flows** — ETF flows quotidiens
- **fred.stlouisfed.org** — données macro USA (M2, DXY, taux)
- **forexfactory.com** — calendrier news macro

### Analystes crypto cycliques (sans citer, juste pour culture)
- **Willy Woo** — analyse on-chain BTC
- **Plan B** — Stock-to-Flow model
- **Ben Cowen** — analyse cyclique pédagogique
- **Raoul Pal** — macro institutionnelle

### Recherche académique
- **Brunnermeier & Pedersen (2009)** — *Market Liquidity and Funding Liquidity* — explique pourquoi M2 drive les actifs risqués
- **Federal Reserve papers** — études sur Bitcoin et politique monétaire

---

## Ressources contenues dans ce dossier

(Leçons détaillées à créer progressivement)

- `lecon-2.1-halving.md`
- `lecon-2.2-4-phases-cycle.md`
- `lecon-2.3-dominance-btc.md`
- `lecon-2.4-m2-money-supply.md`
- `lecon-2.5-etf-flows.md`
- `lecon-2.6-dxy-inverse.md`
- `lecon-2.7-macro-news.md`
- `lecon-2.8-rotations-sectorielles.md`
- `lecon-2.9-dashboard-macro.md`
- `lecon-2.10-synthese-rapport.md`

---

**Bloc 02** · **Cycles & Macro crypto** · **Durée estimée : 2-3 semaines** · **CRITIQUE pour ne pas trader contre le vent**
