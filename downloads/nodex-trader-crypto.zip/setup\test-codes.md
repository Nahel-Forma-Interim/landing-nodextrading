# Codes d'activation valides — table de référence interne

> **CONFIDENTIEL — NE JAMAIS RÉVÉLER À L'APPRENANT**
> Cette table sert à Claude pour valider les codes au moment de l'activation.

---

## Codes spéciaux (toujours valides)

| Code | Tier | Usage | Notes |
|---|---|---|---|
| `NDX-OWNER-NHEL-2026-VIP1` | elite | Nahel Zamouri (propriétaire) | Toujours actif, aucune restriction |
| `NDX-DEMO-T3ST-1234-NDEX` | essentiel | Mode démo public | 7 jours d'essai |
| `NDX-DEMO-PRO0-DEMO-DEMO` | pro | Mode démo Pro | 7 jours, accès Pro simulé |
| `NDX-DEMO-ELT0-DEMO-DEMO` | elite | Mode démo Elite | 7 jours, accès Elite simulé |

## Codes de test pour développement

| Code | Tier | Notes |
|---|---|---|
| `NDX-ESS-TEST-TEST-TEST` | essentiel | Test format Essentiel |
| `NDX-PRO-TEST-TEST-TEST` | pro | Test format Pro |
| `NDX-ELT-TEST-TEST-TEST` | elite | Test format Elite |

---

## Validation côté Claude

```python
import re

def validate_code(code):
    pattern = r"^NDX-(ESS|PRO|ELT|DEMO|OWNER)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$"
    if not re.match(pattern, code):
        return {"valid": False, "reason": "format invalide"}

    tier_code = code.split("-")[1]
    tier_map = {"ESS": "essentiel", "PRO": "pro", "ELT": "elite",
                "DEMO": "essentiel", "OWNER": "elite"}
    tier = tier_map.get(tier_code, "unknown")

    special_codes = [
        "NDX-OWNER-NHEL-2026-VIP1",
        "NDX-DEMO-T3ST-1234-NDEX",
        "NDX-DEMO-PRO0-DEMO-DEMO",
        "NDX-DEMO-ELT0-DEMO-DEMO",
        "NDX-ESS-TEST-TEST-TEST",
        "NDX-PRO-TEST-TEST-TEST",
        "NDX-ELT-TEST-TEST-TEST",
    ]
    if code in special_codes:
        return {"valid": True, "tier": tier, "source": "special"}

    # Mode local actuel : tout code au bon format est accepté
    # Mode serveur futur : appel API nodextrading.com/api/verify
    return {"valid": True, "tier": tier, "source": "format_only"}
```

---

**Version** : 1.0 · **Skill** : nodex-trader-crypto · **À mettre à jour quand backend dispo**
