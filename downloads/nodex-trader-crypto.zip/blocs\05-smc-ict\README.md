# Bloc 05 — SMC/ICT approfondi

> **Smart Money Concepts (SMC) / Inner Circle Trader (ICT) — la méthodologie qui décrypte les mouvements institutionnels.**

---

## Pourquoi ce bloc

SMC/ICT est la méthode dominante chez les jeunes traders crypto depuis 2022-2023. Mais 90 % la maîtrisent mal. Ce bloc apprend à le faire **vraiment**.

---

## Prérequis

- Bloc 03 (structure de marché)
- Bloc 04 (analyse technique)

---

## Objectifs pédagogiques

À la fin :

1. **Maîtriser** les 6 POI : FVG, OB, BB, BPR, BISI, IFVG
2. **Comprendre** la dynamique liquidité smart money vs retail
3. **Identifier** les Killzones (Asia, London, NY) et leur importance
4. **Tracer** le Fibonacci ICT (premium/discount, OTE 0.62-0.79)
5. **Reconnaître** un sweep valide vs un faux signal
6. **Comprendre** les "models" ICT (Model 1, Model 2, etc.)

---

## Leçons (12 leçons)

### Leçon 5.1 — Philosophie SMC/ICT (smart money vs retail)
### Leçon 5.2 — FVG (Fair Value Gap) — le concept central
### Leçon 5.3 — OB (Order Block) — zones d'ordre institutionnel
### Leçon 5.4 — BB (Breaker Block) — niveaux validés 2 fois
### Leçon 5.5 — BPR (Balanced Price Range) — confluence FVG bull/bear
### Leçon 5.6 — BISI / IFVG — variantes
### Leçon 5.7 — Killzones (Asia, London, NY) heures précises
### Leçon 5.8 — Sweep de liquidité (mèche, close, volume)
### Leçon 5.9 — Premium / Discount + zone OTE
### Leçon 5.10 — Top-down analysis (W1 → D1 → H4 → H1 → M15)
### Leçon 5.11 — Models ICT (1, 2, 3) et Silver Bullet
### Leçon 5.12 — Critique honnête : forces et limites du SMC en crypto

---

## Validation du bloc

Analyser 10 setups SMC historiques (5 valides, 5 ratés) et expliquer pourquoi chacun a marché ou pas.

---

**Bloc 05** · **Durée estimée : 3-4 semaines** · **Cœur méthodologique pour beaucoup de traders crypto**
