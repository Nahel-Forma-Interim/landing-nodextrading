# Bloc 03 — Structure de marché

> **Le langage universel des charts.** Sans comprendre la structure, tu lis un graphique sans comprendre l'histoire qu'il raconte.

---

## Pourquoi ce bloc

Avant d'apprendre RSI, MACD, FVG, OB — il faut savoir **lire la structure du marché** : tendance, range, swing highs/lows, points de pivot, MSS (Market Structure Shift), CHoCH (Change of Character), BOS (Break of Structure).

Ces concepts sont la **base universelle** de TOUTES les méthodes (SMC, Wyckoff, Elliott, classique). Sans eux, le reste est inutile.

---

## Prérequis

- Bloc 01 (fondamentaux)

---

## Objectifs pédagogiques

À la fin du bloc, l'apprenant doit :

1. **Identifier visuellement** une tendance haussière, baissière ou un range
2. **Repérer** les swing highs / swing lows sur n'importe quel timeframe
3. **Comprendre** MSS, CHoCH, BOS et leurs implications
4. **Tracer** les supports et résistances qui comptent (volume + multiple touches)
5. **Identifier** les zones de liquidité (BSL au-dessus, SSL en-dessous)
6. **Faire la différence** entre une cassure réelle et un fakeout

---

## Leçons (8 leçons)

### Leçon 3.1 — Tendance, range, et leurs structures
> Concepts : HH+HL = bullish · LL+LH = bearish · range = chop entre 2 niveaux
> Exercice : sur 10 charts, identifier la structure et justifier

### Leçon 3.2 — Swing highs et swing lows
> Concepts : pivot bas/haut, importance des swings sur HTF vs LTF
> Exercice : marquer 20 swings sur BTC D1

### Leçon 3.3 — Support et résistance (les vrais)
> Concepts : multiple touches, volume, polarité, S/R cassé devient inverse
> Exercice : identifier 5 niveaux S/R sur BTC W1 + justifier

### Leçon 3.4 — MSS (Market Structure Shift)
> Concepts : cassure du dernier HL en bullish (= MSS bearish) ou cassure du dernier LH en bearish (= MSS bullish)
> Exercice : repérer 5 MSS historiques sur ETH D1

### Leçon 3.5 — CHoCH (Change of Character)
> Concepts : premier signal de retournement, vs MSS qui confirme
> Exercice : différencier CHoCH vs MSS sur 5 cas

### Leçon 3.6 — BOS (Break of Structure)
> Concepts : continuation de tendance, validation HH ou LL
> Exercice : identifier BOS bullish vs MSS bearish

### Leçon 3.7 — Zones de liquidité (BSL, SSL, equal highs/lows)
> Concepts : où sont les stops retail, comment smart money les chasse
> Exercice : marquer toutes les zones liquidité sur BTC H4 dernière semaine

### Leçon 3.8 — Cassure réelle vs fakeout
> Concepts : volume sur cassure, retest, close au-delà du niveau, time spent
> Exercice : analyser 10 cassures et classer (vraie/fake)

---

## Validation du bloc

Exercice final : **analyser un chart complet** (BTC D1 sur 6 mois) en identifiant :
- Structure globale (tendance/range)
- 5 swing highs/lows majeurs
- 3 zones S/R importantes
- 2 MSS
- 3 zones de liquidité
- 1 fakeout vs 1 cassure réelle

Si Nodex valide → score bloc 3 → unlocks suivants.

---

**Bloc 03** · **Durée estimée : 1-2 semaines**
