# Bloc 06 — On-chain analysis

> **Les charts mentent. La blockchain, jamais.**

---

## Pourquoi ce bloc

L'analyse on-chain est ce qui différencie un trader crypto **professionnel** d'un trader généraliste qui applique les mêmes outils que sur le forex. C'est l'avantage **unique** du marché crypto.

---

## Prérequis

- Bloc 01 (comprendre blockchain)
- Bloc 02 (comprendre cycles)

---

## Objectifs pédagogiques

À la fin :

1. **Lire** MVRV (Market Value to Realized Value) pour BTC et ETH
2. **Comprendre** NUPL (Net Unrealized Profit/Loss)
3. **Surveiller** miners selling et hashrate
4. **Lire** exchange inflows/outflows (signal d'achat/vente massif)
5. **Tracker** active addresses (santé d'une blockchain)
6. **Identifier** les whale transactions (Whale Alert)
7. **Utiliser** les outils Glassnode, CryptoQuant, Lookintobitcoin

---

## Leçons (8 leçons)

### Leçon 6.1 — MVRV (le ratio cyclique)
> Concepts : Market Value / Realized Value, <1 = oversold, >3.7 = top historique
> Sources : bitcoinmagazinepro.com, lookintobitcoin.com

### Leçon 6.2 — NUPL (sentiment des holders)
> Concepts : profits/pertes non réalisés des holders BTC
> Zones : Capitulation < 0 < Hope < 0.25 < Optimism < 0.5 < Belief < 0.75 < Euphoria

### Leçon 6.3 — Realized Cap & Realized Price
> Concepts : prix moyen d'achat de chaque BTC qui a bougé
> Lecture : support fort historique en bear

### Leçon 6.4 — Exchange flows (in/out)
> Concepts : inflows = pression vente (BTC arrive sur exchange pour être vendu) · outflows = pression achat (BTC quitte pour cold storage = HODL)

### Leçon 6.5 — Miners (selling, capitulation, hashrate)
> Concepts : miners forcés de vendre en bear, hashrate = santé réseau

### Leçon 6.6 — Active addresses (santé blockchain)
> Concepts : adresses qui transactent par jour, signal usage réel

### Leçon 6.7 — Whale transactions
> Sources : Whale Alert, Arkham Intelligence

### Leçon 6.8 — Synthèse : tableau de bord on-chain quotidien
> Construire son propre dashboard (5 métriques à check chaque matin)

---

## Validation du bloc

Produire un **rapport on-chain hebdomadaire** sur BTC :
- État MVRV, NUPL
- Exchange flows nets sur 7j
- Activité miners
- Verdict cyclique (accumulation/distribution)

---

**Bloc 06** · **Durée estimée : 2 semaines** · **L'avantage unique du trader crypto**
