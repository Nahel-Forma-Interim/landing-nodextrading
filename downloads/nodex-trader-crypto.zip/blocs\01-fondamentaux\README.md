# Bloc 01 — Fondamentaux crypto

> **Pas de trading sans comprendre l'infrastructure.**
> Ce bloc construit le socle : qu'est-ce qu'une blockchain, BTC vs ETH vs alts, comment fonctionnent les exchanges, custody, wallets, fees, slippage, marchés spot vs futures.

---

## Pourquoi ce bloc en premier

90 % des nouveaux traders crypto se font liquider sur des futures sans comprendre ce qu'est un funding rate. 80 % laissent leurs cryptos sur un exchange et perdent tout (cf. FTX). 70 % trade sur un DEX sans comprendre le slippage et perdent 5-15 % par trade en "frais cachés".

**Ce bloc t'évite ces erreurs basiques avant même de toucher à l'analyse technique.**

---

## Prérequis

Aucun. C'est le bloc de base.

---

## Objectifs pédagogiques (à valider en fin de bloc)

À la fin du bloc, l'apprenant doit être capable de :

1. **Expliquer** ce qu'est une blockchain, comment ça fonctionne (mining/staking, consensus, blocs, transactions)
2. **Différencier** BTC, ETH, Layer 1, Layer 2, altcoins, stablecoins, memecoins
3. **Choisir** entre CEX (Binance, Coinbase) et DEX (Uniswap) selon le besoin
4. **Sécuriser** ses cryptos : différence wallet hot (MetaMask) vs cold (Ledger), seed phrase, multi-sig
5. **Comprendre** les fees : trading fees, gas fees, slippage, spread
6. **Différencier** spot vs futures perpétuels, et savoir quand utiliser quoi
7. **Identifier** les risques de contrepartie (exchange hack, faillite, KYC, gel de compte)

---

## Leçons (à faire dans l'ordre suggéré)

### Leçon 1.1 — Qu'est-ce qu'une blockchain
> Concepts : ledger distribué, mining/staking, consensus, blocs, hash, transactions
> Format : explication socratique + analogie (cahier comptable partagé)
> Exercice : analyser une transaction Bitcoin réelle sur mempool.space

### Leçon 1.2 — Bitcoin vs Ethereum vs alts
> Concepts : philosophie BTC (or numérique), philosophie ETH (ordinateur mondial), alts (utility, speculation)
> Format : tableau comparatif + cas réels
> Exercice : choisir 5 alts et catégoriser (L1/L2/DeFi/AI/RWA/meme)

### Leçon 1.3 — Layer 1 vs Layer 2 vs sidechains
> Concepts : trilemme blockchain (sécurité/scalabilité/décentralisation), rollups, bridges
> Format : architecture visuelle + exemples (ETH L1, ARB L2, Polygon sidechain)
> Exercice : expliquer pourquoi ARB existe (pas juste "Ethereum est cher")

### Leçon 1.4 — Stablecoins (USDT, USDC, DAI)
> Concepts : peg, collateral, risques (Terra Luna 2022)
> Format : étude de cas Terra Luna + comparaison USDT/USDC/DAI
> Exercice : identifier les risques de chaque stablecoin et les protections

### Leçon 1.5 — Exchanges (CEX vs DEX)
> Concepts : Binance/Coinbase vs Uniswap/dYdX, KYC, custody, ordres
> Format : démo workflow d'un trade sur chaque
> Exercice : comparer slippage/fees pour 1000 USDT → ARB sur Binance vs Uniswap

### Leçon 1.6 — Wallets & sécurité
> Concepts : seed phrase, hot vs cold, multi-sig, hardware wallets
> Format : risques réels (drainer, phishing, hack)
> Exercice : créer un wallet test (testnet) + sécuriser sa seed

### Leçon 1.7 — Fees, slippage, spread
> Concepts : maker/taker fees, gas, spread, slippage, MEV
> Format : calculs concrets sur trades réels
> Exercice : optimiser les fees pour 10 trades sur 30 jours

### Leçon 1.8 — Spot vs futures perpétuels
> Concepts : leverage, funding rate, liquidation price, isolated vs cross margin
> Format : comparaison risque/reward + cas concrets de liquidation
> Exercice : calculer prix de liquidation sur leverage 10x avec 100 USDT

### Leçon 1.9 — Risques de contrepartie
> Concepts : Mt. Gox, FTX, Celsius, gel de compte KYC, sanctions
> Format : chronologie des grands hacks/faillites + leçons
> Exercice : audit perso : combien de % du capital sur quel exchange ?

### Leçon 1.10 — Synthèse & quiz pratique
> Format : analyser un cas concret (ex: Nahel a 5000 € sur Binance, comment optimiser sécurité + fees + accès liquidité)
> Exercice : construire un setup perso optimisé (CEX/cold wallet/réserve fiat)

---

## Méthode pédagogique pour ce bloc

Pour chaque leçon, Nodex :

1. **Pose une question d'amorçage** : *"Tu sais ce qu'est X ?"*
2. **Écoute la réponse** sans corriger immédiatement
3. **Pointe les zones floues** par d'autres questions : *"Et si X arrive, qu'est-ce que tu fais ?"*
4. **Donne le concept en réponse**, avec analogie + exemple concret
5. **Propose un exercice** pratique
6. **Debrief l'exercice** ensemble (méthode socratique : *"Pourquoi tu as choisi ça ? Quels sont les risques ?"*)

---

## Validation du bloc (exercice final)

Pour valider le bloc 01, l'apprenant doit :

1. **Construire un setup personnel optimisé** (capital fictif 5 000 €) :
   - Combien sur quel exchange ? Pourquoi ?
   - Quelles cryptos en cold wallet ? Lesquelles en hot ?
   - Quel % en stablecoin pour réserve / opportunité ?
   - Quels exchanges pour trading actif ? Pour custody long terme ?
2. **Justifier chaque choix** avec les risques considérés
3. **Identifier 3 erreurs débutant** qu'il aurait pu faire et qu'il évite maintenant

Si Nodex valide → score bloc passe à 3 → débloque les blocs suivants.

---

## Sources & références

### Livres
- *Mastering Bitcoin* — Andreas Antonopoulos (référence technique BTC)
- *The Bitcoin Standard* — Saifedean Ammous (philosophie monétaire)
- *Mastering Ethereum* — Antonopoulos & Wood (référence ETH)

### Sites
- **mempool.space** — explorateur BTC en temps réel
- **etherscan.io** — explorateur ETH
- **defillama.com** — données DeFi & TVL
- **rugdoc.io** — analyse des risques projets

### Recherche
- **Bank for International Settlements (BIS)** — papers sur stablecoins et crypto
- **Federal Reserve papers** — analyses crypto et politique monétaire

---

## Ressources contenues dans ce dossier

(Les leçons détaillées sont dans des fichiers séparés)

- `lecon-1.1-blockchain.md` — détails leçon 1.1
- `lecon-1.2-btc-eth-alts.md` — détails leçon 1.2
- `lecon-1.3-l1-l2.md` — détails leçon 1.3
- `lecon-1.4-stablecoins.md` — détails leçon 1.4
- `lecon-1.5-exchanges.md` — détails leçon 1.5
- `lecon-1.6-wallets-securite.md` — détails leçon 1.6
- `lecon-1.7-fees-slippage.md` — détails leçon 1.7
- `lecon-1.8-spot-futures.md` — détails leçon 1.8
- `lecon-1.9-risques-contrepartie.md` — détails leçon 1.9
- `lecon-1.10-synthese.md` — synthèse + exercice final

> **Note** : ce README est l'overview du bloc. Les leçons détaillées seront créées progressivement à mesure de l'usage du skill par l'apprenant.

---

**Bloc 01** · **Fondamentaux crypto** · **Durée estimée : 1-2 semaines**
