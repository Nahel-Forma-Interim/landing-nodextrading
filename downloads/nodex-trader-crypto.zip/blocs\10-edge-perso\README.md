# Bloc 10 — Construction de TON edge perso

> **L'objectif final.** À la fin de ce bloc, tu as TA méthode (pas celle de Nodex), validée par 100+ backtests, avec une expectancy positive démontrée.

---

## Pourquoi ce bloc est OBLIGATOIRE

Tu peux maîtriser parfaitement les blocs 1-9 et **rester non-rentable**. Pourquoi ? Parce qu'avoir des connaissances ne suffit pas. Il faut une **méthode mécanique** que TU peux exécuter à 100% sans hésiter, avec ta propre psychologie.

Ce bloc est le **seul** qui te transforme de "apprenant" à "trader autonome rentable".

---

## Prérequis

- TOUS les autres blocs (1-9) doivent avoir été parcourus (même rapidement)
- Score moyen ≥ 2 sur les 9 blocs

---

## Objectifs pédagogiques

1. **Identifier** ton style de trading qui correspond à ta psychologie
2. **Construire** une méthode mécanique avec règles écrites précises
3. **Backtester** 100+ trades sur 3 actifs minimum
4. **Calculer** les métriques (WR, PF, RR moyen, expectancy, max DD)
5. **Itérer** la méthode si expectancy < +0,5% par trade
6. **Valider** la méthode en paper trading 30 trades supplémentaires
7. **Passer en live** progressif (paliers 0,25% → 0,5% → 1%)

---

## Leçons (10 leçons)

### Leçon 10.1 — Identifier ton style de trading
> Questions :
> - Disponibilité quotidienne ? (< 1h → swing/position · 1-3h → intraday · > 3h → scalp possible)
> - Tolérance émotionnelle aux trades fréquents ? (faible → swing · forte → scalp)
> - Capital disponible ? (< 5k → swing · > 10k → scalp viable)
> - Profil cyclique vs anti-cyclique ?
> Sortie : style identifié + justifié

### Leçon 10.2 — Choisir ton timeframe principal
> Logique : aligné avec disponibilité + style
> Mapping : scalp (M1-M15) · intraday (M30-H1) · swing (H4-D1) · position (D1-W1)

### Leçon 10.3 — Choisir tes outils (filtre macro + technique + risk)
> Composer une méthode COHÉRENTE :
> - Filtre macro (ex: BTC bullish + dominance OK)
> - Setup technique (ex: SMC sweep + FVG ou autre)
> - Confirmation (ex: 1-2 bougies, divergence)
> - Sortie (TP/SL fixe ou trailing)
> - Risk (1% standard)

### Leçon 10.4 — Écrire ta méthode (règles binaires)
> Template :
> - Conditions d'entrée (5-10 conditions checklist)
> - Conditions de SL placement
> - Conditions de TP / trailing
> - Conditions de sortie d'urgence
> - Risk par trade
> - Max trades par jour/semaine

### Leçon 10.5 — Backtest manuel 30 trades initiaux
> Méthode : screenshot chaque setup, journaliser entry/SL/TP, résultat
> Outils : TradingView replay mode

### Leçon 10.6 — Calcul des métriques (30 trades)
> Calculer : WR, PF, RR moyen, expectancy, max DD
> Verdict : si expectancy ≥ +0,3% → continuer · sinon → itérer méthode

### Leçon 10.7 — Backtest 70 trades supplémentaires (total 100)
> Confirmer la stabilité statistique (sur 100 trades, marge d'erreur ±10%)

### Leçon 10.8 — Itération si nécessaire
> Si métriques insuffisantes : identifier les pertes systématiques, ajuster UNE règle à la fois, re-backtest
> ⚠️ **NE JAMAIS** changer 5 règles en même temps

### Leçon 10.9 — Paper trading 30 trades (validation finale)
> Après backtest validé : 30 trades paper EN LIVE (pas backtest)
> Vérifier : tu peux EXÉCUTER ta méthode en pression réelle

### Leçon 10.10 — Transition LIVE progressive
> Paliers :
> - 0,25% par trade × 5 trades
> - 0,5% × 5 trades
> - 0,75% × 5 trades
> - 1% (standard méthode) × 5 trades
> - Si discipline OK toute la période → mode normal
> - Sinon → retour paper

---

## Méthode V6.1 (Nodex) — UNE option parmi d'autres

Si l'apprenant veut adopter directement la méthode Nodex V6.1 (8 conditions + 4 questions OUI), c'est **OK comme point de départ**, mais il doit :

1. La **comprendre** (pas juste l'appliquer mécaniquement)
2. La **backtester** sur 100+ trades pour SA propre validation
3. L'**adapter** à son profil personnel (style, risk, disponibilité)
4. Identifier les **forces et limites** dans son contexte

V6.1 n'est PAS imposée. C'est UNE méthode validée qui peut servir de base.

---

## Validation du bloc 10 (= validation parcours complet)

L'apprenant doit présenter à Nodex :

1. **SA méthode écrite** (1-2 pages, règles binaires)
2. **Backtest 100+ trades** documenté (entry/SL/TP/résultat de chacun)
3. **Métriques calculées** : WR, PF, RR moyen, expectancy ≥ +0,5%, DD max ≤ 15%
4. **Paper trading 30 trades** post-backtest avec mêmes métriques
5. **Plan de transition live** détaillé (paliers risk)
6. **Journal d'apprentissage** complet (ce qu'il a appris, ses erreurs, ses progrès)

Si Nodex valide tout :
> *"Tu as maintenant TA méthode. Validée statistiquement. Adaptée à ta psychologie. Tu peux trader sans moi. Mon job s'arrête ici. Le tien commence."*

---

## Test final autonomie (post-validation bloc 10)

Avant de "libérer" l'apprenant, **dernier test** :

> Tu trades **1 semaine entière SANS me consulter**. Tu remplis ton journal seul. Tu prends tes décisions seul. À la fin, tu reviens, on compare ton journal à ce que j'aurais validé.
>
> Si alignement ≥ 95% → **CERTIFIÉ Nodex Trader Crypto Autonome**.
> Si décrochage < 80% → on prolonge 2 semaines.

---

## Phase post-validation (Phase consolidation)

Une fois certifié autonome, l'apprenant entre en **phase consolidation 3 mois live profitables**. Nodex passe alors d'un rôle de formateur à un rôle de **compagnon ponctuel** :

- Reviews mensuelles (debrief, ajustements)
- Disponible pour analyses ponctuelles
- Plus de "leçons" — uniquement coaching ciblé sur demande

---

**Bloc 10** · **Durée : 1-3 mois** · **OBJECTIF FINAL DU PARCOURS**
