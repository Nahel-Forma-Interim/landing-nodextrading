# Bloc 09 — Risk management

> **Le facteur #1 de survie. La défense bat l'attaque.**

> *"La règle la plus importante du trading est de jouer une grande défense, pas une grande attaque."* — **Paul Tudor Jones**

---

## Pourquoi ce bloc EN PRIORITÉ

Statistique implacable : **89 % des particuliers perdent à long terme** (étude AMF, 14 799 comptes, 2014). La cause #1 n'est pas la mauvaise méthode — c'est l'absence de risk management.

Ce bloc peut être fait **dès le début** du parcours, pas en fin. Il ne dépend d'aucun autre.

---

## Prérequis

Aucun (peut être fait n°1 si l'apprenant veut maximiser sa survie).

---

## Objectifs pédagogiques

1. **Maîtriser** les bases : risk par trade, RR, sizing
2. **Calculer** son **Expectancy** par trade (la métrique qui compte)
3. **Comprendre** Kelly Criterion (sizing optimal mathématiquement)
4. **Construire** son allocation par actif et par stratégie
5. **Gérer** les drawdowns (kill switch, stop loss psychologique)
6. **Éviter** les pièges classiques (martingale, revenge trading, leverage)
7. **Construire** un journal de trading qui force la discipline

---

## Leçons (10 leçons)

### Leçon 9.1 — Risk par trade (1% rule, max drawdown)
> Concepts : 1% standard, 2% max absolu, jamais plus
> Math : Pour ramener ton compte de -50% à 0, tu dois faire +100%. Asymétrie destructrice.

### Leçon 9.2 — Risk:Reward (RR ≥ 2:1 minimum)
> Concepts : si RR = 2:1 et WR = 50%, profit. Si RR = 1:1, il faut WR > 50% pour profit.
> Exercice : 10 trades simulés, calculer expectancy

### Leçon 9.3 — Calcul position size (formule)
> Formule : `Taille = (Capital × Risk%) / (Distance Entry-SL en %)`

### Leçon 9.4 — Expectancy (LA métrique reine)
> Formule : `Expectancy = (WR × Gain moyen) - ((1-WR) × Perte moyenne)`
> Cible : Expectancy ≥ +0,5% par trade

### Leçon 9.5 — Kelly Criterion (sizing optimal)
> Formule simplifiée : `f* = WR - ((1-WR)/RR)`
> Lecture : pourcentage optimal du capital à risquer
> Avertissement : Half-Kelly recommandé en pratique (Kelly full = trop volatile)

### Leçon 9.6 — Allocation par actif
> Concepts : pas tout sur 1 actif, max 5% par alt, max 20% par secteur
> Diversification BTC (40%) + ETH (20%) + alts focus (30%) + cash (10%)

### Leçon 9.7 — Allocation par stratégie
> Concepts : si tu as 3 méthodes (scalp / swing / DCA), allouer par stratégie
> Exemple : 50% DCA long terme, 30% swing trading, 20% scalp

### Leçon 9.8 — Gestion drawdown & kill switch
> Règles strictes :
> - 2 SL consécutifs → STOP 24h
> - 5% DD intra-mois → pause 48h + audit
> - 10% DD → arrêt jusqu'à audit complet
> - 20% DD → retour paper trading

### Leçon 9.9 — Pièges psychologiques (martingale, revenge)
> Anti-patterns :
> - Doubler la mise après une perte (martingale destructrice)
> - Trader pour "se refaire" après une perte (revenge)
> - Augmenter le risk parce qu'on est "sûr de soi"

### Leçon 9.10 — Journal de trading 4 couches
> Template :
> 1. Technique (entry, SL, TP, RR, résultat)
> 2. Checklist (méthode appliquée à %)
> 3. Émotionnel (stress 1-10 avant/pendant/après)
> 4. Contextuel (macro, sentiment, news du jour)

---

## Validation du bloc

1. **Calculer son Expectancy** sur ses 30 derniers trades
2. **Définir son allocation** : par actif + par stratégie
3. **Construire son kill switch** : règles strictes écrites
4. **Tenir son journal 4 couches** sur 10 trades minimum

---

## Sources & références

- **Mark Douglas** — *Trading in the Zone* (psychologie risk)
- **Van Tharp** — *Trade Your Way to Financial Freedom* (sizing avancé)
- **Kahneman & Tversky** — Prospect Theory (Prix Nobel 2002)
- **Kelly (1956)** — *A New Interpretation of Information Rate*

---

**Bloc 09** · **Durée estimée : 1-2 semaines** · **PEUT ÊTRE FAIT EN PREMIER (priorité absolue survie)**
