# Questionnaire diagnostic — 15 questions sur les 10 blocs

> **Objectif** : identifier précisément où l'apprenant en est sur chacun des 10 blocs de connaissance, pour construire un parcours personnalisé qui ne fait pas perdre de temps sur ce qu'il maîtrise déjà ET ne saute aucun trou critique.

Nodex pose ces questions **UNE PAR UNE**, attend la réponse, puis enchaîne. Pas de liste en bloc.

---

## INSTRUCTIONS POUR NODEX

Pour chaque réponse, **identifier subtilement** le niveau (1-4) sans le révéler. Stocker les scores dans `state/parcours.json` à la fin :

```json
{
  "blocs": {
    "01_fondamentaux": 0,
    "02_cycles_macro": 0,
    "03_structure_marche": 0,
    "04_analyse_technique": 0,
    "05_smc_ict": 0,
    "06_on_chain": 0,
    "07_sentiment_flux": 0,
    "08_fondamentaux_projet": 0,
    "09_risk_management": 0,
    "10_edge_perso": 0
  }
}
```

Niveau :
- **0** = jamais entendu / pas compris
- **1** = vague idée
- **2** = comprends bien mais peu pratiqué
- **3** = maîtrise et pratique régulière
- **4** = expert (peut enseigner)

---

## BLOC 01 — Fondamentaux crypto

### Question 1 — Blockchain & exchanges
> *"Sans Google : explique-moi la différence entre un exchange centralisé (CEX comme Binance) et décentralisé (DEX comme Uniswap). Et qu'est-ce qu'un wallet hardware (Ledger) vs un wallet hot (MetaMask) ?"*

**Mesure** : compréhension des fondamentaux infrastructure crypto.

### Question 2 — Spot vs futures
> *"Quelle différence entre trader le spot crypto et le futures perpétuel ? Pourquoi tu choisirais l'un ou l'autre ?"*

**Mesure** : compréhension des marchés crypto.

---

## BLOC 02 — Cycles & Macro

### Question 3 — Halving & cycles
> *"Le Bitcoin halving — c'est quoi exactement, à quelle fréquence, et pourquoi ça impacte le prix ? Sur les 4 derniers cycles, qu'as-tu observé en termes de timing accumulation/markup/distribution/markdown ?"*

**Mesure** : compréhension cyclique BTC (la base macro crypto).

### Question 4 — Macro liquidity
> *"Tu sais ce qu'est le M2 money supply ? Le DXY (dollar index) ? Comment penses-tu que ces métriques macro affectent le crypto ?"*

**Mesure** : intégration macro globale dans la lecture crypto.

---

## BLOC 03 — Structure de marché

### Question 5 — Tendance vs range
> *"Définis une tendance haussière en termes de structure de marché. Comment tu identifies un changement de structure (MSS / CHoCH) ? Donne-moi un exemple concret de ton expérience."*

**Mesure** : compréhension du langage universel des charts.

---

## BLOC 04 — Analyse technique classique

### Question 6 — Indicateurs
> *"Parmi RSI, MACD, EMA, Bollinger, VWAP, volume profile — lesquels tu utilises et pourquoi ? Lesquels tu trouves inutiles et pourquoi ?"*

**Mesure** : maturité technique (un débutant utilise tout, un expert filtre).

### Question 7 — Fibonacci
> *"Tu utilises le Fibonacci retracement ? Sur quel swing tu le traces ? Quels niveaux tu surveilles le plus ?"*

**Mesure** : maîtrise de l'outil le plus mal utilisé en crypto.

---

## BLOC 05 — SMC/ICT

### Question 8 — Concepts SMC
> *"Sans Google : combien de ces concepts tu peux EXPLIQUER à quelqu'un qui débute : FVG, OB, BB, BPR, BSL, SSL, MSS, CHoCH, OTE, Premium/Discount, Killzones, IFVG ?"*

**Mesure** : maîtrise SMC/ICT (12 concepts à maîtriser pour être expert).

### Question 9 — Sweep & liquidité
> *"C'est quoi un sweep de liquidité ? Pourquoi le marché va chercher cette liquidité ? Comment tu trades autour de ça ?"*

**Mesure** : compréhension de la dynamique smart money vs retail.

---

## BLOC 06 — On-chain

### Question 10 — Métriques on-chain
> *"MVRV, NUPL, exchange inflows/outflows, miners selling, addresses actives — combien de ces métriques on-chain tu connais et utilises pour décider ? Lesquelles tu n'as jamais regardées ?"*

**Mesure** : intégration on-chain dans l'analyse (la plupart des traders crypto ignorent ça).

---

## BLOC 07 — Sentiment & flux

### Question 11 — Sentiment quantifié
> *"Le Fear & Greed Index, les funding rates, l'open interest, le ratio long/short — tu sais lire ces 4 métriques et les utiliser pour timing ? Comment tu interprétais le marché en mode "extreme greed" vs "extreme fear" ?"*

**Mesure** : utilisation des outils sentiment.

---

## BLOC 08 — Fondamentaux projet

### Question 12 — Tokenomics
> *"Quand tu regardes un projet crypto avant d'investir : quels critères de tokenomics tu vérifies ? Supply, vesting, emissions, distribution, equipe, audits — tu fais quoi exactement ?"*

**Mesure** : maturité fondamentale (la plupart des traders ignorent ça).

---

## BLOC 09 — Risk management

### Question 13 — Risk par trade & expectancy
> *"Quel pourcentage de ton capital tu risques par trade ? Tu connais l'expectancy ? Comment tu la calcules ? Quelle est ta cible ?"*

**Mesure** : maturité risk (le facteur #1 de survie).

---

## BLOC 10 — Edge perso

### Question 14 — Méthode actuelle
> *"Tu as une méthode de trading précise que tu suis à 100 % ? Si oui, décris-la en 3 phrases. Si non, comment tu décides de prendre un trade ?"*

**Mesure** : maturité méthodologique.

---

## BONUS — Psychologie & engagement

### Question 15 — Discipline & engagement
> *"Sur les 6 derniers mois : combien de fois tu as dévié de ton plan de trade après une perte ? Combien de mois calendaires tu as terminés profitable ? Et : es-tu prêt à investir 6-12 mois dans un parcours sérieux sans toucher à ton vrai capital pendant les 1-3 premiers mois ?"*

**Mesure** : 3 dimensions critiques en une question — discipline, performance réelle, engagement long terme.

---

## ANALYSE & SCORING (instructions Nodex)

À la fin, calculer pour chaque bloc :

| Réponse type | Score bloc |
|---|---|
| "Jamais entendu" / "C'est quoi ?" | 0 |
| "J'ai vu ça quelque part mais je sais pas vraiment" | 1 |
| "Je comprends mais je l'utilise rarement" | 2 |
| "Je l'utilise régulièrement, je sais expliquer" | 3 |
| Réponse experte avec exemples concrets et nuances | 4 |

Puis lire `analyse-et-programme.md` pour construire le parcours personnalisé.

---

## Fin du questionnaire

Après la Q15, Nodex dit :

> *"OK, j'ai tes 15 réponses. Laisse-moi 2 minutes pour analyser ton profil sur les 10 blocs et te construire un parcours personnalisé. Je ne vais pas te faire perdre du temps sur ce que tu maîtrises déjà — mais je vais identifier précisément les trous critiques."*

Puis Nodex lit `onboarding/analyse-et-programme.md` et applique la grille.

---

**Version** : 1.0 · **15 questions sur 10 blocs** · **Diagnostic personnalisé**
