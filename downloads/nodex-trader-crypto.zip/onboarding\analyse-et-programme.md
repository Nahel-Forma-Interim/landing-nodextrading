# Analyse + Construction du parcours personnalisé

> **Objectif** : à partir des scores du questionnaire diagnostic (15 questions, 10 blocs notés 0-4), construire un parcours sur-mesure qui :
> 1. Saute les blocs maîtrisés (score 3-4)
> 2. Renforce les blocs partiels (score 2)
> 3. Construit les blocs absents (score 0-1)

---

## Étape 1 — Profilage global

À partir de la moyenne des scores sur les 10 blocs :

| Moyenne globale | Profil | Estimation parcours |
|---|---|---|
| **0,0 - 1,0** | **Débutant absolu** | 8-12 mois (10 blocs complets + pratique) |
| **1,1 - 2,0** | **Débutant éclairé** | 6-9 mois (rappels rapides + blocs critiques) |
| **2,1 - 2,8** | **Intermédiaire** | 4-6 mois (renforcement ciblé + blocs avancés) |
| **2,9 - 3,5** | **Avancé** | 3-4 mois (compléter trous + bloc 10 edge perso) |
| **3,6 - 4,0** | **Expert** | 1-2 mois (uniquement bloc 10 + validation 100 backtests) |

⚠️ **Aucun parcours < 1 mois.** Même un expert doit valider sa méthode par 100+ backtests pour être considéré rentable durable.

---

## Étape 2 — Identification des blocs critiques

### Blocs FONDATIONS (tout repose dessus, score 2 minimum requis)

- **Bloc 01 — Fondamentaux** : si score < 2 → DÉMARRER ICI obligatoirement
- **Bloc 09 — Risk management** : si score < 2 → ENCHAÎNER après 01 (risk avant tout)
- **Bloc 03 — Structure de marché** : si score < 2 → faire avant tout bloc technique

### Blocs MACRO (sans ça, on trade contre le vent)

- **Bloc 02 — Cycles & Macro** : si score < 2 → critique en crypto
- **Bloc 06 — On-chain** : si score < 2 → fortement recommandé
- **Bloc 07 — Sentiment & flux** : si score < 2 → utile en complément

### Blocs TECHNIQUE (le quotidien du trader)

- **Bloc 04 — Analyse technique** : si score < 2 → bases nécessaires
- **Bloc 05 — SMC/ICT** : si score < 2 → si l'apprenant veut SMC comme méthode

### Blocs FONDAMENTAUX (pour investir long terme aussi)

- **Bloc 08 — Fondamentaux projet** : optionnel pour trading pur, essentiel pour positions long terme

### Bloc EDGE PERSO (final)

- **Bloc 10 — Edge perso** : OBLIGATOIRE en fin de parcours (même les experts), validation 100 backtests

---

## Étape 3 — Construction du parcours

### Méthode

1. Classer les 10 blocs par ordre de priorité selon les scores
2. Toujours commencer par les **fondations** (01, 09, 03 si scores < 2)
3. Enchaîner avec **macro** (02, 06, 07) — donne le contexte
4. Puis **technique** (04, 05) — l'opérationnel
5. **Fondamentaux projet** (08) optionnel mais recommandé
6. **Edge perso** (10) toujours en fin

### Exemple de parcours pour chaque profil

#### Débutant absolu (moyenne < 1)
```
Mois 1 : Bloc 01 (fondamentaux) → Bloc 09 (risk basics)
Mois 2 : Bloc 02 (cycles) → Bloc 03 (structure)
Mois 3 : Bloc 04 (analyse technique)
Mois 4 : Bloc 05 (SMC/ICT)
Mois 5 : Bloc 06 (on-chain) → Bloc 07 (sentiment)
Mois 6 : Bloc 08 (fondamentaux projet)
Mois 7-9 : Bloc 09 approfondi (allocation, expectancy avancée)
Mois 10-12 : Bloc 10 (edge perso) — construction + 100 backtests
```

#### Débutant éclairé (moyenne 1,1 - 2)
```
Mois 1 : Compléter bloc 01 + Bloc 09 (risk basics)
Mois 2 : Bloc 02 (cycles macro)
Mois 3 : Bloc 03 + Bloc 04 (technique combinée)
Mois 4 : Bloc 05 (SMC) + Bloc 07 (sentiment)
Mois 5 : Bloc 06 (on-chain) + Bloc 08 (projets)
Mois 6-9 : Bloc 10 (edge perso) — construction + 100 backtests
```

#### Intermédiaire (moyenne 2,1 - 2,8)
```
Mois 1 : Renforcement blocs faibles (selon scores)
Mois 2 : Blocs 02/06/07 si pas maîtrisés (macro + on-chain + sentiment)
Mois 3 : Bloc 09 approfondi (Kelly, allocation)
Mois 4-6 : Bloc 10 (edge perso) — construction + 100 backtests
```

#### Avancé (moyenne 2,9 - 3,5)
```
Mois 1 : Compléter trous identifiés (probablement on-chain ou fondamentaux projet)
Mois 2 : Bloc 09 expectancy + sizing avancé
Mois 3-4 : Bloc 10 (edge perso) — construction + 100 backtests
```

#### Expert (moyenne 3,6+)
```
Mois 1 : Valider blocs identifiés comme faibles
Mois 2 : Bloc 10 — formalisation edge + 100 backtests
```

---

## Étape 4 — Présentation à l'apprenant

Nodex présente le parcours en disant :

> *"Voici ce que je vois de toi :*
>
> *[résumé du profil en 4-5 phrases : forces, faiblesses, niveau global]*
>
> *Sur les 10 blocs, tu maîtrises déjà : [bloc X, Y, Z]. Tu as des bases sur : [A, B]. Tu as des trous critiques sur : [C, D, E]. On va donc concentrer notre temps sur ces trous, et compléter le reste en transversal.*
>
> *Voici le parcours que je te propose :*
>
> *[afficher le parcours adapté au profil]*
>
> *Méthode pédagogique : à chaque bloc, je vais te poser des questions, te faire analyser des cas réels, te faire construire des plans. Pas de cours magistraux. Tu apprends en RAISONNANT, pas en récitant.*
>
> *À la fin du bloc 10, tu auras TA propre méthode de trading, validée par 100+ backtests, avec une expectancy positive démontrée. Tu pourras trader sans moi.*
>
> *Tu valides ce parcours ?"*

---

## Étape 5 — Démarrage

Une fois le parcours validé par l'apprenant :

1. Écrire `state/parcours.json` avec :
   - Scores des 10 blocs
   - Parcours suggéré (ordre des blocs)
   - Bloc actuel : le premier
   - Date de démarrage

2. Écrire `state/profil.md` avec :
   - Niveau global
   - Forces / faiblesses
   - Objectifs déclarés
   - Disponibilité (heures/semaine)

3. **Démarrer le premier bloc** : ouvrir `blocs/[XX-bloc-name]/intro.md`

---

## Règles importantes pour Nodex

1. **NE PAS** imposer un ordre strict — l'apprenant peut sauter / revenir
2. **TOUJOURS** valider avec l'apprenant avant de figer le parcours
3. **NE PAS** promettre une durée ferme — c'est une estimation
4. **TOUJOURS** rappeler que le bloc 10 (edge perso) est OBLIGATOIRE pour valider la rentabilité
5. **NE PAS** noter publiquement les scores (ce sont des indicateurs internes pour Nodex)

---

**Version** : 1.0 · **Construction parcours adaptatif** · **10 blocs**
