# Bloc 07 — Sentiment & flux

> **Le marché bouge sur 2 carburants : la liquidité et la psychologie de masse. On a vu la liquidité (bloc 02). Place à la psychologie quantifiée.**

---

## Prérequis

- Bloc 02 (cycles & macro)

---

## Objectifs pédagogiques

1. **Lire** Fear & Greed Index (sentiment global crypto)
2. **Comprendre** funding rates (longs vs shorts qui paie qui)
3. **Lire** open interest (volume des positions ouvertes en futures)
4. **Utiliser** ratio long/short (Binance public)
5. **Surveiller** options flow (puts/calls institutionnels)
6. **Identifier** les pivots de sentiment majeurs

---

## Leçons (7 leçons)

### Leçon 7.1 — Fear & Greed Index (le thermomètre)
> Source : alternative.me/crypto/fear-and-greed-index
> Lecture : <20 = extreme fear (achat opportunité) · >80 = extreme greed (vente opportunité)
> Historique : zones "extreme" sont des pivots quasi systématiques

### Leçon 7.2 — Funding rates (qui paie qui en futures)
> Concepts : longs paient shorts si funding positif, shorts paient longs si négatif
> Lecture : funding extrême positif = trop de longs = squeeze short imminent
> Sources : coinglass.com, binance.com

### Leçon 7.3 — Open Interest (volume positions ouvertes)
> Concepts : OI monte = capital arrive · OI baisse = capital sort
> Combinaison avec prix : prix ↑ + OI ↑ = trend solide · prix ↑ + OI ↓ = short squeeze (faible)

### Leçon 7.4 — Ratio long/short
> Sources : Binance public ratio
> Lecture : si retail majoritairement long → contrarien souvent gagnant

### Leçon 7.5 — Options flow (puts/calls)
> Concepts : put/call ratio, max pain, gamma exposure
> Sources : laevitas.ch, deribit.com

### Leçon 7.6 — Liquidations heatmap (où sont les stops)
> Sources : coinglass.com/LiquidationData
> Lecture : zones liquidations massives = aimants à prix

### Leçon 7.7 — Synthèse : dashboard sentiment quotidien
> 4 indicateurs à check chaque matin (5 min)

---

## Validation du bloc

Analyser le sentiment actuel et prédire la direction probable des 7 prochains jours avec arguments chiffrés.

---

**Bloc 07** · **Durée estimée : 1-2 semaines**
