# Checklist pré-trade V5.3 (22 points)

**Règle hard rule** : si UNE seule des 9 hard rules manque (cf. liste en bas) → **GRADE = SKIP** quoi que tu aies coché d'autre.
**Règle scoring** : 22/22 = A+ · 19-21 = A · 16-18 = B+ · 13-15 = B (paper only) · <13 = C (skip)

---

## 🌐 Contexte HTF (6)
- [ ] Session **London (08h-11h CET) ou NYAM (14h30-18h CET)** ⚠️ **HARD RULE**
- [ ] Pas de news rouge dans 30 min
- [ ] Biais D1 bullish (HH + HL)
- [ ] Biais H4 aligné avec D1
- [ ] POI majeur D1 marqué (FVG D1 / OB D1 / BB D1)
- [ ] POI H4 marqué (aligné avec contexte H4)

## 📐 Préparation Fibo + POI (6)
- [ ] Fibo H1 tracé (vue d'ensemble bias)
- [ ] Asia Low + PDH/PDL marqués
- [ ] Fibo M15 tracé sur le swing actif
- [ ] **POI identifié dans la zone discount (sous 0.5 Fibo M15)** ⚠️ **HARD RULE V5.3**
- [ ] **Le sweep balaye le POI dans la zone discount/OTE** ⚠️ **HARD RULE V5.3**
- [ ] Sweep valide (3 critères : casse + mèche ≥ 2× corps + close au-dessus) ⚠️ **HARD RULE**

## 🕯️ Confirmation entrée (3)
- [ ] **Bougie 1 mitige le POI** (touche/entre dans la zone)
- [ ] **Bougie 2 clôture au-dessus du high de la bougie 1** ⚠️ **HARD RULE V5.3** (2 bougies obligatoires)
- [ ] Entry en zone OTE 0.62-0.79 (bonus A+)

## 💎 Qualité setup (4)
- [ ] Volume sweep ≥ 3× moyenne 20 bougies
- [ ] BTC bullish sur H4 ⚠️ **HARD RULE**
- [ ] RR visé ≥ 2,5:1 ⚠️ **HARD RULE** (RR < 2:1 = SKIP)
- [ ] Pas de résistance majeure entre Entry et TP2

## 💰 Risk (3)
- [ ] Risk ≤ 1,2 % ⚠️ **HARD RULE**
- [ ] Taille position calculée (formule sizing)
- [ ] Pas de 2 SL consécutifs aujourd'hui ⚠️ **HARD RULE**

---

## 🚫 Les 9 HARD RULES V5.3 (override absolu)

Si UNE seule manque → grade = SKIP, peu importe le score :

1. ❌ Hors London ou NYAM (08h-11h ou 14h30-18h CET)
2. ❌ BTC bear sur H4
3. ❌ Sweep non valide (3 critères pas réunis)
4. ❌ **POI absent de la zone discount (sous 0.5 Fibo M15)** [V5.3]
5. ❌ **Sweep ne balaye pas un POI** (sweep "vide" sans confluence) [V5.3]
6. ❌ **2 bougies de confirmation manquantes** (1 seule = pas suffisant V5.3)
7. ❌ RR < 2:1
8. ❌ Risk > 1,2 %
9. ❌ 2 SL consécutifs aujourd'hui

---

## 🧠 Auto-évaluation psy (hors checklist, mais OBLIGATOIRE)

Avant CHAQUE trade, vérifie en silence :
- ① Dormi 7h+ ?
- ② Pas en boucle post-perte ?
- ③ Trade prévu dans le plan du jour ?

Si UN des 3 KO → SKIP, peu importe le grade.

---

## 📊 Scoring V5.3 → action concrète

| Score | Grade | Risk | RR min | Position | Action |
|-------|-------|------|--------|----------|--------|
| 22/22 | A+ | 1,2 % | 3:1 | 100 % | Entrer en confiance |
| 19-21 | A | 1 % | 2,5:1 | 100 % | Entrer standard |
| 16-18 | B+ | 0,75 % | 2,5:1 | 75 % | Entrer prudent |
| 13-15 | B | 0,5 % | 2:1 | 50 % | **PAPER seulement** |
| <13 | C | — | — | — | **SKIP IMPÉRATIF** |

**Distribution attendue sur 30 trades V5.3** : ~10-15 % A+ · ~30 % A · ~30-35 % B+ · ~15-20 % B · ~5-10 % C.

## 🔄 Différences clés V5.2 → V5.3 (rappel)

| Élément | V5.2 | V5.3 |
|---|---|---|
| Sweep position | N'importe où | **Sous 0.5 Fibo M15, dans la zone POI** |
| POI utilisé | FVG only | **6 POI hiérarchisés** (BPR/BB/OB/FVG/BISI/IFVG) |
| Confirmation | 1 bougie 2 | **2 bougies (mit-bar + close au-dessus)** |
| Sessions | NYAM only | **London + NYAM** |
| Filtre Fibo | Aucun | **Entry sous 0.5 obligatoire (discount)** |
