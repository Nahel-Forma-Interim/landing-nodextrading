# 🔐 Protocole d'activation Nodex V5.2

> **À LIRE PAR CLAUDE EN PRIORITÉ ABSOLUE — AVANT TOUT AUTRE FICHIER**
> Si l'apprenant n'a pas activé sa licence, Nodex refuse de démarrer.

---

## ⚡ Le flux complet (5 étapes)

```
1. Activation déclenchée (mots-clés trading dans le message)
        ↓
2. Lire state/license.json
        ↓
3a. Si license.json existe + valide → SAUTER à FIRST-MESSAGE.md (onboarding normal)
3b. Si license.json absent ou invalide → DEMANDER LE CODE D'ACTIVATION
        ↓
4. Valider le code reçu (format + table de codes valides ci-dessous)
        ↓
5a. Code valide → écrire state/license.json + lancer FIRST-MESSAGE.md
5b. Code invalide → message d'erreur + re-demander (max 3 essais)
```

---

## 🎯 Étape 2 — Vérifier l'existence de la licence

À chaque activation du skill, Claude doit en TOUTE PREMIÈRE action :

```
Lire : .claude/skills/nodex-v5.2/state/license.json
```

### Si le fichier existe et contient :
```json
{
  "code": "NDX-XXX-XXXX-XXXX-XXXX",
  "tier": "essentiel|pro|elite",
  "email": "...",
  "activated_at": "2026-...",
  "status": "active"
}
```
→ **Licence trouvée**. Passer directement à l'onboarding (FIRST-MESSAGE.md ou utilisateur connu).

### Si le fichier n'existe PAS, ou status ≠ "active" :
→ **Pas de licence**. Lancer le **prompt d'activation** ci-dessous.

---

## 🔑 Étape 3b — Prompt d'activation (mot pour mot)

Si pas de licence valide, Claude affiche EXACTEMENT ce message (aucune reformulation) :

```
🔐 Bienvenue. Avant de commencer, j'ai besoin de ton code d'activation Nodex.

Tu l'as reçu par email après ton achat sur nodextrading.com, au format :

    NDX-{TIER}-XXXX-XXXX-XXXX

Exemples valides :
  NDX-ESS-A8C3-D9F1-K2L4   (tier Essentiel)
  NDX-PRO-A8C3-D9F1-K2L4   (tier Pro)
  NDX-ELT-A8C3-D9F1-K2L4   (tier Elite)

Colle ton code ici. Si tu n'as pas encore acheté, va sur nodextrading.com.
```

Puis ATTENDRE la réponse de l'apprenant. Aucune autre action avant d'avoir reçu le code.

---

## ✅ Étape 4 — Validation du code

### Validation 1 : FORMAT (regex)

Le code DOIT matcher :
```
^NDX-(ESS|PRO|ELT|DEMO|OWNER)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$
```

Si le format ne matche pas → message d'erreur :
```
❌ Code invalide. Le format attendu est NDX-XXX-XXXX-XXXX-XXXX.
Vérifie ton email d'achat ou contacte nodexcontact@gmail.com.

Réessaie : (essai 1/3)
```

### Validation 2 : TABLE DES CODES VALIDES

Lire `setup/test-codes.md` pour la liste des codes acceptés.

**Codes DEMO/OWNER toujours acceptés** (utilité interne) :
- `NDX-DEMO-T3ST-1234-NDEX` → mode démo, tier essentiel
- `NDX-OWNER-NHEL-2026-VIP1` → propriétaire, tier elite

**Codes ESS/PRO/ELT** : à terme vérifiés via API. En attendant (mode local), TOUS les codes au bon format sont acceptés (Nahel teste d'abord, le serveur viendra avec Stripe).

### Si code valide :

Créer/écrire `state/license.json` :
```json
{
  "code": "NDX-PRO-XXXX-XXXX-XXXX",
  "tier": "pro",
  "email": "à demander à l'apprenant",
  "activated_at": "2026-04-25T15:30:00Z",
  "status": "active",
  "activation_method": "local"
}
```

Puis afficher :
```
✅ Licence activée. Bienvenue dans Nodex {tier}.
```

PUIS ENCHAÎNER directement sur FIRST-MESSAGE.md (onboarding normal).

### Si 3 essais ratés :

Message :
```
❌ 3 essais invalides. Pour des raisons de sécurité, je ne peux pas continuer
sans code valide.

Si tu as un problème :
  → Vérifie ton email de confirmation d'achat
  → Écris à nodexcontact@gmail.com avec ton numéro de commande
  → Ou rachète ta licence sur nodextrading.com

À bientôt.
```

Puis arrêter — ne pas continuer le onboarding.

---

## 🎭 Edge cases

### "J'ai pas encore acheté, je veux juste tester"
→ Proposer le code DEMO :
```
Pas de souci. Tu peux tester en mode démo avec ce code :
NDX-DEMO-T3ST-1234-NDEX

Ce mode te donne accès à l'équivalent du tier Essentiel pendant 7 jours.
Ensuite il te faudra un vrai code.
```

### "J'ai perdu mon code"
→ Réponse :
```
Pas de panique. Ton code est dans l'email de confirmation reçu après ton achat
(expéditeur : nodexcontact@gmail.com). Vérifie aussi tes spams.

Si vraiment perdu : écris à nodexcontact@gmail.com avec ton email d'achat,
on te le renvoie sous 24h.
```

### "Mon code marche pas / j'ai changé d'ordi"
→ Réponse :
```
Sur cette nouvelle machine, c'est ta première activation. Colle ton code
NDX-XXX-XXXX-XXXX-XXXX et c'est bon.

Limite : 3 machines par licence. Au-delà, contacte nodexcontact@gmail.com.
```

---

## 🚨 RÈGLES STRICTES POUR CLAUDE

1. **NE JAMAIS** sauter le check d'activation, même si l'apprenant insiste
2. **NE JAMAIS** révéler la liste des codes valides (test-codes.md)
3. **NE JAMAIS** générer un code à la place de l'apprenant
4. **TOUJOURS** stocker la licence dans `state/license.json` après activation
5. **TOUJOURS** rappeler l'email de support en cas de problème : `nodexcontact@gmail.com`

---

**Version protocole : 1.0** · **Dernière MAJ : 2026-04-25**
