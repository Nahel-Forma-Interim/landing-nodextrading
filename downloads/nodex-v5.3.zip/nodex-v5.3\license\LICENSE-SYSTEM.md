# 🔒 Système de licence Nodex V5.2 — Stratégie anti-piratage

## Le problème

Un skill Claude est un dossier de fichiers .md en texte brut. **N'importe qui avec les fichiers peut les copier** à un autre acheteur. C'est le challenge classique des produits digitaux.

## La solution en 5 couches

Combiner plusieurs mécanismes pour rendre le piratage **difficile + traçable + dissuasif**.

---

## 🛡️ Couche 1 — Licence personnelle (watermarking)

### Principe
Chaque acheteur reçoit un skill **personnalisé avec son identité** embedded dans plusieurs fichiers.

### Implémentation
Lors de la vente, on génère automatiquement :

```json
{
  "license_id": "NDX-V52-20260424-A7F3K9",
  "buyer_name": "Jean Dupont",
  "buyer_email": "jean@example.com",
  "purchase_date": "2026-04-24",
  "license_type": "PERSONAL",
  "version": "5.2.2",
  "fingerprint": "sha256 des fichiers + infos acheteur"
}
```

Le fichier `license/license.json` est **unique pour chaque acheteur**.

### Watermarks cachés
Plusieurs fichiers contiennent des **références invisibles** à l'acheteur :
- Commentaires HTML invisibles
- Metadata dans les .md
- Variables dans le JavaScript interne
- Checksums uniques

Si Nahel trouve une copie du skill en ligne → il peut **identifier exactement qui l'a piraté**.

---

## 🛡️ Couche 2 — Activation par code

### Principe
Au **premier usage**, Nodex demande le code d'activation.

### Protocole
```
Nodex : "Bonjour ! Avant de commencer, merci de coller ton code d'activation (reçu par email après achat)."

Apprenant : "NDX-V52-20260424-A7F3K9"

Nodex vérifie :
1. Le code est dans la liste des codes valides (fichier license/codes.json)
2. Le code n'est pas déjà activé sur un autre PC
3. Si OK → écrit dans license/activation.json (date + machine ID)
4. Si déjà activé ailleurs → refuse + alerte Nahel par email
```

### Suivi
Nahel a un tableau (Google Sheet / Notion / Airtable) :

| Code | Acheteur | Email | Date achat | 1ère activation | Statut |
|------|----------|-------|------------|----------------|--------|
| NDX-V52-...A7F3 | Jean Dupont | jean@... | 24/04 | 25/04 | Actif |
| NDX-V52-...B8K4 | Marie L. | marie@... | 26/04 | - | En attente |

---

## 🛡️ Couche 3 — Clause CGV + licence légale

### Principe
Un contrat strict à accepter avant téléchargement.

### Extrait CGV :

> *"La présente licence confère un droit d'usage PERSONNEL et NON TRANSFÉRABLE du skill Nodex V5.2. Toute redistribution, revente, partage, publication, ou reproduction (totale ou partielle) est STRICTEMENT INTERDITE et constitue une violation de propriété intellectuelle passible de poursuites judiciaires."*

### Signature électronique
Au paiement → acceptation CGV obligatoire (checkbox) → enregistrement horodaté.

---

## 🛡️ Couche 4 — Distribution privée contrôlée

### Options

#### Option A — GitHub privé + invitations individuelles
- Repo privé `nodex-skill-v5.2-licensed`
- Chaque acheteur reçoit une **invitation GitHub personnelle** (non transférable)
- Après paiement → on envoie l'invitation à son compte GitHub
- **Avantage** : GitHub tracke qui accède au code

#### Option B — Gumroad / Stripe + livraison par email
- Fichier ZIP téléchargeable **1 seule fois par acheteur**
- Lien expire après 24h
- Watermark unique dans le ZIP

#### Option C — Plateforme SaaS (long terme)
- Tu ne vends **PAS le skill**
- Tu vends **l'accès à une plateforme** où l'acheteur utilise Claude + le skill via TON interface
- 100% de contrôle, 0% de piratage possible
- ⚠️ Demande une infra backend

### Recommandation
**Commencer par Option A (GitHub privé)** : simple, déjà en place, traçable.

---

## 🛡️ Couche 5 — Mise à jour régulière + obsolescence

### Principe
Si quelqu'un pirate le skill, sa copie **devient obsolète** rapidement.

### Mécanisme
- Nouvelle version du skill tous les **15-30 jours** (corrections, optimisations)
- Seuls les acheteurs légitimes reçoivent les MAJ (via leur accès GitHub)
- Les pirates ont une version figée qui vieillit

### Avantages
- Pression à être client légitime pour avoir les updates
- Dissuasion forte : payer une fois = 1 an de MAJ gratuites

---

## 💼 Pricing suggéré (à titre indicatif)

| Tier | Prix | Contenu |
|------|------|---------|
| **Essentiel** | 497 € | Skill V5.2 + formation HTML + support email 30 jours |
| **Pro** | 997 € | Essentiel + 3 sessions coaching Zoom 1h + MAJ 1 an |
| **Elite** | 2 497 € | Pro + groupe mastermind Discord + MAJ 3 ans + trade alerts |

**Règle marketing** : tarif élevé = perçu comme qualité. En dessous de 300 €, risque de dévaluer le produit.

---

## 📋 Mise en place concrète (checklist)

### Phase de lancement (après validation Phase 4 de Nahel)

- [ ] Créer repo GitHub **privé** `nodex-skill-licensed`
- [ ] Mettre en place **Stripe** ou Gumroad pour paiement
- [ ] Rédiger **CGV + licence juridique** (avec avocat idéalement)
- [ ] Créer **landing page** de vente (Nodex Trading)
- [ ] Setup **Airtable / Notion** pour suivi acheteurs
- [ ] Automatiser **génération de code** par achat (via Zapier)
- [ ] Système de **watermarking** automatique à l'achat
- [ ] Template **email de livraison** avec code
- [ ] **Testimonials** de 5-10 acheteurs beta (Fatah + équipe)

### Go-to-market

1. Phase 1 : **offre aux proches** (50 €) pour récolter 5-10 testimonials
2. Phase 2 : **lancement communauté crypto** (497 €) — landing + posts Twitter
3. Phase 3 : **vente pérenne** — programme d'affiliation + contenu

---

## 🎯 Vision long terme

> **Ce skill n'est pas un produit. C'est l'entrée d'un écosystème Nodex Trading.**

Roadmap :
- **V1** : skill Nodex V5.2 (produit de base)
- **V2** : skill + Discord mastermind
- **V3** : SaaS Nodex (plateforme web)
- **V4** : app mobile Nodex Trading Companion
- **V5** : copy-trading (si agréments nécessaires)

Le skill **lance l'écosystème**. Chaque acheteur devient un client potentiel des produits V2-V5.
