# Procédure : Emergency Stop

**Déclenche quand** : DD élevé, 2 SL consécutifs, panique, tilt, discussion émotionnelle.

## Protocole Claude

### 1. Diagnostic rapide
Vérifier state/metrics.md :
- DD actuel ? (si ≥ 5 % → niveau warning)
- SL consécutifs aujourd'hui ? (si ≥ 2 → STOP 24h)
- Trades aujourd'hui ? (si ≥ 3 → limite atteinte)
- État mental Nahel (tilt, stress, revenge trading) ?

### 2. Actions obligatoires selon diagnostic

#### Si 2 SL consécutifs dans la journée
**STOP TRADING 24h.** Ferme TradingView. Reviens demain.

#### Si DD ≥ 5 % sur 5 trades
**PAUSE 48h minimum**. Revue méthode avec Claude :
- Vérifier si les 18 points étaient cochés
- Vérifier si le trailing a été bien exécuté
- Identifier les erreurs (Demon Finder)

#### Si DD ≥ 10 %
**ARRÊT COMPLET**. Plus de trades.
- Revue complète de la méthode
- Ajustement éventuel V5.3
- Reprise seulement après 1 semaine minimum

#### Si panique / tilt / revenge trading
**Ferme l'écran.** Sors. Marche 30 min.
- Rappeler : "Une perte ≠ une erreur. C'est le coût du business."
- Rappeler : "Le marché n'est pas ton ennemi. Toi-même, tu es ton ennemi."
- Demander : qu'est-ce qui te stresse vraiment ? (souvent hors trading)

### 3. Ce que Claude ne fait JAMAIS en urgence
- ❌ Valider un nouveau trade "pour rattraper"
- ❌ Augmenter le risk
- ❌ Proposer un nouveau setup hors plan
- ❌ Minimiser le stress ("ça va aller, pas grave")

### 4. Ce que Claude fait TOUJOURS en urgence
- ✅ Arrêter le trading
- ✅ Rappeler les règles
- ✅ Poser des questions ouvertes pour évacuer
- ✅ Proposer un plan de retour (24-48-72h selon gravité)
