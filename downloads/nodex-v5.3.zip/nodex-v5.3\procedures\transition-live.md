# 🌊 Phase 5 — Transition Paper → Live (le grand saut)

> **Objectif** : passer de la simulation au vrai argent SANS exploser le capital sur les premiers trades.
> **Durée typique** : 4-6 semaines · **Trades cible** : 15 trades live progressifs

---

## 🧠 LA RÈGLE D'OR DE CETTE PHASE

> **Le live n'est PAS le paper avec de l'argent dedans.**
>
> En paper, tu peux te tromper sans douleur. En live, ton cerveau réagit
> chimiquement (cortisol, dopamine) et change ton jugement. Ton WR va
> CHUTER de 10-15 % sur les premiers trades, c'est NORMAL et PRÉVU.
>
> La transition doit être PROGRESSIVE pour que ton mental s'habitue.

---

## 💰 CAPITAL DE DÉPART — RECOMMANDATION NODEX

| Profil | Capital live initial | Pourquoi |
|---|---|---|
| **Standard** | **500€** | Assez pour que les gains soient motivants, assez petit pour pas paniquer |
| Prudent | 200€ | Si tu n'as jamais eu d'argent en jeu, commence là |
| Confiant | 1000€ max | Tu as déjà tradé en réel ailleurs et tu maîtrises ton mental |

⚠️ **NE JAMAIS dépasser 1000€ sur cette phase**, même avec un capital plus gros.
Le but n'est pas de gagner, c'est d'**APPRENDRE LE LIVE**.

---

## 📏 TAILLE DE POSITION PROGRESSIVE (3 paliers)

### Palier 1 — Trades 1 à 5 (les "mini-live")
- Risque par trade : **0,25 %** du capital live
- Sur 500€ : **1,25€ de risque max** par trade
- Objectif : tu te familiarises au stress de l'argent réel
- **Ne pas viser le profit.** Viser l'exécution propre.

### Palier 2 — Trades 6 à 10 (les "demi-live")
- Risque par trade : **0,5 %** du capital live
- Sur 500€ : **2,50€ de risque max** par trade
- Objectif : doubler la pression, voir si tu tiens
- À ce stade, ton WR doit déjà se stabiliser

### Palier 3 — Trades 11 à 15 (les "vrais live")
- Risque par trade : **1 %** du capital live (taille normale Nodex)
- Sur 500€ : **5€ de risque max** par trade
- Objectif : tu trades comme tu le feras à long terme
- **Si tu finis 11→15 profitable, tu passes en Phase 6.**

⚠️ **Si tu perds 3 trades consécutifs DANS UN PALIER, tu RECULES d'un palier.**
Ce n'est PAS un échec, c'est de la gestion de risque.

---

## 🛑 LES 5 STOPS AUTOMATIQUES (sans négociation)

1. **3 SL consécutifs** sur la session du jour → **STOP 24h**
2. **Capital tombe à -10 %** du capital initial → **STOP 7 jours + audit**
3. **Capital tombe à -20 %** → **STOP DÉFINITIF + retour Phase 4**
4. **2 trades pris hors checklist** sur 10 → **STOP + audit discipline**
5. **Tu trades en revanche d'un trade perdant** → **STOP + journal émotionnel obligatoire**

→ Lire `procedures/emergency-stop.md` pour les protocoles d'urgence.

---

## 📓 NOUVEAU JOURNAL : 4 COUCHES OBLIGATOIRES

À CHAQUE trade live, tu remplis :

1. **Couche technique** (comme en paper) : entry, SL, TP, RR, asset
2. **Couche checklist** : 18 points cochés / non cochés
3. **Couche émotionnelle (NOUVEAU)** :
   - Avant : peur (1-10) / excitation (1-10) / fatigue (1-10)
   - Pendant : nombre de fois où tu as voulu modifier le trade
   - Après : satisfaction (1-10) / frustration (1-10) / leçon
4. **Couche contextuelle** : news du jour, état général du marché, ton humeur perso

→ Template : `templates/journal-live-trade.md`

---

## 🗓️ ROUTINE QUOTIDIENNE LIVE

### Pré-session (10 min, OBLIGATOIRE)
1. Ouvrir le tracker → cocher "session démarrée"
2. Lire `references/checklist-18-points.md`
3. Vérifier news macro du jour (Forex Factory)
4. Auto-évaluation : "Suis-je en état de trader ?" (sommeil, stress perso, focus)
5. **Si auto-évaluation faible → SKIP la session**

### Pendant session (3h max, NYAM 14h30-17h30 CET)
- 1 setup max par session (sauf si A+ écrasant)
- Pas de trade hors NYAM, jamais
- Pas de chart hors watchlist
- Discipline absolue, pas de "et si" ou "tiens je vais juste regarder"

### Post-session (15 min, OBLIGATOIRE)
1. Journaler le(s) trade(s) avec les 4 couches
2. Update `state/metrics.md` et `state/trades-log.md`
3. Update `state/live-progression.md` (palier actuel, nb trades restants)
4. Fermer le terminal. **Pas de revenge trade le soir.**

---

## 🎯 CHECKPOINTS NODEX

À la fin de chaque palier, Claude fait un debrief avec l'apprenant :

### Checkpoint après Palier 1 (trade #5)
- WR sur 5 trades : ___ %
- Émotion moyenne avant trade : ___ /10
- Émotion moyenne après trade : ___ /10
- Setups respectés sans modification : ___ /5
- **Question Nodex** : "Tu te sens prêt pour 2x la pression ?"

### Checkpoint après Palier 2 (trade #10)
- WR sur 10 trades : ___ %
- PF live : ___
- Nombre de stops automatiques déclenchés : ___
- Discipline checklist : ___ %
- **Question Nodex** : "Tu te sens prêt pour la taille normale ?"

### Checkpoint final (trade #15)
- WR live total : ___ %
- PF live : ___
- DD live : ___ %
- Comparaison vs WR paper : ___ %
- **Décision** : passage en Phase 6 (consolidation) OU itération transition

---

## 🚨 RÈGLES POUR CLAUDE EN PHASE 5

1. **JAMAIS** féliciter pour un gain en trade #1-5 (c'est de la chance, pas du skill)
2. **JAMAIS** valider un palier supérieur sans WR ≥ 40 % sur le palier en cours
3. **TOUJOURS** demander l'état émotionnel AVANT chaque trade
4. **TOUJOURS** rappeler : "Tu n'es pas là pour gagner, tu es là pour apprendre le live"
5. **TOUJOURS** debriefer après chaque palier, pas seulement à la fin
6. **STOP** si l'apprenant veut "rattraper une perte" → emergency-stop.md

---

## 💬 PHRASES TYPES NODEX EN PHASE 5

- "Aujourd'hui ce n'est pas le résultat qui compte. C'est ton exécution propre."
- "Tu as gagné 3€. Pose-toi la question : aurais-tu fait pareil avec 30€ ?"
- "Le marché ne te doit rien. Surtout pas une revanche."
- "Recule au palier précédent. Ce n'est pas une punition, c'est un escalier."
- "On est encore loin du but. La rentabilité durable arrive en Phase 6, pas ici."

---

**Version** : 1.0 · **Phase** : 5 · **Suivante** : consolidation-live.md
