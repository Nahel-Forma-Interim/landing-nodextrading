# 🧠 Psychologie de l'argent réel — ce qui change vs paper

> **Le paper trading prépare ta technique. Pas ton mental.**
> **L'argent réel active ton cerveau reptilien.** Voici comment t'y préparer.

---

## ⚡ Les 3 réactions chimiques au passage en live

### 1. Le cortisol (stress)
- **Quand** : à chaque entrée de trade
- **Effet** : ralentit ton jugement, contracte ton corps, hyperfocus sur le prix
- **Symptôme** : tu refresh ton chart toutes les 10 secondes
- **Antidote** : respiration 4-7-8 (inspire 4s, retiens 7s, expire 8s) avant de cliquer "Buy"

### 2. La dopamine (récompense)
- **Quand** : à chaque trade gagnant
- **Effet** : tu te sens invincible, tu veux ENCORE
- **Symptôme** : tu cherches un autre setup immédiatement, hors checklist
- **Antidote** : règle "1 trade par session NYAM, point". Ferme le terminal après le TP.

### 3. La cortisol-2 (perte)
- **Quand** : à chaque SL touché
- **Effet** : tu ressens une douleur réelle (le cerveau traite la perte d'argent comme une douleur physique)
- **Symptôme** : tu veux RATTRAPER tout de suite
- **Antidote** : journal émotionnel obligatoire dans les 5 min, puis fermeture du terminal pour 2h minimum

---

## 🎭 Les 7 visages que tu vas découvrir chez toi

### 1. **Le greedy** (mois 1-2 live)
"+5 % aujourd'hui ? Pourquoi pas +10 ?" → tu prends 3 trades supplémentaires → tu finis -2 %.

### 2. **Le revanchard** (premier gros SL)
"Le marché m'a volé 15€, je vais les récupérer" → tu prends un trade hors checklist → tu perds 30€.

### 3. **Le gel** (après 3 SL)
"J'ai peur d'appuyer." Tu vois un setup A+, tu ne le prends pas. Tu regrettes 2h plus tard.

### 4. **L'overconfident** (après 5 wins)
"J'ai compris la stratégie." Tu modifies le risk à 2 % "juste cette fois". Tu prends -4 %.

### 5. **Le doute permanent** (mois 2)
"Et si j'utilisais une autre stratégie ?" Tu cherches sur Twitter, YouTube. Tu pollues ta tête.

### 6. **Le fatigué** (mois 3)
"Pas de setup depuis 5 jours, c'est nul." Tu skippes la session. Le setup A+ arrive le 6e jour.

### 7. **Le pro** (Phase 7)
Aucun de ces visages. Tu exécutes. Tu journales. Tu vis ta vie. Tu reviens demain.

→ **Ton objectif : devenir le 7e en passant par les 6 premiers, en les acceptant.**

---

## 🛠️ Outils mentaux concrets

### Avant chaque session — Le "scanner mental" (3 questions)
1. **Sommeil** : ai-je dormi ≥ 7h ? (sinon → SKIP la session)
2. **Stress perso** : ai-je une dispute / problème en tête ? (sinon → SKIP)
3. **Focus** : suis-je capable de rester 3h concentré ? (sinon → SKIP)

→ **2 SKIP/oui sur 3 = pas de trading aujourd'hui.** Aucune négociation.

### Avant chaque trade — Le "test du trade abandonné"
> "Si j'oublie ce trade et je vais boire un café, est-ce que je le regrette dans 1h ?"

Si la réponse est "non" → le setup n'est pas assez clair. Skip.

### Pendant le trade — Le "test de la modification"
> "Suis-je en train de vouloir modifier mon SL ou TP ?"

Si oui → écris dans le journal POURQUOI tu veux modifier. Puis NE LE FAIS PAS. Le SL/TP est sacré.

### Après le trade — Le "debrief 5 minutes"
1. Note résultat en €
2. Note émotion ressentie pendant (1-10)
3. Note 1 chose que tu as bien faite
4. Note 1 chose à améliorer
5. Ferme le terminal

---

## 🚨 Les 5 signaux d'alerte mental

Si tu observes l'un de ces signes, **STOP immédiat 24h** :

1. Tu trades pour "te prouver quelque chose"
2. Tu calcules combien tu dois gagner pour atteindre un objectif (€/mois)
3. Tu te compares à d'autres traders sur les réseaux
4. Tu rêves de tes trades la nuit
5. Tu vérifies les charts pendant les repas / sur les toilettes / en marchant

→ Ces signes = ton cerveau est COLONISÉ par le trading. Pause obligatoire.

---

## 💡 Vérités qui font mal mais qui sauvent

- **Le marché ne te doit rien.** Surtout pas une revanche.
- **Tu seras NUL en live au début.** C'est NORMAL et PRÉVU.
- **Les meilleurs jours sont ceux où tu ne trades pas.** Vraiment.
- **Tu ne vis pas du trading. Le trading est une compétence parmi d'autres.**
- **Personne ne devient riche en 6 mois.** Les "réussites" sur Twitter sont 90 % du marketing.
- **+3 %/mois ≠ "petit". C'est +43 %/an. C'est plus que la majorité des fonds.**
- **Une mauvaise session ≠ un mauvais trader. Un mauvais MOIS ≠ un mauvais trader. 3 mauvais MOIS = il faut arrêter.**

---

## 🎯 Le mantra Nodex

> **"Mon job n'est pas de gagner aujourd'hui.**
> **Mon job est d'exécuter mon process aujourd'hui.**
> **Le profit est la conséquence du process bien exécuté sur la durée."**

À répéter avant chaque session NYAM. Sans exception.

---

**Version** : 1.0 · **Référence** : psycho live · **Phase** : 5+
