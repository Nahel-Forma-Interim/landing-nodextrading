# Méthode V5.3 — Référence complète (Multi-POI + Fibo)

> **Évolution V5.2 → V5.3** : on garde la rigueur V5.2 (sweep, trailing, risk strict) ET on ajoute :
> - **Sweep obligatoirement dans la zone discount/OTE** (pas n'importe où)
> - **Sur un POI identifié** (BPR / BB / OB / FVG / IFVG / BISI)
> - **2 bougies de confirmation** (pas 1 seule)
> - **Top-down complet** D1 → H4 → H1 → M15

## 🎯 Le setup V5.3

**Nom** : SMC Multi-POI + Fibo Top-down
**TF d'exécution** : M15
**Sessions** : **London (08h00-11h00 CET) + NYAM (14h30-18h00 CET)**
**Direction** : Long only spot

---

## 🏆 Les 6 POI hiérarchisés (cœur de V5.3)

| Rang | POI | Force | Description |
|------|-----|-------|-------------|
| 1 | **BPR** | ⭐⭐⭐⭐⭐ | Balanced Price Range = FVG bull + FVG bear superposés. Rare mais ~80% de proba. |
| 2 | **BB** | ⭐⭐⭐⭐⭐ | Breaker Block. Ancien support cassé→retest comme résistance→re-cassé bullish. Validé 2× par le marché. |
| 3 | **OB** | ⭐⭐⭐⭐ | Order Block. Dernière bougie baissière avant impulsion bullish. |
| 4 | **FVG** | ⭐⭐⭐⭐ | Fair Value Gap. low[i] > high[i-2]. Très commun et fiable. |
| 5 | **BISI** | ⭐⭐⭐⭐ | Bullish Imbalance Sell-Side Inefficiency. Synonyme du FVG bullish. |
| 6 | **IFVG** | ⭐⭐⭐ | Inverse FVG. FVG bearish invalidé qui devient support. |

---

## 📋 Les 8 étapes V5.3 (ordre rigoureux)

### Étape 1 — Contexte HTF (D1 + H4 + BTC)
- D1 bullish (HH + HL sur 5-10 dernières)
- H4 aligné
- POI majeurs D1 + H4 marqués
- BTC H4 bullish (hard rule)
- Pas de news rouge ±30 min

### Étape 2 — Tracer Fibo H1 (vue d'ensemble)
- Swing impulsif H1 le plus récent (low → high)
- Vérifier où le prix se trouve : **discount (sous 0.5)** ou premium
- Si premium → attendre

### Étape 3 — Marquer la liquidité M15
- Asia Low, PDL, lows récents significatifs, chiffres ronds

### Étape 4 — Tracer Fibo M15 (zone d'action)
- Swing impulsif M15 récent (low → high)
- Identifier les niveaux : **0.5 (frontière discount)** et **OTE 0.62-0.79**
- C'est CETTE zone que tu vas surveiller pour l'entrée

### Étape 5 — Identifier le POI dans la zone discount/OTE
- Cherche le POI le plus haut en ranking (cf. tableau ci-dessus) **dans la zone sous 0.5** ET idéalement **dans la zone OTE 0.62-0.79**
- Exemples : un BB dans OTE = setup A+ · un FVG dans discount = setup A
- **Hard rule** : aucun POI dans le discount → SKIP

### Étape 6 — Attendre le SWEEP **DANS la zone POI**
- Le prix doit venir **balayer un low SOUS le 0.5 Fibo**
- Le sweep doit toucher le POI identifié
- 3 critères du sweep :
  1. Niveau significatif cassé
  2. Mèche ≥ 2× corps
  3. Close au-dessus du niveau
- **Bonus A+** : volume ≥ 3× moyenne 20 bougies

### Étape 7 — Attendre **2 BOUGIES de confirmation**
- **Différence clé V5.3 vs V5.2** : on attend **2 bougies** post-sweep, pas une
- Bougie 1 = bougie qui touche/mitige le POI
- Bougie 2 = bougie suivante qui clôture **au-dessus du high de la bougie 1**
- **SANS les 2 bougies = PAS D'ENTRÉE** (hard rule)
- Bonus : si bougie 2 est englobante (engulfing) = setup +++

### Étape 8 — Placer le trade
- **Entry** = close de la 2e bougie de confirmation
- **SL** = sous mèche du sweep + buffer 0,2 %
- **Risk** = 1 % standard / 1,2 % max A+
- **TP** = trailing par paliers (voir section suivante)
- **Vérifier RR ≥ 2,5:1** sinon skip

---

## 💎 Gestion TP trailing par paliers (inchangé V5.2/V5.3)

100 % de la position gardée. SL déplacé par paliers :

| Palier | Prix atteint | Action |
|--------|--------------|--------|
| 1 · ENTRY | 0 % | SL initial à **−1 %** |
| 2 · BE déclencheur | **+1,5 %** | SL bouge à **BE (0 %)** |
| 3 · Mid-trail | **+2,5 %** | SL bouge à **+1,5 %** |
| 4 · SORTIE | **+3 %** | **Sortie totale** |

### 4 scénarios

| Scénario | Description | Résultat |
|----------|-------------|----------|
| A · Move parfait | Prix atteint +3 % | **+3,0 %** 🏆 |
| B · Partiel +2,5 % | +2,5 % puis reverse | **+1,5 %** ✅ |
| C · Partiel +1,5 % | +1,5 % puis reverse | **0 %** 🟡 (BE) |
| D · Reverse direct | N'atteint jamais +1,5 % | **−1 %** ❌ |

**Piège** : bouger le SL à temps. Toujours alertes TradingView à +1,5 % et +2,5 %.

---

## 🛡️ Risk management V5.3 (NON NÉGOCIABLE)

| Règle | Valeur |
|-------|--------|
| Risk / trade | **1 % standard · 1,2 % max A+** |
| RR minimum | **2,5:1** (hard rule = RR < 2:1 = SKIP) |
| Max trades / jour | **3** |
| Stop 2 SL consécutifs | **→ 24h** |
| DD alert 5 % / 5 trades | **→ pause 48h** |
| DD stop 10 % | **→ arrêt complet** |

### Formule taille position
```
Taille = Capital × Risk% ÷ (Entry − SL) × Entry
```

Exemple : Cap 2000 € · Risk 1 % · Entry 0,1280 · SL 0,1272 (0,62 %)
→ Taille = 2000 × 1 % ÷ 0,62 % × 0,1280 = **413 €** en position

---

## 🌍 Sessions V5.3

V5.3 trade **2 fenêtres de Kill Zone** :

### Kill Zone London (08h00-11h00 CET)
- Logique : Asia accumule la liquidité (00h-08h), London ouvre, vient sweeper
- Setups possibles : sweep Asia Low, sweep PDL
- Volume institutionnel London = excellent pour la mécanique sweep + POI

### Kill Zone NYAM (14h30-18h00 CET)
- Logique : NY rejoint la liquidité European/London
- Setups possibles : sweep High/Low London, sweep PDH/PDL
- Volume maximal global

**Règle d'or** : zéro trade en dehors de ces 2 fenêtres.

---

## 📊 Validation V5.3

### Backtest préliminaire (20 trades V5.3)
- WR : **60 %**
- PnL : **+30,5 %** capital sur 20 trades
- Watchlist : ARB + PENDLE
- Sessions : London + NYAM
- Confirme la cohérence de la méthode

### Live (avril 2026 en cours)
- Capital 2 000 $ engagé en réel depuis début avril
- PnL : **+130 $ / +5 %** sur le mois
- Phase 6 consolidation en cours (mois 1/3)
