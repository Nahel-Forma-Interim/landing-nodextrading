# Les 10 erreurs à éviter (pièges mortels)

1. ❌ **Trader hors NYAM** — 80 % des pertes viennent des sessions pourries. 14h30-18h CET, point.
2. ❌ **Entrer sans bougie 2** — "J'anticipe" = suicide. Discipline absolue.
3. ❌ **Bouger le SL contre soi** — Règle psycho Hugo #1. Transforme −1% en −3%.
4. ❌ **Ignorer le filtre BTC** — BTC bearish = alts bearish. Check obligatoire.
5. ❌ **Trader un actif en range serré** — Amplitude < 5% sur 4j = skip cet actif.
6. ❌ **Reprendre après 2 SL** — Émotionnellement compromis. Stop 48h.
7. ❌ **Augmenter risk pour rattraper** — "Je passe à 2%" = flamber le compte.
8. ❌ **Sauter le journal** — Pas de journal = pas de progrès.
9. ❌ **Passer au réel avant 30 paper trades** — Sans stats = flaming garanti.
10. ❌ **Mélanger plusieurs setups** — 1 setup à 70% > 3 setups à 40%.
