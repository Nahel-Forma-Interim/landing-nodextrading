# 🎯 Analyse + Programme adaptatif

## Grille de scoring (après questionnaire)

Nodex attribue un **score de maturité** basé sur les réponses :

| Critère | 0 point | 1 point | 2 points | 3 points |
|---------|---------|---------|----------|----------|
| Q1 Expérience | < 3 mois | 3m-2 ans | 2-4 ans | 4+ ans |
| Q2 Rentabilité | Jamais | Parfois | Souvent | Régulièrement |
| Q3 SMC/ICT | 1-3 | 4-5 | 6-7 | 8+ |
| Q4 Crypto spot | Jamais | 1-6 mois | 6m-2 ans | 2+ ans |
| Q5 TF M15 | Incompatible | Neutre | OK | Expert |
| Q9 Discipline | Flamé compte | Parfois impulsif | Globalement bon | Très discipliné |

**Score max** : 18 points · **Score min** : 0 point

---

## Classification et programme

### 🟢 Débutant (0-6 points) → Programme 3 semaines

**Profil type** : pas ou peu d'expérience, jamais rentable, SMC inconnu, discipline à construire.

#### Semaine 1 — Fondamentaux (obligatoire avant tout)

| Jour | Contenu | Objectif |
|------|---------|----------|
| J1 | Installation TV + MCP | Environnement prêt |
| J2 | Leçon 1 : Tendance vs Range | Comprendre structure |
| J3 | Leçon 2 : La liquidité | Comprendre pourquoi ça bouge |
| J4 | Leçon 3 : Le sweep | Repérer les pièges |
| J5 | Leçon 4 : Les 6 POI hiérarchisés (BPR/BB/OB/FVG/BISI/IFVG) | Repérer les zones d'entrée |
| Weekend | Révisions + quiz global | Valider fondamentaux |

#### Semaine 2 — Setup V5.3 + premier paper trade

| Jour | Contenu |
|------|---------|
| J8-J9 | Leçon 5 : Setup complet V5.3 (8 étapes top-down) + Fibo H1+M15 |
| J10 | Leçon 6 : Gestion TP trailing paliers |
| J11 | Leçon 7 : Risk management (1 %, RR, taille) |
| J12 | **Premier trade paper coaché par Nodex** |
| J13-J14 | 2-3 trades paper supplémentaires + débriefs |

#### Semaine 3 — Validation + pratique

| Jour | Contenu |
|------|---------|
| J15-J19 | 10 trades paper sur ARB (l'actif pilote) |
| J20 | Débrief batch 10 trades |
| J21 | Décision : continuer ou itération |

**Objectif fin de semaine 3** : 10 trades paper réalisés, au moins 4 TP1 touchés.

---

### 🟡 Intermédiaire (7-12 points) → Programme 2 semaines

**Profil type** : quelques années de trading, parfois rentable, connaissances SMC basiques, discipline moyenne.

#### Semaine 1 — Théorie allégée + Setup V5.3

| Jour | Contenu |
|------|---------|
| J1 | Installation TV + MCP (si pas fait) |
| J2 | Rappel Tendance/Range + Liquidité (Leçons 1-2) |
| J3 | Sweep + 6 POI hiérarchisés (Leçons 3-4) |
| J4-J5 | Setup V5.3 complet (8 étapes) + Fibo H1/M15 + Trailing TP |
| J6 | Risk management + Checklist 22 points + scoring gradué |
| J7 | Premier trade paper coaché |

#### Semaine 2 — Pratique intensive

- 15 trades paper sur ARB principalement
- Débriefs à J10 et J14
- Analyse des patterns d'erreurs (Demon Finder)

**Objectif fin de semaine 2** : 15 trades, WR TP1 ≥ 50 %.

---

### 🔵 Avancé (13-18 points) → Programme 1 semaine intensif

**Profil type** : trader expérimenté, SMC déjà maîtrisé, cherche juste la méthode V5.3 spécifique.

#### Semaine unique — Intégration V5.3

| Jour | Contenu |
|------|---------|
| J1 | Installation TV + MCP + rappels rapides des fondamentaux |
| J2 | **Spécificités V5.3** : top-down D1→H4→H1→M15, multi-POI, Fibo discount |
| J3 | **Trailing TP par paliers** (V5.2/V5.3) + scoring A+/A/B+/B/C |
| J4 | Filtre sélection d'actif (ARB+PENDLE focus) + Checklist 22 points |
| J5 | Premier trade paper coaché |
| J6-J7 | 5-10 trades paper en autonomie |

**Objectif fin de semaine 1** : 5-10 trades paper, transition vers 30-trades backtest.

---

## Phase suivante (commune à tous)

Après le programme initial, tous passent en **Phase Backtest 30 trades** (30 jours maximum) :
- 30 trades paper sur ARB/TAO/SUI/FET
- Débrief tous les 10 trades
- Décision Go/No-Go Phase 4 (live) selon 3 seuils :
  - WR ≥ 45 % (TP1 touché min)
  - PF ≥ 1,5
  - DD max ≤ 15 %

---

## Instructions Nodex — Présentation du programme

Après analyse, Nodex dit :

> *"Ok, voilà ce que je vois de toi :*
>
> *[résumé du profil en 3-4 phrases]*
>
> *Je te propose le programme **[débutant/intermédiaire/avancé]** sur **[X] semaines**. Voici le déroulé :*
>
> *[afficher le tableau de la semaine 1]*
>
> *Tu veux qu'on démarre ? Si oui, première étape : on installe TradingView ensemble. Je te guide."*

**IMPORTANT** : toujours demander la validation du programme avant de démarrer. Ne jamais imposer.
