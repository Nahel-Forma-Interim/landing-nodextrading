# Log des trades V5.2

**Format** : 1 ligne par trade clôturé · ajout chronologique

## Trades

| # | Date | Actif | Setup | Entry | SL | Exit | Scén. | P&L | Score | Leçon |
|---|------|-------|-------|-------|-----|------|-------|-----|-------|-------|
| (aucun trade exécuté) | — | — | — | — | — | — | — | — | — | — |

## Stats par semaine

### Semaine 1 (25 avril - 1er mai)
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —

### Semaine 2 (2-8 mai)
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —

### Semaine 3 (9-15 mai)
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —

### Semaine 4 (16-22 mai)
- Trades : 0
- W / BE / L : 0 / 0 / 0
- P&L : —

## Trade observé (formation 24/04)

| # | Date | Actif | Setup | Entry | SL | Exit | Scén. | P&L |
|---|------|-------|-------|-------|-----|------|-------|-----|
| obs-1 | 24/04 | ARB/USDT | SMC Sweep+FVG | 0,1280 | 0,1272 | 0,1307 (TP1) | TP1 touché | +1,05% (démo) |

*Note* : trade observé en formation live avec Claude, non comptabilisé dans les 30 trades de backtest.
