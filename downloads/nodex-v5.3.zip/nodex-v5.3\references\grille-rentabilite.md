# 📊 Grille de rentabilité — qu'est-ce que "rentable" exactement ?

> Référence chiffrée pour évaluer objectivement où en est l'apprenant.
> **Aucune subjectivité.** Les seuils décident.

---

## 🎯 NIVEAUX DE RENTABILITÉ NODEX (5 paliers)

### Palier 0 — DÉBUTANT (Phase 1-3)
- Zéro trade live
- Aucune métrique pertinente
- **Verdict** : "tu apprends, c'est tout"

### Palier 1 — APPRENTI (Phase 4-5)
- Critères paper validés (WR ≥ 45 %, PF ≥ 1.5, DD ≤ 15 %)
- Premiers trades live (< 15)
- **Verdict** : "tu sais théoriquement, on teste en pratique"

### Palier 2 — TRADER VIABLE (Phase 6, 1-2 mois validés)
- 1 ou 2 mois consécutifs profitables (+3 % min/mois)
- WR live ≥ 45 %
- DD intra-mois ≤ 8 %
- **Verdict** : "tu peux tenir, mais c'est encore fragile"

### Palier 3 — TRADER RENTABLE (Phase 6 validée, 3+ mois)
- 3 mois consécutifs profitables minimum
- WR live ≥ 50 %
- PF live ≥ 1.6
- DD cumulé ≤ -10 %
- **Verdict** : "tu es OFFICIELLEMENT rentable"
- **Action** : déclencher Phase 7 (autonomie + compagnon)

### Palier 4 — TRADER PROFESSIONNEL (Phase 7, 12+ mois)
- 12 mois validés
- Capital × 2 ou plus depuis le départ
- ROI annualisé ≥ +30 %
- **Verdict** : "tu es dans le top 1 % des traders retail"

### Palier 5 — MAÎTRE (Phase 7 long terme, 24+ mois)
- 24 mois validés
- Capital × 5 ou plus
- ROI annualisé ≥ +40 %
- **Verdict** : "le marché est ton terrain de jeu"

---

## 📐 LES MÉTRIQUES À CONNAÎTRE PAR CŒUR

### WR (Win Rate)
- Formule : `wins / total_trades × 100`
- Seuil minimal Nodex : **45 %**
- Confortable : **50-55 %**
- Excellent : **>60 %**

### PF (Profit Factor)
- Formule : `total_gains / abs(total_losses)`
- Seuil minimal Nodex : **1.5**
- Confortable : **1.8-2.0**
- Excellent : **>2.5**

### DD (Drawdown)
- Formule : `(peak_capital - trough_capital) / peak_capital × 100`
- Seuil critique : **-15 %** (au-delà = arrêt)
- Confortable : **<-10 %**
- Excellent : **<-5 %**

### ROI (Return on Investment)
- Formule : `(capital_actuel - capital_initial) / capital_initial × 100`
- Mensuel attendu Nodex : **+3 % minimum**
- Mensuel cible : **+5 %**
- Annualisé attendu : **+30-50 %**

### Discipline
- Formule : `trades_avec_18pts_cochés / total_trades × 100`
- Seuil critique : **90 %**
- Idéal : **95-100 %**

---

## 💡 ATTENDU vs PROMIS

### Ce qu'on PROMET à l'acheteur
- "Devenir un trader rentable durable en suivant le programme"
- "+3 % par mois en moyenne sur 12 mois bien suivis"
- "Capital qui double dans les 18-24 mois si discipline"
- "Méthode + coaching IA + indicateurs Pine + fiche cockpit"

### Ce qu'on NE PROMET PAS
- ❌ "Devenir riche en 3 mois"
- ❌ "+30 % par mois"
- ❌ "Quitter ton job dans 6 mois"
- ❌ "Méthode infaillible"
- ❌ "0 perte"

### Ce qu'on RAPPELLE OBJECTIVEMENT
- 95 % des traders retail échouent dans la première année
- Notre approche réduit ce risque à environ 50 % (encore 1 sur 2 échoue)
- L'échec vient à 95 % de la discipline, pas de la stratégie
- C'est pourquoi le skill se concentre sur le PROCESS, pas sur les setups

---

## 🚦 GRILLE DE DÉCISION RAPIDE (Claude utilise ça)

```
SI total_trades_live < 15 :
   → Phase 5 (transition)

SI total_trades_live >= 15 ET mois_consécutifs_profitables < 3 :
   → Phase 6 (consolidation)

SI mois_consécutifs_profitables >= 3 ET capital_actuel >= 1500€ :
   → Phase 7 (autonomie)

SI mois_consécutifs_profitables = 0 ET DD > -15 % :
   → ALERTE NOIRE → Retour Phase 4

SI mois_consécutifs_profitables tombe en cours :
   → COMPTEUR RESET → "tu repars à 0/3"
```

---

**Version** : 1.0 · **Référence** : grille rentabilité · **Phases** : 4-7
