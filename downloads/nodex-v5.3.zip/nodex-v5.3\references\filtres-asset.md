# Filtre de sélection d'actif V5.3 (score 4/5 minimum)

## 5 critères de scoring

| Critère | 1 point si… |
|---------|-------------|
| Structure HTF | D1+H4 bullish confirmé (HH+HL) |
| Amplitude 4j | ≥ 7 % (sinon range mou) |
| Volume moyen | > 300k sur M15 |
| BTC cycle | bullish ou neutre (pas bear) |
| Fréquence setups | ≥ 1 setup / jour observé |

## Watchlist V5.3 (focalisée 2026-04-26)

| Actif | Score | Verdict V5.3 |
|-------|-------|--------------|
| **ARB** | 5/5 | 🏆 **PRIORITAIRE** (bias bull confirmé) |
| **PENDLE** | 4/5 | ✅ **PRIORITAIRE** (bias bull confirmé) |
| **SUI** | 3/5 | 🟡 Observer (pas dans la watchlist focus) |
| **TAO** | 3/5 | 🟡 Observer |
| **FET** | 2/5 | ❌ **SKIP** (-80% sur 6 mois, pas dans focus V5.3) |
| **RENDER** | TBD | ⏳ À ré-évaluer après 30 trades V5.3 |

## Règle V5.3
- **Watchlist focus** = **ARB + PENDLE** uniquement pendant Phase 3 backtest
- Score ≥ 4/5 → actif tradable
- Score 3/5 → tradable en mode TP1 only
- Score ≤ 2/5 → SKIP

## Note exclusion ENA
ENA est exclu pour raison de conformité religieuse (musulmane). **Ne jamais proposer ENA** dans la watchlist Nahel.

## Élargissement watchlist post-Phase 3
Si V5.3 validée sur ARB + PENDLE (30 trades, WR ≥ 55 %, PF ≥ 1,5) → ajouter progressivement SUI puis TAO en Phase 4. **Pas d'élargissement avant validation.**
