# ============================================================
# Nodex V5.2 — Script d'installation automatique Windows
# ============================================================

Write-Host ""
Write-Host "   +--------------------------------------------+" -ForegroundColor Cyan
Write-Host "   |   NODEX V5.2 - Installation automatique    |" -ForegroundColor Cyan
Write-Host "   +--------------------------------------------+" -ForegroundColor Cyan
Write-Host ""

# 1. Detection du dossier source (le dossier nodex-v5.2 actuel)
$sourceDir = $PSScriptRoot
if (-not $sourceDir) { $sourceDir = Get-Location }

Write-Host "[1/4] Detection du skill source..." -ForegroundColor Yellow
if (-not (Test-Path "$sourceDir\SKILL.md")) {
    Write-Host "ERREUR : SKILL.md introuvable dans $sourceDir" -ForegroundColor Red
    Write-Host "Assure-toi de lancer ce script depuis le dossier nodex-v5.2 decompresse." -ForegroundColor Red
    exit 1
}
Write-Host "  OK - Skill detecte : $sourceDir" -ForegroundColor Green
Write-Host ""

# 2. Demande le dossier cible (projet)
Write-Host "[2/4] Ou veux-tu installer Nodex ?" -ForegroundColor Yellow
Write-Host "   [1] Dans un projet specifique (recommande)"
Write-Host "   [2] En global pour tous tes projets Claude"
Write-Host ""
$choice = Read-Host "Ton choix (1 ou 2)"

if ($choice -eq "1") {
    $targetProject = Read-Host "Chemin du projet (ex: C:\Users\MonNom\MonProjet)"
    if (-not (Test-Path $targetProject)) {
        Write-Host "ERREUR : Le dossier $targetProject n'existe pas." -ForegroundColor Red
        exit 1
    }
    $targetDir = "$targetProject\.claude\skills\nodex-v5.2"
} elseif ($choice -eq "2") {
    $targetDir = "$env:USERPROFILE\.claude\skills\nodex-v5.2"
} else {
    Write-Host "Choix invalide. Abandon." -ForegroundColor Red
    exit 1
}

Write-Host "  Destination : $targetDir" -ForegroundColor Green
Write-Host ""

# 3. Creation du dossier et copie
Write-Host "[3/4] Installation des fichiers..." -ForegroundColor Yellow

# Suppression si existant
if (Test-Path $targetDir) {
    $overwrite = Read-Host "Le skill existe deja. Ecraser ? (o/n)"
    if ($overwrite -ne "o") {
        Write-Host "Abandon." -ForegroundColor Yellow
        exit 0
    }
    Remove-Item -Recurse -Force $targetDir
}

# Creation du dossier parent
$parent = Split-Path $targetDir -Parent
New-Item -ItemType Directory -Force -Path $parent | Out-Null

# Copie
Copy-Item -Recurse -Force $sourceDir $targetDir

Write-Host "  OK - Fichiers copies" -ForegroundColor Green
Write-Host ""

# 4. Verification
Write-Host "[4/4] Verification de l'installation..." -ForegroundColor Yellow
$requiredFiles = @(
    "$targetDir\SKILL.md",
    "$targetDir\FIRST-MESSAGE.md",
    "$targetDir\PERSONA.md",
    "$targetDir\onboarding\welcome.md",
    "$targetDir\references\methode-complete.md"
)

$allOk = $true
foreach ($file in $requiredFiles) {
    if (-not (Test-Path $file)) {
        Write-Host "  MANQUANT : $file" -ForegroundColor Red
        $allOk = $false
    }
}

if ($allOk) {
    Write-Host "  OK - Tous les fichiers requis sont presents" -ForegroundColor Green
} else {
    Write-Host "  ATTENTION : Certains fichiers manquent. Verifie le ZIP." -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "+---------------------------------------------------+" -ForegroundColor Green
Write-Host "|                                                   |" -ForegroundColor Green
Write-Host "|   INSTALLATION REUSSIE !                          |" -ForegroundColor Green
Write-Host "|                                                   |" -ForegroundColor Green
Write-Host "|   Prochaines etapes :                             |" -ForegroundColor Green
Write-Host "|   1. Ferme et relance Claude Code                 |" -ForegroundColor Green
Write-Host "|   2. Ouvre ton projet                             |" -ForegroundColor Green
Write-Host "|   3. Dis a Claude : 'Nodex, tu es la ?'           |" -ForegroundColor Green
Write-Host "|   4. Nodex t'accueillera automatiquement          |" -ForegroundColor Green
Write-Host "|                                                   |" -ForegroundColor Green
Write-Host "+---------------------------------------------------+" -ForegroundColor Green
Write-Host ""
