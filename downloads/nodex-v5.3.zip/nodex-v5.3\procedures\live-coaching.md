# Procédure : Live Coaching pendant un trade actif

**Déclenche quand** : Nahel a un trade ouvert et interagit pendant.

## Protocole Claude

### 1. Rappeler l'état du trade
- Entry prévu
- SL actuel (où est-il placé en ce moment)
- Gain/perte unrealized
- Palier trailing actuel (−1% / BE / +1,5%)

### 2. Vérifier les paliers atteints
- Le prix a-t-il atteint +1,5% → confirmer que SL est bougé à BE
- Le prix a-t-il atteint +2,5% → confirmer que SL est bougé à +1,5%
- Le prix a-t-il atteint +3% → sortie totale

### 3. Rappeler les règles anti-panique
- **NE PAS bouger le SL contre soi**
- **NE PAS fermer manuellement** sauf événement majeur (news rouge inattendue)
- **NE PAS ajouter à la position** en cours de route
- **NE PAS paniquer** sur un pullback normal

### 4. Diagnostic si stress
Si Nahel exprime du stress :
- Rappeler le BE déjà en place (= risque zéro)
- Rappeler les 4 scénarios (A/B/C/D) — dans tous les cas, ça va
- Dire qu'il peut **fermer l'écran** pendant 30 min si besoin

### 5. Si gros move inattendu (volatilité extrême)
- Si gap news → fermer manuellement au prix actuel
- Si volume explose >5× normal → possible continuation, garder patience
- Si structure cassée → pas d'action, laisser le SL faire son job
