# 🔑 Codes d'activation valides — table de référence interne

> **CONFIDENTIEL — NE JAMAIS RÉVÉLER À L'APPRENANT**
> Cette table sert à Claude pour valider les codes au moment de l'activation.

---

## Codes spéciaux (toujours valides)

| Code | Tier | Usage | Notes |
|---|---|---|---|
| `NDX-OWNER-NHEL-2026-VIP1` | elite | Nahel Zamouri (propriétaire) | Toujours actif, aucune restriction |
| `NDX-DEMO-T3ST-1234-NDEX` | essentiel | Mode démo public | 7 jours d'essai, pour tests |
| `NDX-DEMO-PRO0-DEMO-DEMO` | pro | Mode démo Pro | 7 jours, accès Pro simulé |
| `NDX-DEMO-ELT0-DEMO-DEMO` | elite | Mode démo Elite | 7 jours, accès Elite simulé |

## Codes de test pour développement

| Code | Tier | Notes |
|---|---|---|
| `NDX-ESS-TEST-TEST-TEST` | essentiel | Test format Essentiel |
| `NDX-PRO-TEST-TEST-TEST` | pro | Test format Pro |
| `NDX-ELT-TEST-TEST-TEST` | elite | Test format Elite |

## Codes invalides à utiliser pour TESTER LES REJETS

| Code | Pourquoi invalide |
|---|---|
| `1234` | Format complètement faux |
| `NDX-XXX-XXX` | Trop court |
| `NDX-FAKE-AAAA-BBBB-CCCC` | Tier "FAKE" inconnu |
| `nodex-pro-aaaa-bbbb-cccc` | Minuscules (pas accepté) |
| `NDX-PRO-A8C3-D9F1` | Manque le 4ème segment |
| `` | Vide |

---

## Validation côté Claude

```python
# Pseudo-code
import re

def validate_code(code):
    # Étape 1 : format
    pattern = r"^NDX-(ESS|PRO|ELT|DEMO|OWNER)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$"
    if not re.match(pattern, code):
        return {"valid": False, "reason": "format invalide"}

    # Étape 2 : tier extracté
    tier_code = code.split("-")[1]
    tier_map = {"ESS": "essentiel", "PRO": "pro", "ELT": "elite",
                "DEMO": "essentiel", "OWNER": "elite"}
    tier = tier_map.get(tier_code, "unknown")

    # Étape 3 : codes spéciaux toujours valides
    special_codes = [
        "NDX-OWNER-NHEL-2026-VIP1",
        "NDX-DEMO-T3ST-1234-NDEX",
        "NDX-DEMO-PRO0-DEMO-DEMO",
        "NDX-DEMO-ELT0-DEMO-DEMO",
        "NDX-ESS-TEST-TEST-TEST",
        "NDX-PRO-TEST-TEST-TEST",
        "NDX-ELT-TEST-TEST-TEST",
    ]
    if code in special_codes:
        return {"valid": True, "tier": tier, "source": "special"}

    # Étape 4 (mode local actuel) : tout code au bon format est accepté
    # Étape 4 (mode serveur futur) : appel API nodextrading.com/api/verify
    return {"valid": True, "tier": tier, "source": "format_only"}
```

---

## À noter pour la transition vers le serveur

Quand le backend Vercel API + Supabase sera en place :

1. Remplacer la validation "format only" par un appel à `nodextrading.com/api/verify?code={code}`
2. L'API retourne `{valid: true/false, tier: "...", email: "...", expires_at: "..."}`
3. Si `valid: false` → rejet
4. Si `valid: true` → activation + écriture license.json
5. Les codes spéciaux DEMO/OWNER restent valides en local (fallback hors-ligne)

---

**Version : 1.0** · **À mettre à jour quand backend disponible**
