# 🎓 Nodex V5.3 — Skill Formateur Trading (Multi-POI + Fibo)

**Version** : 5.3.0 · **Propriétaire** : Nahel Zamouri · **Statut** : Privé · **Évolution de** : V5.2 (FVG-only)

## 📌 Qu'est-ce que c'est ?

Un skill Claude qui transforme Claude en **Nodex**, un formateur en trading professionnel. Quand tu actives ce skill :

1. Nodex t'accueille et se présente
2. Te fait passer un **diagnostic 10 questions**
3. Analyse ton profil (débutant / intermédiaire / avancé)
4. Crée un **programme adapté** (1, 2 ou 3 semaines)
5. T'aide à installer TradingView + connexion MCP
6. T'enseigne la **stratégie Nodex V5.3** étape par étape (top-down D1→H4→H1→M15)
7. Te coache sur tes 30 premiers paper trades
8. Valide ton passage en live si tu atteins les seuils

## 🎯 Quelle stratégie ?

**Nodex V5.3** = évolution V5.2 enrichie SMC/ICT complète + Fibo top-down :
- **6 POI hiérarchisés** : BPR ⭐⭐⭐⭐⭐ · BB ⭐⭐⭐⭐⭐ · OB ⭐⭐⭐⭐ · FVG ⭐⭐⭐⭐ · BISI ⭐⭐⭐⭐ · IFVG ⭐⭐⭐
- **Top-down complet** : D1 → H4 → H1 → M15
- **Fibo H1 + M15** · entry sous 0.5 obligatoire (zone discount)
- Crypto spot Binance — **watchlist focus : ARB + PENDLE**
- Timeframe M15 · Session NYAM (14h30-18h CET) · Long only
- Risk 1 % standard / 1,2 % max A+ · TP trailing paliers plafond +3 %
- **Checklist 22 points** + scoring gradué A+/A/B+/B/C

## 📦 Installation

### Option A — Télécharger le ZIP
Télécharge le ZIP du skill et décompresse dans :
```
<ton projet>/.claude/skills/nodex-v5.3/
```

### Option B — Clone GitHub (si repo dispo)
```bash
git clone https://github.com/Nahel-Forma-Interim/nodex-skill-v5.3 .claude/skills/nodex-v5.3
```

### Option C — Copier le dossier
Copie manuellement le dossier `nodex-v5.3/` dans `.claude/skills/` de ton projet.

## 🚀 Activation

Dans Claude Code, dis simplement :
> *"Nodex, je veux apprendre le trading"*

Ou n'importe quel message contenant : `trade`, `V5`, `ARB`, `SMC`, `formation`, `apprendre`, etc.

**Le skill s'active automatiquement** et lance le protocole d'onboarding.

## 📂 Structure

```
nodex-v5.3/
├── SKILL.md                    ← Entry point
├── PERSONA.md                  ← Qui est Nodex
├── README.md                   ← Ce fichier
│
├── onboarding/
│   ├── welcome.md
│   ├── questionnaire.md
│   └── analyse-et-programme.md
│
├── setup/
│   └── installation-guide.md
│
├── references/
│   ├── methode-complete.md
│   ├── checklist-22-points.md
│   ├── erreurs-a-eviter.md
│   └── filtres-asset.md
│
├── procedures/
│   ├── pre-trade-check.md
│   ├── live-coaching.md
│   ├── post-trade-debrief.md
│   └── emergency-stop.md
│
├── state/
│   ├── current-phase.md
│   ├── metrics.md
│   └── trades-log.md
│
└── templates/
    └── journal-trade-entry.md
```

## 🔒 Confidentialité

**Ce skill vaut de l'or.** Ne le partage pas publiquement avant accord de Nahel.

Roadmap :
- ✅ Phase 1 : Usage perso Nahel (actuel)
- 🟡 Phase 2 : Équipe interne (après 30 trades backtest validés)
- 🔵 Phase 3 : Produit commercial (vente, après Phase 4 live rentable confirmée)

## 📊 Métriques cibles (Phase 3 backtest)

| Métrique | Seuil minimum |
|----------|---------------|
| WR (TP1) | ≥ 45 % |
| Profit Factor | ≥ 1,5 |
| Drawdown max | ≤ 15 % |

## 🧠 Philosophie

> *"Le trading rentable, c'est 20 % de méthode et 80 % de discipline. Je te donne la méthode. La discipline, c'est toi qui la construis — et je suis là pour t'y aider."* — Nodex

---

**Contact** : Nahel Zamouri · Projet Nodex Trading · Créé le 24 avril 2026
