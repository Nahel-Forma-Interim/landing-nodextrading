# Template : Entrée Nodex Journal pour un trade V5.2

À remplir dans Nodex Journal dès que le trade est placé.

```
N°             : [numéro incrémental]
Date           : YYYY-MM-DD
Heure CET      : HH:MM
Session        : NYAM
Actif          : [ARB|TAO|SUI|FET|PENDLE]/USDT
TF             : M15
Setup          : SMC Sweep + FVG
Biais HTF D1   : bullish / bearish / neutre
Biais HTF H4   : bullish / bearish / neutre
BTC H4         : bullish / bearish / neutre
Volume sweep   : [x× moyenne]
Score setup /10: [note honnête]

== NIVEAUX ==
Entry          : [prix]
SL             : [prix]  (risk [X]%)
+1,5% (palier 1): [prix]  → SL à BE
+2,5% (palier 2): [prix]  → SL à +1,5%
+3% (sortie)   : [prix]  → SORTIE TOTALE

== RISQUE ==
Capital        : [€]
Risk %         : [1 à 1,2]%
Taille position: [€]
RR minimum     : [2,5:1+]

== RÉSULTAT (après clôture) ==
Scénario       : A / B / C / D
Exit           : [prix]
P&L brut       : [%]
P&L net        : [%]
Durée trade    : [bougies]

== PSYCHOLOGIE ==
Émotion entrée : 1-5 (1=calme, 5=stressé)
Émotion sortie : 1-5
As-tu tenu plan: OUI / NON (si NON : détailler)

== LEÇON ==
[Une phrase simple qui résume ce qu'il faut retenir de ce trade]
```
