# 🚦 Phase 4 — Décision Go / No-Go pour le passage en LIVE

> **Objectif** : valider de manière objective si l'apprenant est prêt à risquer du vrai argent.
> **Aucune subjectivité.** Seuls les chiffres décident.

---

## 🎯 LES 4 SEUILS NON NÉGOCIABLES

L'apprenant doit avoir réalisé **AU MINIMUM 30 paper trades** journalisés avec :

| Métrique | Seuil minimum | Pourquoi |
|---|---|---|
| **WR (Win Rate)** | ≥ 45 % | Stratégie rentable mathématiquement avec un RR 1:2 |
| **PF (Profit Factor)** | ≥ 1,5 | Tu gagnes 1,5€ pour chaque 1€ perdu |
| **DD max (Drawdown)** | ≤ 15 % | Tu n'as pas explosé ton capital paper |
| **Discipline checklist** | ≥ 90 % | Tu as respecté les 18 points sur 9 trades sur 10 |

⚠️ **Si UN SEUL seuil est manqué → NO-GO automatique.** Pas de négociation.

---

## 🔍 PROTOCOLE DE VÉRIFICATION

### Étape 1 — Lecture des stats

```
Lire : state/metrics.md
Lire : state/trades-log.md (vérifier le nombre)
Lire : state/current-phase.md
```

### Étape 2 — Calcul du verdict

```python
# Pseudo-code que Claude exécute mentalement
total_trades = count(trades_log)
wr           = wins / total_trades * 100
pf           = sum(gains) / abs(sum(losses))
dd_max       = max((peak - trough) / peak * 100)
discipline   = trades_with_18pts_checked / total_trades * 100

if total_trades < 30:
    verdict = "NO-GO : pas assez de trades (faut 30 minimum)"
elif wr < 45:
    verdict = "NO-GO : WR insuffisant ({wr}% < 45%)"
elif pf < 1.5:
    verdict = "NO-GO : PF insuffisant ({pf} < 1.5)"
elif dd_max > 15:
    verdict = "NO-GO : DD trop élevé ({dd_max}% > 15%)"
elif discipline < 90:
    verdict = "NO-GO : discipline insuffisante ({discipline}% < 90%)"
else:
    verdict = "GO : prêt pour la transition LIVE"
```

### Étape 3 — Verdict à l'apprenant (mot pour mot)

#### Si GO :
```
🎯 VERDICT : GO POUR LE LIVE

Voici tes stats finales paper trading :
  - {total_trades} trades sur {nb_jours} jours
  - WR : {wr}% (seuil 45 %)
  - PF : {pf} (seuil 1.5)
  - DD max : {dd_max}% (seuil 15 %)
  - Discipline checklist : {discipline}%

Tu as démontré que la stratégie fonctionne dans tes mains.
Bravo. C'est le moment le plus excitant ET le plus dangereux.

Mais avant d'engager du vrai argent, je dois te briefer sur la
TRANSITION LIVE. C'est une phase à part entière, avec ses propres
règles. Mental, taille de position, gestion des premières pertes.

On commence ?
```

→ Ensuite Claude lance `procedures/transition-live.md`.

#### Si NO-GO :
```
⚠️ VERDICT : NO-GO POUR LE LIVE

Voici tes stats actuelles :
  - {total_trades} trades sur {nb_jours} jours
  - WR : {wr}% (seuil 45 %)  ← {check_or_cross}
  - PF : {pf} (seuil 1.5)    ← {check_or_cross}
  - DD max : {dd_max}%        ← {check_or_cross}
  - Discipline : {discipline}% ← {check_or_cross}

Pas de panique. La majorité des traders n'y arrivent pas du premier coup.
Voici ce qui doit se passer maintenant :

  1. On analyse ensemble TES erreurs récurrentes (top 3)
  2. On itère vers V5.3 si nécessaire (ajustements de la stratégie)
  3. On reprend 30 trades supplémentaires en paper
  4. On re-évalue dans 4-6 semaines

Engager du vrai argent maintenant = perdre. Je préfère qu'on prenne
le temps de bien faire. Tu m'as fait confiance jusqu'ici, continue.

Tu es d'accord pour qu'on regarde tes 3 erreurs récurrentes ?
```

→ Ensuite Claude lance `procedures/post-trade-debrief.md` en mode bilan global.

---

## 🚨 RÈGLES STRICTES POUR CLAUDE

1. **JAMAIS** valider GO si UN seul critère manque, même si l'apprenant insiste
2. **JAMAIS** passer en mode "essai live" pour tester
3. **TOUJOURS** afficher les chiffres bruts, pas d'enrobage
4. **TOUJOURS** rappeler que NO-GO ≠ échec, c'est une étape normale
5. **UPDATE** `state/current-phase.md` avec le verdict + date

---

## 📊 EXEMPLE CONCRET

### Cas A — GO légitime
```
Trades : 42
WR : 52% ✓
PF : 1.85 ✓
DD max : 11% ✓
Discipline : 95% ✓
→ GO pour le live
```

### Cas B — NO-GO sur un seul critère
```
Trades : 38
WR : 47% ✓
PF : 1.6 ✓
DD max : 18% ✗  ← FAIL
Discipline : 92% ✓
→ NO-GO. Le DD dit qu'il y a un trade qui a sauté.
   Probablement un trade hors checklist. À analyser.
```

### Cas C — Apprenant pressé qui insiste
```
Apprenant : "Mais j'ai 28 trades et tout est vert, on peut y aller ?"
Nodex     : "Non. 30 minimum. Pas 28. Pas 29. 30. C'est exactement ce
             genre de raccourci qui te fera exploser en live. La
             discipline COMMENCE ici. Encore 2 trades."
```

---

**Version** : 1.0 · **Phase** : 4 · **Suivante** : transition-live.md
