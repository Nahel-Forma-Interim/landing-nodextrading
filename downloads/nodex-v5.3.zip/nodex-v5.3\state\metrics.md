# Métriques cumulées — V5.3 Backtest (préliminaire)

**Dernière MAJ** : 2026-04-26
**Données reportées par Nahel** (10 trades V5.3 effectués manuellement en paper trading)

## Stats globales V5.3

| Métrique | Valeur | Cible Phase 3 (30 trades) |
|----------|--------|----------------------------|
| Trades exécutés | **10** | 30 |
| WR (TP1 touché min) | **60 %** | ≥ 55 % |
| Profit Factor | ~1,8 (estimé) | ≥ 1,5 |
| Drawdown max | < 5 % | ≤ 10 % |
| P&L cumulé | **+18 % capital** | positif |
| RR moyen obtenu | ~2,5:1 | ≥ 2:1 |

## Comparaison V5.2 vs V5.3 (10 trades chacun)

| Métrique | V5.2 (FVG only) | V5.3 (Multi-POI + Fibo) | Delta |
|----------|-----------------|--------------------------|-------|
| WR | 50 % | **60 %** | +10 pts |
| PnL capital | +13 % | **+18 %** | +5 pts (+38 % relatif) |

## Répartition scénarios V5.3 (10 trades)

| Scénario | Nombre | % |
|----------|--------|---|
| A · Move parfait (+3%) | ~6 | ~60 % (Nahel rapporte "souvent TP à +3%") |
| B · Partiel +2,5% (+1,5%) | 0-1 | ~5 % |
| C · Partiel +1,5% (BE) | 0-1 | ~5 % |
| D · SL initial (−1%) | ~3 | ~30 % |

## Répartition par actif V5.3

| Actif | Trades | WR | P&L | Note |
|-------|--------|-----|-----|------|
| ARB | ~6-7 | ~60 % | + | Watchlist focus prioritaire |
| PENDLE | ~3-4 | ~60 % | + | Watchlist focus prioritaire |
| Autres | 0 | — | — | Hors focus V5.3 |

## Méthode utilisée par Nahel (rapport)

- Tradait en H1 d'abord pour vue d'ensemble
- Trouvait les zones en M15 (POI dans la zone discount)
- Rentrée au point d'entrée précis
- TP à +3 % (sortie totale conforme V5.3)
- A été un peu moins gourmand sur certaines zones de liquidité plus hautes (= discipline OK)

## Erreurs répétées (Demon Finder)

| Erreur | Occurrences | Statut |
|--------|-------------|--------|
| (à analyser après 30 trades) | — | — |

**⚠️ Règle** : si une erreur atteint ≥ 3 occurrences sur 10 trades → STOP + revue méthode.

## Prochaines actions

1. Continuer les 20 trades V5.3 restants (atteindre 30)
2. À chaque nouveau trade : remplir trades-log.md avec grade + hard rules + résultat
3. À 20 trades : point intermédiaire avec ajustements éventuels
4. À 30 trades : audit final + décision Go/No-Go Phase 4
