# Template — Trade live (4 couches)

> À copier-coller pour CHAQUE trade live. Phases 5, 6, 7.

---

## Trade #___ — {date} — {asset}

### COUCHE 1 — Technique
- **Symbol** : ___
- **Direction** : LONG (Nodex = long only)
- **Entry** : ___
- **SL** : ___
- **TP1 (BE)** : ___
- **TP2 (sortie)** : ___
- **RR** : ___
- **Risque ($)** : ___
- **Risque (%)** : ___
- **Capital avant** : ___
- **Capital après** : ___
- **Résultat** : WIN / LOSS / BE / RUNNER
- **Variation €** : ___
- **Variation %** : ___

### COUCHE 2 — Checklist 18 points
- [ ] HTF haussier (H4 + H1)
- [ ] PDH ou PWH identifié
- [ ] Sweep clair (mèche + clôture en-dessous)
- [ ] Volume sweep > moyenne 20
- [ ] FVG haussier formé après sweep
- [ ] FVG vierge
- [ ] FVG ≥ 0,3 % de taille
- [ ] Bougie 2 mitige sans casser
- [ ] Bougie 2 clôture haussière
- [ ] Pas de wick majeur sous bougie 2
- [ ] SL sous mèche du sweep
- [ ] Risque calculé = 1 % (ou 1,5 % A+)
- [ ] RR minimum 1:2
- [ ] Pas de news majeur dans l'heure
- [ ] Session NYAM en cours
- [ ] Calme + pas en revanche
- [ ] Pas dépassé 2 trades dans la session
- [ ] Acceptation perte sans recul

**Score** : ___ / 18 (si < 18 → trade NE DEVAIT PAS être pris)

### COUCHE 3 — Émotionnel

**AVANT le trade**
- Peur (1-10)         : ___
- Excitation (1-10)   : ___
- Fatigue (1-10)      : ___
- Conviction (1-10)   : ___

**PENDANT le trade**
- Nb fois où j'ai voulu modifier SL : ___
- Nb fois où j'ai voulu modifier TP : ___
- Nb fois où j'ai vérifié le prix    : ___
- Émotion dominante : peur / euphorie / sérénité / impatience

**APRÈS le trade**
- Satisfaction (1-10) : ___
- Frustration (1-10)  : ___
- Si perte : revanche envisagée ? OUI / NON
- Leçon clé du trade  : ___

### COUCHE 4 — Contextuel
- News macro du jour : ___
- État BTC vs MA200 : haussier / baissier / range
- Volatilité globale : faible / normale / forte
- Mon humeur perso (1-10) : ___
- Heure de sommeil cette nuit : ___ h
- Stress pro/perso ce jour : ___ /10

---

## Conclusion (à remplir POST-TP/SL)

**Ce que j'ai bien fait** : ___

**Ce que j'aurais pu mieux faire** : ___

**Pattern récurrent identifié (si oui)** : ___

**Action correctrice pour le prochain trade** : ___

---

**Update à faire après remplissage** :
- [ ] state/trades-log.md (ligne ajoutée)
- [ ] state/metrics.md (WR, PF, DD recalculés)
- [ ] state/live-progression.md (palier mis à jour)
