# 📋 Questionnaire Diagnostic — 10 questions

Nodex pose ces questions **UNE PAR UNE**, attend la réponse, puis enchaîne.
Pas de liste en bloc — ça fait formulaire administratif.

---

## Question 1 — Expérience trading
> *"Depuis combien de temps tu trades ? (débutant complet, quelques mois, 1-2 ans, 3 ans+)"*

**Ce qu'on mesure** : ancienneté
**Impact sur programme** :
- 0 à 3 mois → programme **débutant** (3 semaines)
- 3 mois à 2 ans → programme **intermédiaire** (2 semaines)
- 2 ans+ → programme **avancé** (1 semaine)

---

## Question 2 — Résultats passés
> *"As-tu déjà réussi à faire du bénéfice net sur un mois complet ? (oui régulièrement / oui parfois / jamais / je ne sais pas / je débute)"*

**Ce qu'on mesure** : rentabilité passée
**Impact** : si jamais rentable → focus sur discipline & psychologie en priorité

---

## Question 3 — Méthodes connues
> *"Tu connais déjà le SMC / ICT / Order Blocks / FVG / sweep ? Sur une échelle de 1 (jamais entendu) à 10 (expert) ?"*

**Ce qu'on mesure** : prérequis techniques
**Impact** :
- 1-3 → théorie SMC complète obligatoire (Leçons 1-10)
- 4-6 → théorie allégée (Leçons 1, 5, 9, 10)
- 7+ → rappels rapides + focus V5.2 spécifique

---

## Question 4 — Marchés tradés
> *"Tu trades ou tu as tradé quels marchés ? (forex / crypto spot / crypto futures / actions / indices / autre)"*

**Ce qu'on mesure** : familiarité avec crypto spot
**Impact** : si aucune expérience crypto → intro nécessaire

---

## Question 5 — Timeframe préféré
> *"Quand tu trades (ou quand tu aimerais trader), tu te sens plus à l'aise en quelle durée : scalping (M1-M15), intraday (M30-H1), swing (H4-D1) ?"*

**Ce qu'on mesure** : alignement avec M15 NYAM
**Impact** : si incompatible avec M15, expliquer pourquoi on l'utilise

---

## Question 6 — Capital disponible
> *"Quel capital envisages-tu pour ton trading (estimation) ? (moins de 500€ / 500-2000€ / 2000-10000€ / plus de 10000€). Aucun jugement, juste pour adapter les exemples."*

**Ce qu'on mesure** : adaptation des exemples chiffrés
**Impact** : tous les calculs de taille de position sont adaptés

---

## Question 7 — Temps disponible
> *"Combien d'heures par jour tu peux y consacrer en semaine ? (moins de 1h / 1-3h / 3-6h / temps plein)"*

**Ce qu'on mesure** : intensité du coaching
**Impact** :
- moins d'1h → programme étalé sur 4+ semaines
- 3-6h → programme standard 2-3 semaines
- temps plein → programme intensif 1-2 semaines

---

## Question 8 — Objectif principal
> *"C'est quoi ton objectif principal avec ce trading ? (revenu complémentaire / remplacer mon salaire / gros gains rapides / apprendre par curiosité / autre)"*

**Ce qu'on mesure** : motivation réelle
**Impact** : recadrer attentes si "gros gains rapides" (promesse réaliste)

---

## Question 9 — Discipline / Psychologie
> *"Tu te décrirais comment sur l'impulsivité en trading ? (très discipliné / globalement discipliné / je me laisse parfois emporter / j'ai déjà flamé un compte sur une mauvaise décision)"*

**Ce qu'on mesure** : risque psychologique
**Impact** : si problèmes de discipline → règles psychologiques renforcées, stop-loss plus serré

---

## Question 10 — Équipement actuel
> *"Tu as TradingView installé (web ou Desktop) ? Tu as un compte Binance ? Un journal de trades ?"*

**Ce qu'on mesure** : prérequis techniques
**Impact** : adapter la phase "Installation" (peut être zappée si déjà tout installé)

---

## 🎯 Fin du questionnaire

Après Q10, Nodex dit :

> *"Parfait, j'ai ce qu'il me faut. Laisse-moi **2 minutes** pour analyser ton profil et te proposer un programme sur-mesure."*

Puis Nodex lit `onboarding/analyse-et-programme.md` et applique la grille.

---

## 📝 Version courte (si apprenant dit "j'ai du niveau")

Poser uniquement :
- Q1 (expérience)
- Q2 (résultats)
- Q4 (marchés)
- Q8 (objectif)

Puis diriger vers programme intermédiaire ou avancé selon réponses.
