# 🛠️ Guide d'installation — TradingView + MCP + GitHub

Nodex guide l'apprenant **étape par étape**. Il ne saute aucune étape, vérifie à chaque fois que ça fonctionne.

---

## 📋 Pré-requis

Avant de commencer, l'apprenant doit avoir :
- Un **PC Windows** (Mac/Linux adaptation possible mais non couverte ici)
- **Node.js** installé (version 18+)
- **Git** installé
- Un compte **GitHub** (gratuit)
- Un compte **TradingView** (gratuit suffit pour débuter)

**Nodex vérifie ça d'abord en posant la question** : *"Tu as tout ça ? Si oui, on continue. Si non, je te guide étape par étape."*

---

## 🎯 Étape 1 — Installer TradingView Desktop

### Pourquoi Desktop et pas Web ?

La version Desktop permet à Nodex de **voir ton chart en direct** via le protocole CDP (port 9222). La version Web ne le permet pas.

### Procédure

1. Va sur **https://www.tradingview.com/desktop/**
2. Clique **"Download"** (MSIX Windows ou .dmg Mac)
3. Installe normalement (suivant / suivant / OK)
4. Lance TradingView Desktop au moins une fois pour valider l'installation

### Vérification

L'apprenant confirme : *"TV Desktop lance bien"* → on passe à l'étape 2.

---

## 🎯 Étape 2 — Exemption loopback (Windows MSIX)

**⚠️ Étape critique.** Sans elle, Nodex ne pourra pas se connecter au chart.

### Pourquoi ?

Les apps MSIX Windows sont dans un sandbox qui **bloque l'écoute localhost** par défaut. On doit faire une exception pour TradingView.

### Procédure

1. Ouvre **PowerShell en tant qu'Administrateur** :
   - Clic droit sur le bouton Démarrer
   - Choisis *"Terminal (admin)"* ou *"PowerShell (admin)"*
   - Accepte le UAC (fenêtre jaune)

2. Colle cette commande :
   ```powershell
   CheckNetIsolation LoopbackExempt -a -n="TradingView.Desktop_n534cwy3pjxzj"
   ```

3. Appuie sur **Entrée**. Tu dois voir : `OK.`

### Vérification

L'apprenant confirme *"c'est écrit OK"* → on passe à l'étape 3.

---

## 🎯 Étape 3 — Lancer TV avec le port debug activé

### Procédure (PowerShell **normal** cette fois, pas admin)

1. Ouvre **PowerShell** (clic droit Démarrer → Terminal)
2. Colle la commande :
   ```powershell
   Get-Process TradingView -ErrorAction SilentlyContinue | Stop-Process -Force
   Start-Sleep -Seconds 2
   $exe = "C:\Program Files\WindowsApps\TradingView.Desktop_*_x64__n534cwy3pjxzj\TradingView.exe"
   $resolved = (Get-Item $exe | Sort-Object Name -Descending | Select-Object -First 1).FullName
   Start-Process -FilePath $resolved -ArgumentList "--remote-debugging-port=9222"
   Start-Sleep -Seconds 6
   Test-NetConnection -ComputerName localhost -Port 9222 -InformationLevel Quiet -WarningAction SilentlyContinue
   ```

3. Si le résultat final est `True` → **c'est bon, port 9222 actif** ✅

### Vérification

L'apprenant confirme *"True"* → on passe à l'étape 4.

---

## 🎯 Étape 4 — Configurer le compte Binance (spot)

### Prérequis
Si l'apprenant n'a pas encore de compte Binance, il doit en créer un.

### Procédure

1. Va sur **https://www.binance.com**
2. Crée ton compte (KYC obligatoire pour dépôt)
3. **Active le Paper Trading** ou Binance Testnet pour démarrer **SANS vrai argent**
4. Note : pour la phase backtest, tu peux aussi juste observer + tenir ton journal sans exécuter réellement

### Important
**L'apprenant ne touche PAS de vrai argent** avant d'avoir fait les 30 paper trades validés.

---

## 🎯 Étape 5 — Cloner le repo GitHub de formation

Pour récupérer tous les supports de formation (HTML, docs, journal).

### Procédure

1. Ouvre PowerShell dans le dossier de ton choix (ex: `Documents`)
2. Colle :
   ```powershell
   git clone https://github.com/Nahel-Forma-Interim/nodex-tracker.git
   cd nodex-tracker
   ```
3. Le dossier contient :
   - `index.html` → tracker du projet
   - `backtest/formation-v5.2-complete.html` → formation complète
   - `backtest/setup-smc-visuel.html` → visuel 16:9 du setup
   - `backtest/strategie-v5.html` → doc stratégie
   - `backtest/nodex-v4.0-formation.mp4` → vidéo explicative

4. Ouvre la formation dans ton navigateur :
   ```powershell
   Start-Process "backtest/formation-v5.2-complete.html"
   ```

---

## 🎯 Étape 6 — Indicateurs TradingView recommandés

Une fois TV lancé :

1. Ouvre ton chart (exemple : `BINANCE:ARBUSDT`)
2. Règle le timeframe sur **M15**
3. Ajoute ces indicateurs (gratuits dans la bibliothèque TV) :
   - **FVG/iFVG (Nephew_Sam_)** → repère les FVG automatiquement
   - **AsianSession Kasper** → marque la session asiatique (= zone liquidité)
   - **Volume** → pour vérifier le critère volume ≥ 3× moyenne

### Vérification

L'apprenant confirme *"les indicateurs sont chargés"* → **installation terminée** 🎉

---

## 🎯 Étape 7 — Tester la connexion Nodex ↔ TV

Dans Claude, l'apprenant tape :

> *"Nodex, tu vois mon chart ?"*

Nodex utilise alors le MCP TradingView pour vérifier :
- `mcp__tradingview__tv_health_check` → confirme la connexion
- `mcp__tradingview__chart_get_state` → lit l'état du chart

**Si connexion OK** : Nodex confirme *"Je vois ton chart sur ARBUSDT M15, c'est parfait, on peut commencer."*

**Si erreur** : Nodex aide à diagnostiquer (souvent port 9222 pas écouté → relancer étape 3).

---

## 📊 Récapitulatif visuel

```
[ TradingView Desktop ]   --CDP port 9222-->   [ Claude / Nodex ]
         ⬇                                              ⬆
  Chart M15 ARBUSDT                              Formation V5.2
  + indicateurs FVG                              + skill nodex-v5.2
  + volumes
         ⬇
  Exécution trades
  en paper trading
         ⬇
  Journal Nodex
  (CSV ou app perso)
```

---

## 🎯 Fin de l'installation

Nodex confirme :

> *"OK, tout est en place. Tu as maintenant :*
> *1. TradingView Desktop qui tourne avec le port debug*
> *2. Le chart ARBUSDT M15 ouvert avec les indicateurs*
> *3. Le repo formation cloné*
> *4. Moi (Nodex) qui peut voir ton chart en temps réel*
>
> *On est prêt. Demain (ou maintenant si tu veux), on démarre la **Leçon 1 : Tendance vs Range**. Ça te va ?"*
